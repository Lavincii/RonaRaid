﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"





IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 System.Void Flash::Start()
extern void Flash_Start_m8B26902F759AE1F18A1FF54FF0A066551F0F3688 ();
// 0x00000002 System.Void Flash::OnTriggerEnter2D(UnityEngine.Collider2D)
extern void Flash_OnTriggerEnter2D_m061BBE509F31E435AA7B532B2B76390A0279AB46 ();
// 0x00000003 System.Void Flash::End()
extern void Flash_End_m5068DFB8589D22BF984E243B60AD953FE1CFAB1E ();
// 0x00000004 System.Void Flash::ResetMaterial()
extern void Flash_ResetMaterial_mFE1D963684FF80E430ED7277CB13E3F3F0FE6FA0 ();
// 0x00000005 System.Void Flash::.ctor()
extern void Flash__ctor_mA632A5743328DCFC5891A1231933E50D81F1595C ();
// 0x00000006 System.Void HardDouble::Start()
extern void HardDouble_Start_mB17F406E2C53FEDB876FC9434C56643C72286D57 ();
// 0x00000007 System.Void HardDouble::Update()
extern void HardDouble_Update_mA5BCAB98C6459967C3937AE5A211ACEDFD9BDB3F ();
// 0x00000008 System.Void HardDouble::.ctor()
extern void HardDouble__ctor_m7AB5B8179CD08DD01B339F4AEF7121522697D864 ();
// 0x00000009 System.Void PopReward::Start()
extern void PopReward_Start_m36933F0702D7F9A03919676D06CF0D8392BE9EAD ();
// 0x0000000A System.Void PopReward::ShowRewardedVideo()
extern void PopReward_ShowRewardedVideo_mC3C5917115C3342679FAAE58CB22C2BA9E2D331B ();
// 0x0000000B System.Void PopReward::OnUnityAdsReady(System.String)
extern void PopReward_OnUnityAdsReady_m57F6FB4D5C9E3C4545AD5723F06C822C21F6DB47 ();
// 0x0000000C System.Void PopReward::OnUnityAdsDidFinish(System.String,UnityEngine.Advertisements.ShowResult)
extern void PopReward_OnUnityAdsDidFinish_m4A8059C0657243C712795119FE1F7AE351589C65 ();
// 0x0000000D System.Void PopReward::OnUnityAdsDidError(System.String)
extern void PopReward_OnUnityAdsDidError_m3629F72E0898984109176C5714E8C2C0C7534934 ();
// 0x0000000E System.Void PopReward::OnUnityAdsDidStart(System.String)
extern void PopReward_OnUnityAdsDidStart_m1D5BBF3E4A730C48D4B6F6E2AC7E31AA27D2C64F ();
// 0x0000000F System.Void PopReward::.ctor()
extern void PopReward__ctor_mF48C7E97B29AE38BBB1B8CECB5E508314BD49FFA ();
// 0x00000010 System.Void RemoveAds::RemoveAd()
extern void RemoveAds_RemoveAd_mD661F9870C921E6C506F0A6E285692376D0E1F8C ();
// 0x00000011 System.Void RemoveAds::.ctor()
extern void RemoveAds__ctor_m484BCDFD8A6746837A8C28CBEFC680EC66780E6F ();
// 0x00000012 System.Void AudioManger::Awake()
extern void AudioManger_Awake_m55F957100F48CA3F327909F434F2979925602598 ();
// 0x00000013 System.Void AudioManger::Start()
extern void AudioManger_Start_m3C13AB431184579FAAA65714EC6E833F195AD8AB ();
// 0x00000014 System.Void AudioManger::Play(System.String)
extern void AudioManger_Play_m08EFC2908A2E13C182E2D3562078944EC112BAA4 ();
// 0x00000015 System.Void AudioManger::StopPlaying(System.String)
extern void AudioManger_StopPlaying_m40F69ED32FE1832B6C6394EB7F1913A53F54A46B ();
// 0x00000016 System.Void AudioManger::.ctor()
extern void AudioManger__ctor_m6016AF7021462D6CFAD2C2B48D94370E81DDEC87 ();
// 0x00000017 System.Void BannerManager::Start()
extern void BannerManager_Start_m55992CD2487295D18E24B8662213845A978702C6 ();
// 0x00000018 System.Collections.IEnumerator BannerManager::ShowBannerWhenInitialized()
extern void BannerManager_ShowBannerWhenInitialized_m676BDCC05DE7151B3C81F13E5D60159AFE93BD38 ();
// 0x00000019 System.Void BannerManager::LoadShoot()
extern void BannerManager_LoadShoot_mAE9D9518D1E46D364C1920109D0983126B4508B9 ();
// 0x0000001A System.Void BannerManager::LoadCatch()
extern void BannerManager_LoadCatch_mF5E2C9AE9AAC91E61AEEB9255275F4DEE43B35C2 ();
// 0x0000001B System.Void BannerManager::RemoveAds()
extern void BannerManager_RemoveAds_mF98255599CC0DB310FED239100482738EAF417BA ();
// 0x0000001C System.Void BannerManager::.ctor()
extern void BannerManager__ctor_m0AD620A047688F663C111848A7692153F093DCF3 ();
// 0x0000001D System.Void BombSpawn::Start()
extern void BombSpawn_Start_m099F0CC3E1FF96ACEBD17E685957CDCCE3747A7C ();
// 0x0000001E System.Void BombSpawn::Update()
extern void BombSpawn_Update_mD785AEDF2F7DF905F436D2113896ECC17CFD4A04 ();
// 0x0000001F System.Void BombSpawn::.ctor()
extern void BombSpawn__ctor_mEDA97D761DD5C4468E1603E15F7D8CECB3514267 ();
// 0x00000020 System.Void BombSpawner::Start()
extern void BombSpawner_Start_mEEF4FD796E6F125D8FA6BD431C31D046CDBBF2A8 ();
// 0x00000021 System.Void BombSpawner::Update()
extern void BombSpawner_Update_mAA11B63B2808969C2E4DA80B0B0847CFF156BA19 ();
// 0x00000022 System.Void BombSpawner::.ctor()
extern void BombSpawner__ctor_mE300FC2E154A29A155E45AEB87AEF64E847F3747 ();
// 0x00000023 System.Void Bullet::Start()
extern void Bullet_Start_m0C6AD7FCC791ADF08593B040294D8B7329617D04 ();
// 0x00000024 System.Void Bullet::OnTriggerEnter2D(UnityEngine.Collider2D)
extern void Bullet_OnTriggerEnter2D_m9244231F2C1AB21C314A050A32331CA5BBA44834 ();
// 0x00000025 System.Void Bullet::.ctor()
extern void Bullet__ctor_mFBA1E7297C133AE06ADA2EF2BA04567AD213A9D4 ();
// 0x00000026 System.Void ButtonFX::Button()
extern void ButtonFX_Button_mBDED4D807C29028E0518F18098CE57DCE8F2A8AD ();
// 0x00000027 System.Void ButtonFX::.ctor()
extern void ButtonFX__ctor_m33A3B15214B840D82BF71CBB23E306A2BB8FCC1E ();
// 0x00000028 System.Void Catch2x::Start()
extern void Catch2x_Start_m6A2D7AB2413CA27E6CF03FF1E45691B6F293C43E ();
// 0x00000029 System.Void Catch2x::OnTriggerEnter2D(UnityEngine.Collider2D)
extern void Catch2x_OnTriggerEnter2D_mA6B716C793E5354099237C60E6E779D6853BFFAD ();
// 0x0000002A System.Void Catch2x::.ctor()
extern void Catch2x__ctor_mE45A49ED1CA1314C06A8DA5ADAD3BD8E9F06590A ();
// 0x0000002B System.Void CatchAM::Start()
extern void CatchAM_Start_mC618B2FE34F7C03C78C5633723788ADF48EC4D17 ();
// 0x0000002C System.Void CatchAM::PlaySound(System.String)
extern void CatchAM_PlaySound_m8E3AA76BF692EEED752C5FED44783C8DE222536B ();
// 0x0000002D System.Void CatchAM::.ctor()
extern void CatchAM__ctor_m3BD1C6BE9817EE19DE20B49D13DA0E2E452BDFF0 ();
// 0x0000002E System.Void CatchBomb::Start()
extern void CatchBomb_Start_m5A9C8D1B7956A551A5E176FEDC4FD9C43D9F7345 ();
// 0x0000002F System.Void CatchBomb::OnTriggerEnter2D(UnityEngine.Collider2D)
extern void CatchBomb_OnTriggerEnter2D_m02B6502F8D3C261E6A08C871285EC1260227DA17 ();
// 0x00000030 System.Void CatchBomb::.ctor()
extern void CatchBomb__ctor_mE90366CB482D4058AD03DF509B81B977645FEB1D ();
// 0x00000031 System.Void CatchEnemy::Start()
extern void CatchEnemy_Start_mDD09C54710C691DD56B9DD5AB3FC6BCEAAE02E9F ();
// 0x00000032 System.Void CatchEnemy::OnTriggerEnter2D(UnityEngine.Collider2D)
extern void CatchEnemy_OnTriggerEnter2D_m08E3932BD2444F78470FCACA449FA970E2AB9160 ();
// 0x00000033 System.Void CatchEnemy::.ctor()
extern void CatchEnemy__ctor_mD29810C4D3D87F0486C6B8F68FA3ADA6ECE1FF48 ();
// 0x00000034 System.Void CatchMenu::LoadMenu()
extern void CatchMenu_LoadMenu_m2AB39CAFFB9EC40174EB00FD45368AE107F0293C ();
// 0x00000035 System.Void CatchMenu::.ctor()
extern void CatchMenu__ctor_m2FAC1A68E1193A06A7B78CA61601856B6BC44876 ();
// 0x00000036 System.Void CatchPointSystem::Start()
extern void CatchPointSystem_Start_mC14B56BBFE93513B54B20593D07B618BE73F3DB9 ();
// 0x00000037 System.Void CatchPointSystem::Update()
extern void CatchPointSystem_Update_m3A2C68E0BDBDBC1F168B6829BBA9068E2528E4BB ();
// 0x00000038 System.Void CatchPointSystem::.ctor()
extern void CatchPointSystem__ctor_mFE4A25CF2B63001677710F8052C1EF7DAB4B44AB ();
// 0x00000039 System.Void CatchScore::Start()
extern void CatchScore_Start_m9A0C00C7CC643E831032880AE895482B7B3EFFFA ();
// 0x0000003A System.Void CatchScore::Update()
extern void CatchScore_Update_m008FA6BB11EDB68BA6F097EFD38561A33021A2ED ();
// 0x0000003B System.Void CatchScore::AddScore()
extern void CatchScore_AddScore_mED9057926185F69782359763BC33A32C4BED253F ();
// 0x0000003C System.Void CatchScore::GameOver()
extern void CatchScore_GameOver_mEB8B7D63B4EE6614296878800F561A95199EE7F1 ();
// 0x0000003D System.Void CatchScore::.ctor()
extern void CatchScore__ctor_mCECEAC6A245A82E8D508C9C9BD9E3DE111311617 ();
// 0x0000003E System.Void CoinAdReward::Start()
extern void CoinAdReward_Start_m28D67D3666895FD9B491B525F1A0689C86AF6D2C ();
// 0x0000003F System.Void CoinAdReward::ShowRewardedVideo()
extern void CoinAdReward_ShowRewardedVideo_m8D36F381076CA846BE3E3EF939B6401844A5F5A9 ();
// 0x00000040 System.Void CoinAdReward::OnUnityAdsReady(System.String)
extern void CoinAdReward_OnUnityAdsReady_m90957FDBB0741B93071E915703BB75AA51D0FC6A ();
// 0x00000041 System.Void CoinAdReward::OnUnityAdsDidFinish(System.String,UnityEngine.Advertisements.ShowResult)
extern void CoinAdReward_OnUnityAdsDidFinish_m7D8181831BA381EEB94D32632586959D594B42E7 ();
// 0x00000042 System.Void CoinAdReward::OnUnityAdsDidError(System.String)
extern void CoinAdReward_OnUnityAdsDidError_mAC06C3CEA447B7899D0C3DB900F7FDA480D91255 ();
// 0x00000043 System.Void CoinAdReward::OnUnityAdsDidStart(System.String)
extern void CoinAdReward_OnUnityAdsDidStart_m27D632ECB28499438AA003A6522CD5FFC2F9CA67 ();
// 0x00000044 System.Void CoinAdReward::.ctor()
extern void CoinAdReward__ctor_mD0765993ADC955FBE3232F77D0071E7DBFFBD232 ();
// 0x00000045 System.Void CoinTracker::Start()
extern void CoinTracker_Start_m5AD826DB751C9309E18CA4F6D2F7D7FAA6DE2F8E ();
// 0x00000046 System.Void CoinTracker::Update()
extern void CoinTracker_Update_mF7E677FBCD521A8182ED9187127A23A79F2718E0 ();
// 0x00000047 System.Void CoinTracker::AddScore()
extern void CoinTracker_AddScore_m40D1C18B124C72CCC08E16D9332C7C1A214119B2 ();
// 0x00000048 System.Void CoinTracker::GameOver()
extern void CoinTracker_GameOver_mD0772FDA4FA10B7161C07BDB238B8DA82B6F5172 ();
// 0x00000049 System.Void CoinTracker::.ctor()
extern void CoinTracker__ctor_m5F588AA587478FCFB240FD7351039A61B79E8619 ();
// 0x0000004A System.Void DeployVirus::Start()
extern void DeployVirus_Start_m91C8823912AF0D79B2ADB5C48D10C19012E1F9F7 ();
// 0x0000004B System.Void DeployVirus::spawnVirus()
extern void DeployVirus_spawnVirus_m8A05CD118F8E95B9F236B866D8F4DCAE3FF85A3D ();
// 0x0000004C System.Collections.IEnumerator DeployVirus::virusWave()
extern void DeployVirus_virusWave_m147F6052081F7FA9C281088F656D37EC9CA1E7E1 ();
// 0x0000004D System.Void DeployVirus::.ctor()
extern void DeployVirus__ctor_mA9E06CED6B34990D870F599C2BDE2162A582E800 ();
// 0x0000004E System.Void DestroBoss::Start()
extern void DestroBoss_Start_m0D1EB2DA497E1F5F8F3837A138821DA79840CD76 ();
// 0x0000004F System.Void DestroBoss::OnTriggerEnter2D(UnityEngine.Collider2D)
extern void DestroBoss_OnTriggerEnter2D_m32F0B42A968CAF1402845BA76E3D37F6968668C1 ();
// 0x00000050 System.Void DestroBoss::.ctor()
extern void DestroBoss__ctor_mC988AE3C07E88381DF7CE688A74667DD27727029 ();
// 0x00000051 System.Void DestroBoss::.cctor()
extern void DestroBoss__cctor_m82558AABD9AFA2373F84BCC23E9C041171234C81 ();
// 0x00000052 System.Void DestroyBomb::OnMouseDown()
extern void DestroyBomb_OnMouseDown_mD187FDE1CE25ACEE0770F32DF62CE62D348FCB68 ();
// 0x00000053 System.Void DestroyBomb::.ctor()
extern void DestroyBomb__ctor_mFD313C2FE649DEF05985C8BF0C0FA6C2BA11C6FD ();
// 0x00000054 System.Void DestroyCatchCoin::Start()
extern void DestroyCatchCoin_Start_m885BB8FBF4E51CB024FF53AA12553F4F45B14839 ();
// 0x00000055 System.Void DestroyCatchCoin::OnTriggerEnter2D(UnityEngine.Collider2D)
extern void DestroyCatchCoin_OnTriggerEnter2D_mD54A874EE4793A639EDEBFA20D501D90E0C23EE6 ();
// 0x00000056 System.Void DestroyCatchCoin::.ctor()
extern void DestroyCatchCoin__ctor_m8415F77D06A57FBDFBD82043C4AF19C15EF0BBCC ();
// 0x00000057 System.Void DestroyCoin::OnMouseDown()
extern void DestroyCoin_OnMouseDown_m7562EBBED9BC657C973FAE80996D860BA3D82AEF ();
// 0x00000058 System.Void DestroyCoin::.ctor()
extern void DestroyCoin__ctor_m20A221F9888831B5AEA23885C4EB1B76327E97A3 ();
// 0x00000059 System.Void DestroyDoubler::Start()
extern void DestroyDoubler_Start_mA93BB48E7DCCF3427397D5AC208F33844675BE4E ();
// 0x0000005A System.Void DestroyDoubler::OnMouseDown()
extern void DestroyDoubler_OnMouseDown_mBD30A513871D511CDD60CCF162AE301823B4F8EC ();
// 0x0000005B System.Void DestroyDoubler::.ctor()
extern void DestroyDoubler__ctor_m9F1820B69915A21613DC4E2C6845120DEF71A0BB ();
// 0x0000005C System.Void DestroyFive::Start()
extern void DestroyFive_Start_mC4D990F544BB6413A53DFD77D6744EDC9E33258E ();
// 0x0000005D System.Void DestroyFive::OnMouseDown()
extern void DestroyFive_OnMouseDown_mB2A2A6CA49924E82D5171A9592EE8A814C34160C ();
// 0x0000005E System.Void DestroyFive::.ctor()
extern void DestroyFive__ctor_m63961DCA7B8DA4FE920AF415F4BFFDA3D23ADD8E ();
// 0x0000005F System.Void DestroyHardCoin::OnTriggerEnter2D(UnityEngine.Collider2D)
extern void DestroyHardCoin_OnTriggerEnter2D_m4D08F566E2515A061DAD46BD7F70B1D48D3E3BBC ();
// 0x00000060 System.Void DestroyHardCoin::.ctor()
extern void DestroyHardCoin__ctor_m10A55F14EA978FAFDEDCC167F3B934E90FF04057 ();
// 0x00000061 System.Void DestroyTime::Start()
extern void DestroyTime_Start_m65F57F32C49BD1630C0BE6AC7EEA2BFCE3D92DAC ();
// 0x00000062 System.Collections.IEnumerator DestroyTime::WaitThenRestoreTime()
extern void DestroyTime_WaitThenRestoreTime_mFCA4CD4EF8634211D695D6B8E4A03396E319EBE1 ();
// 0x00000063 System.Void DestroyTime::OnMouseDown()
extern void DestroyTime_OnMouseDown_m1DA55B94D0931EE09359FA114EDAEDDA9AAD2D36 ();
// 0x00000064 System.Void DestroyTime::.ctor()
extern void DestroyTime__ctor_mB3397E61E00BF93B8EC946ECFD10623F4E81D35A ();
// 0x00000065 System.Void DestroyVirus::OnMouseDown()
extern void DestroyVirus_OnMouseDown_m706A8C0FE72604D1D143689BC5675802EB988CEB ();
// 0x00000066 System.Void DestroyVirus::.ctor()
extern void DestroyVirus__ctor_mC8BBDD226E6D4FDF711FABC1D4F840F369DA47EC ();
// 0x00000067 System.Void Enemy::Start()
extern void Enemy_Start_m0681B66D4522F045EB7A33A21467994960D1E435 ();
// 0x00000068 System.Void Enemy::OnTriggerEnter2D(UnityEngine.Collider2D)
extern void Enemy_OnTriggerEnter2D_mB5D8A9A3E7CFA603912813FE5D11B43F5F83634E ();
// 0x00000069 System.Void Enemy::.ctor()
extern void Enemy__ctor_mCD4E016A02FE662E339AA011EBA74D77B09556C5 ();
// 0x0000006A System.Void EnemySpawner::Start()
extern void EnemySpawner_Start_mC0F2354C1D2ED84F19D7BF22C89A2C198EBED26E ();
// 0x0000006B System.Void EnemySpawner::Update()
extern void EnemySpawner_Update_m846CE9A8B10E8EBB82FF444060B85133DDEFD0D0 ();
// 0x0000006C System.Void EnemySpawner::SpawnEnemy(System.Single)
extern void EnemySpawner_SpawnEnemy_m7BEBAA3A754FACF357E86E9886F4BC9A627A56C4 ();
// 0x0000006D System.Void EnemySpawner::SelectWave()
extern void EnemySpawner_SelectWave_mE408638B531283B04509C24C58CA59137C6D129B ();
// 0x0000006E System.Void EnemySpawner::.ctor()
extern void EnemySpawner__ctor_m637C6372D629C685D64F22E5E15FD64F9F715F24 ();
// 0x0000006F System.Void Wave::.ctor()
extern void Wave__ctor_m3446E431F89F15C279F37E857054908A70CEFF7E ();
// 0x00000070 System.Void FallingObjects::Update()
extern void FallingObjects_Update_m100967871ED390C30CF3D59FD5C74906AA92315E ();
// 0x00000071 System.Void FallingObjects::.ctor()
extern void FallingObjects__ctor_m8560F1BD49F8E2CA90E90116212BED550180EA90 ();
// 0x00000072 System.Void GoBack::LoadMenu()
extern void GoBack_LoadMenu_m4D9C6324D65115B9C2CFD5B5213761853FBDD3B0 ();
// 0x00000073 System.Void GoBack::.ctor()
extern void GoBack__ctor_m284DF5B1E05CFD89223704DA08C86BA499A5D2AF ();
// 0x00000074 System.Void HDestroyVirus::Start()
extern void HDestroyVirus_Start_mBF4BE8A94B81420312098D2FBC87707AEB0D2CFC ();
// 0x00000075 System.Void HDestroyVirus::OnTriggerEnter2D(UnityEngine.Collider2D)
extern void HDestroyVirus_OnTriggerEnter2D_m41C4E3BCADDC03D8CBF077F9369A27CDAEC19E90 ();
// 0x00000076 System.Void HDestroyVirus::.ctor()
extern void HDestroyVirus__ctor_mB65D776487AAAB1B350BC9A93E939C677E750705 ();
// 0x00000077 System.Void Hard2::Start()
extern void Hard2_Start_mA9613A5289BAB542C84BC4CD12C62B00E4090542 ();
// 0x00000078 System.Void Hard2::OnTriggerEnter2D(UnityEngine.Collider2D)
extern void Hard2_OnTriggerEnter2D_m26EF8E60C277D5C8DC8AD9EF353EE125BE9B006F ();
// 0x00000079 System.Void Hard2::.ctor()
extern void Hard2__ctor_mCD3A744BF1B59F7B0C7956AC973DA51FE8C1C4FF ();
// 0x0000007A System.Void Hard5::Start()
extern void Hard5_Start_m8526FF8540C11E0FB803CDAC030911F407716D39 ();
// 0x0000007B System.Void Hard5::OnMouseDown()
extern void Hard5_OnMouseDown_m65B08ADC1EF0F594949BCFF146F0C63788C79BA0 ();
// 0x0000007C System.Void Hard5::.ctor()
extern void Hard5__ctor_mE148252D2479C806DBB657C119C74BC8DF91E355 ();
// 0x0000007D System.Void HardScoreTracker::Start()
extern void HardScoreTracker_Start_m9F058AF876214B4F8F2B18C405705E242BB6E297 ();
// 0x0000007E System.Void HardScoreTracker::Update()
extern void HardScoreTracker_Update_mEE33D15D41E536AC8A5C53D143F95AE25677383D ();
// 0x0000007F System.Void HardScoreTracker::AddScore()
extern void HardScoreTracker_AddScore_m0C223064696E58DED92A073C140AA528FB052C1C ();
// 0x00000080 System.Void HardScoreTracker::GameOver()
extern void HardScoreTracker_GameOver_m2261217B7E361321FB8535BB4F50EC36560B46FC ();
// 0x00000081 System.Void HardScoreTracker::.ctor()
extern void HardScoreTracker__ctor_m17A7AA0EF7C5736E61DFEF1A7F756FEAEE4B99CC ();
// 0x00000082 System.Void HardSpawn::Start()
extern void HardSpawn_Start_m00EE51F0F061DF885C2490F602B8C9194A1EF27A ();
// 0x00000083 System.Void HardSpawn::Update()
extern void HardSpawn_Update_m623C6E5C3A695F4E40BCEE0D9FDC695749513AF0 ();
// 0x00000084 System.Void HardSpawn::SpawnHardEnemy(System.Single)
extern void HardSpawn_SpawnHardEnemy_m06757D17B212074518C072CD0E0A38ECBB421C4D ();
// 0x00000085 System.Void HardSpawn::SelectHardWave()
extern void HardSpawn_SelectHardWave_m21FE3194D4B39ADDE94FE5D54A19BB67642B835D ();
// 0x00000086 System.Void HardSpawn::.ctor()
extern void HardSpawn__ctor_mE279FD91B24D4FEA5A04FBA8C8210D08223FA4D5 ();
// 0x00000087 System.Void HardWWave::.ctor()
extern void HardWWave__ctor_m117E84440A1FAAD01652D21A0FC8E60FB66A1238 ();
// 0x00000088 System.Void LifeCount::Start()
extern void LifeCount_Start_m28F37A454DD7218BBAA759E6F6B030C308BC1027 ();
// 0x00000089 System.Void LifeCount::Update()
extern void LifeCount_Update_m95841959A436E9E0B5DF7BF75CD3B6047D2D3A53 ();
// 0x0000008A System.Void LifeCount::.ctor()
extern void LifeCount__ctor_mB877DD577CE884B3F3B1CE0F0B0F452E953E67B6 ();
// 0x0000008B System.Void LoseLife::OnTriggerEnter2D(UnityEngine.Collider2D)
extern void LoseLife_OnTriggerEnter2D_m25752540A77AB407241B70F01204256B39213879 ();
// 0x0000008C System.Void LoseLife::.ctor()
extern void LoseLife__ctor_mD59ECCB364B74EB205D25D21B0C6CFE180BBF8DD ();
// 0x0000008D System.Void MoveandShoot::Start()
extern void MoveandShoot_Start_mA964996AED1A73E8C8D02B7FB4BE5E997AAA2BF6 ();
// 0x0000008E System.Void MoveandShoot::Update()
extern void MoveandShoot_Update_m446CCF173390D0675F1FE9D129A852D63C0B6484 ();
// 0x0000008F System.Void MoveandShoot::.ctor()
extern void MoveandShoot__ctor_mE48AC1D25DE28DC38A8701C1A069C58B891C922B ();
// 0x00000090 System.Void Mover::Update()
extern void Mover_Update_mC8652D13CE63EB52757504DEFAA34034CBC4FACF ();
// 0x00000091 System.Void Mover::.ctor()
extern void Mover__ctor_mFAFEBAF042392E9011A10922FFFFCDBEED3EAA59 ();
// 0x00000092 System.Void NewBehaviourScript::Start()
extern void NewBehaviourScript_Start_mDB573B0B04591BBF1CDC10C7C835851EBF8D17F2 ();
// 0x00000093 System.Void NewBehaviourScript::Update()
extern void NewBehaviourScript_Update_mAA0BE51F329DE556FA585E93DD1B9CF6D917A85C ();
// 0x00000094 System.Void NewBehaviourScript::.ctor()
extern void NewBehaviourScript__ctor_mC87DFFB91971C9C20A9487A744F5E68D74FB05FE ();
// 0x00000095 System.Void ObjectPoolItem::.ctor(UnityEngine.GameObject,System.Int32,System.Boolean)
extern void ObjectPoolItem__ctor_m08FCD752A19000480320167AB069B013BC8DCBB8 ();
// 0x00000096 System.Void ObjectPooling::Awake()
extern void ObjectPooling_Awake_m8A7241F7A2052ECEE7E66804F4E2439ED8577FC9 ();
// 0x00000097 UnityEngine.GameObject ObjectPooling::GetPooledObject(System.Int32)
extern void ObjectPooling_GetPooledObject_mD2AEF887BB5BC3AE14EECE900E811404180CDC95 ();
// 0x00000098 System.Collections.Generic.List`1<UnityEngine.GameObject> ObjectPooling::GetAllPooledObjects(System.Int32)
extern void ObjectPooling_GetAllPooledObjects_m6BFF61A9C373EE2BAB0F7048A76F6C9F7B4B8261 ();
// 0x00000099 System.Int32 ObjectPooling::AddObject(UnityEngine.GameObject,System.Int32,System.Boolean)
extern void ObjectPooling_AddObject_m909B3E5F0DCC58649D6D7672B26DE150B08553EE ();
// 0x0000009A System.Void ObjectPooling::ObjectPoolItemToPooledObject(System.Int32)
extern void ObjectPooling_ObjectPoolItemToPooledObject_mABB4DCB5247AD26B3E2AF8B88CE880E03E4C50F3 ();
// 0x0000009B System.Void ObjectPooling::.ctor()
extern void ObjectPooling__ctor_m7B0E6901E1D36230FF1AE52CC46468486BB1AE89 ();
// 0x0000009C System.Void PauseMenu::Start()
extern void PauseMenu_Start_m87C554A1CF71A5E4A233FB35A6E0DB276388DF3B ();
// 0x0000009D System.Void PauseMenu::Update()
extern void PauseMenu_Update_m59D9098B173533E082A41253B251B1E5F5AB9EA9 ();
// 0x0000009E System.Void PauseMenu::Resume()
extern void PauseMenu_Resume_m69237FDC7E24AE034095A08093A78DA863B05A61 ();
// 0x0000009F System.Void PauseMenu::Pause()
extern void PauseMenu_Pause_m3E05CFCF9737962B2E1F4514848D7A59D879BA81 ();
// 0x000000A0 System.Void PauseMenu::LoadMain()
extern void PauseMenu_LoadMain_mCE52911C1C540E219AEF14D7A3E065552242A63A ();
// 0x000000A1 System.Void PauseMenu::QuitGame()
extern void PauseMenu_QuitGame_m19B044FD48321942D4249C199C49B9F035F16F4A ();
// 0x000000A2 System.Void PauseMenu::.ctor()
extern void PauseMenu__ctor_m1DE7CAFF465FE5BEB4E0ABDF165AFA208631EF28 ();
// 0x000000A3 System.Void PlayerController::Start()
extern void PlayerController_Start_mC0C9B9461D0BDAC48EC43715818A4BA63C4F45EF ();
// 0x000000A4 System.Void PlayerController::Update()
extern void PlayerController_Update_m38903EF1C8F12B9388303741F8040EE26C33DC33 ();
// 0x000000A5 System.Void PlayerController::.ctor()
extern void PlayerController__ctor_m648E40092E37395F4307411E855445886113CD60 ();
// 0x000000A6 System.Void Points::UpdateScore()
extern void Points_UpdateScore_mF2C01D69888483C76407A55F6D7A0B45AD9F8243 ();
// 0x000000A7 System.Void Points::.ctor()
extern void Points__ctor_mE666A3496B6E23C57AA4E9FFCD54A132E166F21A ();
// 0x000000A8 System.Void PowerUpSpawner::Start()
extern void PowerUpSpawner_Start_m87D14D12821222346CAE0066CBCF06F358B57475 ();
// 0x000000A9 System.Void PowerUpSpawner::Update()
extern void PowerUpSpawner_Update_mE1D8765893DC5A9E0E584E5A35ECA9753120E9E9 ();
// 0x000000AA System.Void PowerUpSpawner::SpawnEnemy(System.Single)
extern void PowerUpSpawner_SpawnEnemy_m0E1B4213C1628306F679A8CE59C540F6BB4B53A2 ();
// 0x000000AB System.Void PowerUpSpawner::SelectWave()
extern void PowerUpSpawner_SelectWave_m86C6D26D8B2F21A20EE82F5B038CFDA3AE31BB23 ();
// 0x000000AC System.Void PowerUpSpawner::.ctor()
extern void PowerUpSpawner__ctor_m558DCC8B1EF843461FD029CE70D61C3BE20E2985 ();
// 0x000000AD System.Void level::.ctor()
extern void level__ctor_m43B8CB57506E35BA27451FF99C5DDCD0460DA410 ();
// 0x000000AE System.Void PurchaseFX::Button()
extern void PurchaseFX_Button_m8B977C16F2FBB225D8CC3B4E036BC2DB56B91CB1 ();
// 0x000000AF System.Void PurchaseFX::.ctor()
extern void PurchaseFX__ctor_mC3903CF3222A8EB4B5E02DD40BD2BFF64EFE187A ();
// 0x000000B0 System.Void Restart::RestartGame()
extern void Restart_RestartGame_mE2CB28CB6105AAE4D4F715E0111C9D4033F1011E ();
// 0x000000B1 System.Void Restart::.ctor()
extern void Restart__ctor_m34586B1A8EF0A99076B81D9C768470378C934469 ();
// 0x000000B2 System.Void RestartHard::RestartGame()
extern void RestartHard_RestartGame_mEC82D82E7F547F705F198A738D13CA1FC4DD8094 ();
// 0x000000B3 System.Void RestartHard::.ctor()
extern void RestartHard__ctor_m2A6325E1E1382134016A15BFEA66E7179EC252F1 ();
// 0x000000B4 System.Void RewardedAdsButton::Start()
extern void RewardedAdsButton_Start_m014A67A1C7401E8226239F436FCAE3D82D470AA5 ();
// 0x000000B5 System.Void RewardedAdsButton::ShowRewardedVideo()
extern void RewardedAdsButton_ShowRewardedVideo_mF5F5A234162E2B8DB694EC6BC8026B6FA27AFCEF ();
// 0x000000B6 System.Void RewardedAdsButton::OnUnityAdsReady(System.String)
extern void RewardedAdsButton_OnUnityAdsReady_mD14B0661E57DBB2A801E46EEAA465F8852898623 ();
// 0x000000B7 System.Void RewardedAdsButton::OnUnityAdsDidFinish(System.String,UnityEngine.Advertisements.ShowResult)
extern void RewardedAdsButton_OnUnityAdsDidFinish_mFB400A89DDF3778E69F122BCBD6F5E54F18A9D34 ();
// 0x000000B8 System.Void RewardedAdsButton::OnUnityAdsDidError(System.String)
extern void RewardedAdsButton_OnUnityAdsDidError_m06538F8DFDB895C6E2872E43AC7EE7E0AE8D11DD ();
// 0x000000B9 System.Void RewardedAdsButton::OnUnityAdsDidStart(System.String)
extern void RewardedAdsButton_OnUnityAdsDidStart_m996CE3A0903A78F82D7B0236F1FE51F68E85A491 ();
// 0x000000BA System.Void RewardedAdsButton::.ctor()
extern void RewardedAdsButton__ctor_m7834FB47E0BF38EC317BC7366EB54197DF09F77B ();
// 0x000000BB System.Void RonaMenu::LoadMenu()
extern void RonaMenu_LoadMenu_m4580587AD40A2BE41D8927E0E61DB55E7E3FF032 ();
// 0x000000BC System.Void RonaMenu::.ctor()
extern void RonaMenu__ctor_mAD02893B98A283EA1ACD03DCC5EDBB7173642F84 ();
// 0x000000BD System.Void RonaSM::Start()
extern void RonaSM_Start_mACAD79CFF93BDCE84FDEF6EA6DF6729FADA1D11F ();
// 0x000000BE System.Void RonaSM::PlaySound(System.String)
extern void RonaSM_PlaySound_m5A20379E2C16B7C28EDCD39D411EB26023AA7C11 ();
// 0x000000BF System.Void RonaSM::.ctor()
extern void RonaSM__ctor_m91988CDC238A613FC638161E84027A1948FD3FE1 ();
// 0x000000C0 System.Void ScoreTracker::Start()
extern void ScoreTracker_Start_mCE3CC30C4A7DC9F85B576F53C9858940052FA01B ();
// 0x000000C1 System.Void ScoreTracker::Update()
extern void ScoreTracker_Update_mCAC5B848C06B902AA891C855164292E23F204817 ();
// 0x000000C2 System.Void ScoreTracker::AddScore()
extern void ScoreTracker_AddScore_mAEACBFB376EE25AA9FCBD6EBD939ECE742634F52 ();
// 0x000000C3 System.Void ScoreTracker::GameOver()
extern void ScoreTracker_GameOver_m7C1CD78FEDC664F2A61118138E1CD1E55CF9BD9F ();
// 0x000000C4 System.Void ScoreTracker::.ctor()
extern void ScoreTracker__ctor_mF1425BBD406E0C988CF84765B919C0F4C832ED3E ();
// 0x000000C5 System.Void ShootAM::Start()
extern void ShootAM_Start_m8DC4D3E1BF75C29A1036A180F702E288DC12981C ();
// 0x000000C6 System.Void ShootAM::PlaySound(System.String)
extern void ShootAM_PlaySound_m27012327808F961669D9E3564CA494D5E60D55A0 ();
// 0x000000C7 System.Void ShootAM::.ctor()
extern void ShootAM__ctor_m2230FAA02B5B7F2044D95773365D668A9AD4D450 ();
// 0x000000C8 System.Void ShootBomb::Start()
extern void ShootBomb_Start_mD1EE111A364236D07ADB2337D4947D7DA3ACD735 ();
// 0x000000C9 System.Void ShootBomb::OnTriggerEnter2D(UnityEngine.Collider2D)
extern void ShootBomb_OnTriggerEnter2D_m7611290EED6A5FD551B27B90300AE61605E47222 ();
// 0x000000CA System.Void ShootBomb::.ctor()
extern void ShootBomb__ctor_m3DD1B217CED6080E2B245963788C684C0A7E3789 ();
// 0x000000CB System.Void ShootMenu::LoadMenu()
extern void ShootMenu_LoadMenu_m46762EA7F99D069F48BB6A7E4866C54BD752C30D ();
// 0x000000CC System.Void ShootMenu::.ctor()
extern void ShootMenu__ctor_mC3F6CA874DCD6459327917016E83A82D6C455282 ();
// 0x000000CD System.Void ShootReward::Start()
extern void ShootReward_Start_mE41366D07EBA4DE15EF08D7A0F34B1305D87F104 ();
// 0x000000CE System.Void ShootReward::ShowRewardedVideo()
extern void ShootReward_ShowRewardedVideo_m08DEEF32A4D1BEC80F133A9D15B5463D39EF6EE9 ();
// 0x000000CF System.Void ShootReward::OnUnityAdsReady(System.String)
extern void ShootReward_OnUnityAdsReady_mE13D5B061DD03FE97F1BC802713A0E1B8B3FCF78 ();
// 0x000000D0 System.Void ShootReward::OnUnityAdsDidFinish(System.String,UnityEngine.Advertisements.ShowResult)
extern void ShootReward_OnUnityAdsDidFinish_mA9F62C02D21A3D74EE187ACC408F7FA9DF41D5CB ();
// 0x000000D1 System.Void ShootReward::OnUnityAdsDidError(System.String)
extern void ShootReward_OnUnityAdsDidError_m2EA4892D7EC6A3650EE7FA590D3514E2BEEB8F65 ();
// 0x000000D2 System.Void ShootReward::OnUnityAdsDidStart(System.String)
extern void ShootReward_OnUnityAdsDidStart_m9DF4B56070646582C0FF14A03E23DB8F422D40F5 ();
// 0x000000D3 System.Void ShootReward::.ctor()
extern void ShootReward__ctor_mD68DE4554D086AA6FE824518F6D6088AF84DAF66 ();
// 0x000000D4 System.Void ShopControl::Start()
extern void ShopControl_Start_mD449C80429C8F6631E8AB1D11F901C20F6DBE3B9 ();
// 0x000000D5 System.Void ShopControl::Update()
extern void ShopControl_Update_m1B5795C33A7CA460263A727367D62E866A7C8A94 ();
// 0x000000D6 System.Void ShopControl::buyVirus()
extern void ShopControl_buyVirus_mB7818C3195A915A236954EB08321C12EA9935809 ();
// 0x000000D7 System.Void ShopControl::resetPlayerPrefs(System.String)
extern void ShopControl_resetPlayerPrefs_mEA1440AC727B3D6CB9569D77EDF4C105027619D5 ();
// 0x000000D8 System.Void ShopControl::.ctor()
extern void ShopControl__ctor_m314EE77699352D462E71DA6E61698CE8B9D66786 ();
// 0x000000D9 System.Void ShotControl::Start()
extern void ShotControl_Start_mD15539B71D300EE63D703FCC5F2CBFEF5F51177C ();
// 0x000000DA System.Void ShotControl::Update()
extern void ShotControl_Update_mCF2882E75CBBF408A0AF210E6BB1C099661E4E64 ();
// 0x000000DB System.Void ShotControl::.ctor()
extern void ShotControl__ctor_mE82B524257A52175FF50654FA99A23F74001F058 ();
// 0x000000DC System.Void Sound::.ctor()
extern void Sound__ctor_m4594F1F1D68380A13C70A564C5C164901D725D44 ();
// 0x000000DD System.Void SoundManager::Start()
extern void SoundManager_Start_mB9D238182CC4B1023DE4C4D331E88EFB7E82F24F ();
// 0x000000DE System.Void SoundManager::Update()
extern void SoundManager_Update_mA43265016234A06D51D1D96DAB646B758F6E4AB6 ();
// 0x000000DF System.Void SoundManager::.ctor()
extern void SoundManager__ctor_mFF8C696A5B666ABC1E2344581FE7FB06E038D422 ();
// 0x000000E0 System.Void Spawner::Start()
extern void Spawner_Start_mEA70C3EA61603E141DD386EC98864D2A80917900 ();
// 0x000000E1 System.Void Spawner::Update()
extern void Spawner_Update_mBBD680767D87C19E6B68AF774A049579F270A44E ();
// 0x000000E2 System.Void Spawner::.ctor()
extern void Spawner__ctor_mA37BC0F6624E147B76FC192F6E53162998BCA0A5 ();
// 0x000000E3 System.Void StartMenu::PlayGame()
extern void StartMenu_PlayGame_mBAEFD143AAD31DD3708C50E90926987448F2E3D6 ();
// 0x000000E4 System.Void StartMenu::PlayHard()
extern void StartMenu_PlayHard_mB49F3E636E8AEDD5718AD935030088CB13FD4422 ();
// 0x000000E5 System.Void StartMenu::PlayCatch()
extern void StartMenu_PlayCatch_m68EFFBEDDEE5B5753EBBCA300CA63D574623606F ();
// 0x000000E6 System.Void StartMenu::Shop()
extern void StartMenu_Shop_m0213CF34B29312A9943DE97F837BFAB9011BADEA ();
// 0x000000E7 System.Void StartMenu::QuitGame()
extern void StartMenu_QuitGame_mD9B21796AA52121FCE4C66E97B0D936A9B053D9A ();
// 0x000000E8 System.Void StartMenu::.ctor()
extern void StartMenu__ctor_mFE9B9682B9BBA1E057D5037188C932B5A77F8CE6 ();
// 0x000000E9 System.Void TMP::Update()
extern void TMP_Update_m585303DE1012952E04D16ACBFFFEB5539F154153 ();
// 0x000000EA System.Void TMP::.ctor()
extern void TMP__ctor_m9A6D959D87D36ADA79D893BC40D35C8916151F98 ();
// 0x000000EB System.Void TestSpawn::Start()
extern void TestSpawn_Start_m32F0390A74FDFA3FDE463E26B042840E6F3E24A9 ();
// 0x000000EC System.Void TestSpawn::spawnEnemy()
extern void TestSpawn_spawnEnemy_mF427E003628BAC54D157E558FE398FBDDA905383 ();
// 0x000000ED System.Collections.IEnumerator TestSpawn::asteroidWave()
extern void TestSpawn_asteroidWave_m6AE9BD629E71D344E7A334B92BB3E638A49CBD8D ();
// 0x000000EE System.Void TestSpawn::.ctor()
extern void TestSpawn__ctor_m3424A5C0772CCE3330276C3370F412059D34D3A2 ();
// 0x000000EF System.Void Virus1::Start()
extern void Virus1_Start_mFC03FAA0B7E45CE03AD1F16C8AABCF78C6385AE7 ();
// 0x000000F0 System.Void Virus1::Update()
extern void Virus1_Update_m7FE96DFD0B6D1B2319F97BFA1F5699664027A913 ();
// 0x000000F1 System.Void Virus1::.ctor()
extern void Virus1__ctor_mDE5F40446549F2B1485A83E2616E99F66B7058FB ();
// 0x000000F2 System.Void Weapon::Update()
extern void Weapon_Update_mD65E9FD544FEE0974CED54FA39BB05A89FB6D99E ();
// 0x000000F3 System.Void Weapon::Shoot()
extern void Weapon_Shoot_mF5B36E6C4428C1E8858F42526F5EEC7C7AF9D4E3 ();
// 0x000000F4 System.Void Weapon::.ctor()
extern void Weapon__ctor_mF7C215ECC1D7032E6DE76DE606A9159F840B62FB ();
// 0x000000F5 System.Void back::BackButton()
extern void back_BackButton_mDC05AAD2E262033B6374481666A6487078014694 ();
// 0x000000F6 System.Void back::.ctor()
extern void back__ctor_mAEA62A3E124D04834F2C88189BAB1C27158D0D1A ();
// 0x000000F7 System.Void bomb::Start()
extern void bomb_Start_mA57F25109EAD258B089DB14F86774E77DD37DE31 ();
// 0x000000F8 System.Void bomb::OnTriggerEnter2D(UnityEngine.Collider2D)
extern void bomb_OnTriggerEnter2D_m8530B9067160E6E77CB6C2D531FB428380A8DDFE ();
// 0x000000F9 System.Void bomb::.ctor()
extern void bomb__ctor_m9FD2695E5549D32964B3D6D4984E0C9EBF65F23D ();
// 0x000000FA System.Void catchDoubler::Start()
extern void catchDoubler_Start_m01C00C4BB40342C83BC3A542135F8AA69E31CBFA ();
// 0x000000FB System.Void catchDoubler::Update()
extern void catchDoubler_Update_m1741DC6DDB78BBE3146C0FAFF0DF04533E1D2B60 ();
// 0x000000FC System.Void catchDoubler::.ctor()
extern void catchDoubler__ctor_m89A0C44885A58C4568C728A3EF6E65DB20F352B5 ();
// 0x000000FD System.Void coin::Start()
extern void coin_Start_mE53E845441EF04E468CF50496C6A8828694EA296 ();
// 0x000000FE System.Void coin::OnTriggerEnter2D(UnityEngine.Collider2D)
extern void coin_OnTriggerEnter2D_m6E3D7A0080F1C1EB62DE1B54344FD606FCEF9CF4 ();
// 0x000000FF System.Void coin::.ctor()
extern void coin__ctor_mEEB2E0AE11DFC930658FFA5DF694A494C6E4C789 ();
// 0x00000100 System.Void doubler::Start()
extern void doubler_Start_m407F74D273BEF373109EC321360F27F064BFD444 ();
// 0x00000101 System.Void doubler::OnTriggerEnter2D(UnityEngine.Collider2D)
extern void doubler_OnTriggerEnter2D_m9F181ABDF4A940D4108DC95A6810694796F467D0 ();
// 0x00000102 System.Void doubler::.ctor()
extern void doubler__ctor_m38F0150C162CEC7080076A6E4D1E8042BBFC5827 ();
// 0x00000103 System.Void freeze::Start()
extern void freeze_Start_mBE48C56A85921EE0D9C7C531AF17F287FA5228D6 ();
// 0x00000104 System.Void freeze::OnTriggerEnter2D(UnityEngine.Collider2D)
extern void freeze_OnTriggerEnter2D_mBE189F6624A8D5DF78A07208CA748E473FB7B716 ();
// 0x00000105 System.Void freeze::.ctor()
extern void freeze__ctor_m400C3D97ECF7CAF42C0162C5B75E78DC31319F7F ();
// 0x00000106 System.Void restartCatch::RestartGame()
extern void restartCatch_RestartGame_m6F29261CB6B68A3F1294DF4E40C9510A9E8BE93A ();
// 0x00000107 System.Void restartCatch::.ctor()
extern void restartCatch__ctor_m24EE53F73CAFFCCF1E7A34413FF586D5D0E92088 ();
// 0x00000108 System.Void SettingsMenu::SetVolume(System.Single)
extern void SettingsMenu_SetVolume_m8EBB34A1A9F07559F73F8EFE957B3771D54756FC ();
// 0x00000109 System.Void SettingsMenu::.ctor()
extern void SettingsMenu__ctor_m038E1040393AAD26365313BCF704FB6FF638D065 ();
// 0x0000010A System.Void ChatController::OnEnable()
extern void ChatController_OnEnable_m168B1E78BFA288F42D4AE0A8F1424B8D68B07993 ();
// 0x0000010B System.Void ChatController::OnDisable()
extern void ChatController_OnDisable_m49C4A6501BCC216F924B3C37F243D1B5B54A69FF ();
// 0x0000010C System.Void ChatController::AddToChatOutput(System.String)
extern void ChatController_AddToChatOutput_m5E6DF0E37CB2E9FBBEACCB6EEE6452AB14BBE94C ();
// 0x0000010D System.Void ChatController::.ctor()
extern void ChatController__ctor_m2C7AAB67386BA2DC6742585988B914B3FAB30013 ();
// 0x0000010E System.Void DropdownSample::OnButtonClick()
extern void DropdownSample_OnButtonClick_mEAC0F8D33D13DE84DCEA5D99E5162E4D28F6B54D ();
// 0x0000010F System.Void DropdownSample::.ctor()
extern void DropdownSample__ctor_m901DB807D4DFA75581306389B7A21072E98E72A0 ();
// 0x00000110 System.Void EnvMapAnimator::Awake()
extern void EnvMapAnimator_Awake_mDDD10A405C7152BEFA0ECEA0DCBD061B47C5802E ();
// 0x00000111 System.Collections.IEnumerator EnvMapAnimator::Start()
extern void EnvMapAnimator_Start_m630E0BFAB4D647BC38B99A70F522EF80D25F3C71 ();
// 0x00000112 System.Void EnvMapAnimator::.ctor()
extern void EnvMapAnimator__ctor_m2A8770DA2E27EC52F6A6F704831B732638C76E84 ();
// 0x00000113 System.Void WinGame::WinIt()
extern void WinGame_WinIt_m80DCFEEEBB7E4BA6CFA653204C0AD2F6DDBE2379 ();
// 0x00000114 System.Void WinGame::ReturnIt()
extern void WinGame_ReturnIt_m2587EDAA56355D4EA808CA1F6A5F87249CF47542 ();
// 0x00000115 System.Void WinGame::.ctor()
extern void WinGame__ctor_mA8DA79C5B3918EC310D2899B22AF6B11976FE2CA ();
// 0x00000116 System.Char TMPro.TMP_DigitValidator::Validate(System.String&,System.Int32&,System.Char)
extern void TMP_DigitValidator_Validate_mEC7653F2228D8AA66F69D6B3539ED342AEE57691 ();
// 0x00000117 System.Void TMPro.TMP_DigitValidator::.ctor()
extern void TMP_DigitValidator__ctor_m4E1C1BEB96F76F2EE55E6FEC45D05F2AAC5DF325 ();
// 0x00000118 System.Char TMPro.TMP_PhoneNumberValidator::Validate(System.String&,System.Int32&,System.Char)
extern void TMP_PhoneNumberValidator_Validate_mBE0169BE01459AA37111A289EC422DDB0D5E3479 ();
// 0x00000119 System.Void TMPro.TMP_PhoneNumberValidator::.ctor()
extern void TMP_PhoneNumberValidator__ctor_mBF81DE006E19E49DAC3AFF685F8AF268A2FD0FFB ();
// 0x0000011A TMPro.TMP_TextEventHandler_CharacterSelectionEvent TMPro.TMP_TextEventHandler::get_onCharacterSelection()
extern void TMP_TextEventHandler_get_onCharacterSelection_mF70DBE3FF43B3D6E64053D37A2FADF802533E1FF ();
// 0x0000011B System.Void TMPro.TMP_TextEventHandler::set_onCharacterSelection(TMPro.TMP_TextEventHandler_CharacterSelectionEvent)
extern void TMP_TextEventHandler_set_onCharacterSelection_mDEC285B6A284CC2EC9729E3DC16E81A182890D21 ();
// 0x0000011C TMPro.TMP_TextEventHandler_SpriteSelectionEvent TMPro.TMP_TextEventHandler::get_onSpriteSelection()
extern void TMP_TextEventHandler_get_onSpriteSelection_m395603314F8CD073897DCAB5513270C6ADD94BF4 ();
// 0x0000011D System.Void TMPro.TMP_TextEventHandler::set_onSpriteSelection(TMPro.TMP_TextEventHandler_SpriteSelectionEvent)
extern void TMP_TextEventHandler_set_onSpriteSelection_m3D4E17778B0E3CC987A3EF74515E83CE39E3C094 ();
// 0x0000011E TMPro.TMP_TextEventHandler_WordSelectionEvent TMPro.TMP_TextEventHandler::get_onWordSelection()
extern void TMP_TextEventHandler_get_onWordSelection_m415F4479934B1739658356B47DF4C2E90496AE2E ();
// 0x0000011F System.Void TMPro.TMP_TextEventHandler::set_onWordSelection(TMPro.TMP_TextEventHandler_WordSelectionEvent)
extern void TMP_TextEventHandler_set_onWordSelection_m2EDD56E0024792DCE7F068228B4CA5A897808F4E ();
// 0x00000120 TMPro.TMP_TextEventHandler_LineSelectionEvent TMPro.TMP_TextEventHandler::get_onLineSelection()
extern void TMP_TextEventHandler_get_onLineSelection_m8E724700CC5DF1197B103F87156576A52F62AB2B ();
// 0x00000121 System.Void TMPro.TMP_TextEventHandler::set_onLineSelection(TMPro.TMP_TextEventHandler_LineSelectionEvent)
extern void TMP_TextEventHandler_set_onLineSelection_m067512B3F057A225AF6DD251DD7E546FFF64CD93 ();
// 0x00000122 TMPro.TMP_TextEventHandler_LinkSelectionEvent TMPro.TMP_TextEventHandler::get_onLinkSelection()
extern void TMP_TextEventHandler_get_onLinkSelection_m221527467F0606DD3561E0FB0D7678AA8329AD5D ();
// 0x00000123 System.Void TMPro.TMP_TextEventHandler::set_onLinkSelection(TMPro.TMP_TextEventHandler_LinkSelectionEvent)
extern void TMP_TextEventHandler_set_onLinkSelection_mE3CE372F9FECD727FAB3B14D46439E0534EE8AA8 ();
// 0x00000124 System.Void TMPro.TMP_TextEventHandler::Awake()
extern void TMP_TextEventHandler_Awake_m67A37475531AC3EB75B43A640058AD52A605B8D9 ();
// 0x00000125 System.Void TMPro.TMP_TextEventHandler::LateUpdate()
extern void TMP_TextEventHandler_LateUpdate_mB0ABBED08D5494DFFF85D9B56D4446D96DDBDDF5 ();
// 0x00000126 System.Void TMPro.TMP_TextEventHandler::OnPointerEnter(UnityEngine.EventSystems.PointerEventData)
extern void TMP_TextEventHandler_OnPointerEnter_mE1CAF8C68C2356069FEB1AA1B53A56E24E5CE333 ();
// 0x00000127 System.Void TMPro.TMP_TextEventHandler::OnPointerExit(UnityEngine.EventSystems.PointerEventData)
extern void TMP_TextEventHandler_OnPointerExit_mB429546A32DCF6C8C64E703D07F9F1CDC697B009 ();
// 0x00000128 System.Void TMPro.TMP_TextEventHandler::SendOnCharacterSelection(System.Char,System.Int32)
extern void TMP_TextEventHandler_SendOnCharacterSelection_mFBFC60A83107F26AA351246C10AB42CEB3A5A13C ();
// 0x00000129 System.Void TMPro.TMP_TextEventHandler::SendOnSpriteSelection(System.Char,System.Int32)
extern void TMP_TextEventHandler_SendOnSpriteSelection_mAB964EB5171AB07C48AC64E06C6BEC6A9C323E09 ();
// 0x0000012A System.Void TMPro.TMP_TextEventHandler::SendOnWordSelection(System.String,System.Int32,System.Int32)
extern void TMP_TextEventHandler_SendOnWordSelection_m3B76D7E79C65DB9D8E09EE834252C6E33C86D3AE ();
// 0x0000012B System.Void TMPro.TMP_TextEventHandler::SendOnLineSelection(System.String,System.Int32,System.Int32)
extern void TMP_TextEventHandler_SendOnLineSelection_m9E9CAD5FA36FCA342A38EBD43E609A469E49F15F ();
// 0x0000012C System.Void TMPro.TMP_TextEventHandler::SendOnLinkSelection(System.String,System.String,System.Int32)
extern void TMP_TextEventHandler_SendOnLinkSelection_m1C55C664BB488E25AE746B99438EEDAE5B2B8DE8 ();
// 0x0000012D System.Void TMPro.TMP_TextEventHandler::.ctor()
extern void TMP_TextEventHandler__ctor_m189A5951F5C0FA5FB1D0CFC461FAA1EBD7AED1AE ();
// 0x0000012E System.Collections.IEnumerator TMPro.Examples.Benchmark01::Start()
extern void Benchmark01_Start_m20668FA5AD3945F18B5045459057C330E0B4D1F4 ();
// 0x0000012F System.Void TMPro.Examples.Benchmark01::.ctor()
extern void Benchmark01__ctor_m40EDCD3A3B6E8651A39C2220669A7689902C8B36 ();
// 0x00000130 System.Collections.IEnumerator TMPro.Examples.Benchmark01_UGUI::Start()
extern void Benchmark01_UGUI_Start_mE8F5BC98EC6C16ECEBAD0FD78CD63E278B2DF215 ();
// 0x00000131 System.Void TMPro.Examples.Benchmark01_UGUI::.ctor()
extern void Benchmark01_UGUI__ctor_m7F24B3D019827130B3D5F2D3E8C3FF23425F98BE ();
// 0x00000132 System.Void TMPro.Examples.Benchmark02::Start()
extern void Benchmark02_Start_m3F848191079D3EF1E3B785830D74698325CA0BB7 ();
// 0x00000133 System.Void TMPro.Examples.Benchmark02::.ctor()
extern void Benchmark02__ctor_m3323414B806F63563E680918CC90EAF766A3D1AE ();
// 0x00000134 System.Void TMPro.Examples.Benchmark03::Awake()
extern void Benchmark03_Awake_m261B7F2CD25DC9E7144B2A2D167219A751AD9322 ();
// 0x00000135 System.Void TMPro.Examples.Benchmark03::Start()
extern void Benchmark03_Start_m649EFCC5BF0F199D102083583854DE87AC5EFBDD ();
// 0x00000136 System.Void TMPro.Examples.Benchmark03::.ctor()
extern void Benchmark03__ctor_m90649FDE30CC915363C5B61AA19A7DE874FF18ED ();
// 0x00000137 System.Void TMPro.Examples.Benchmark04::Start()
extern void Benchmark04_Start_mFDF88CB6DD4C5641A418DB08E105F9F62B897777 ();
// 0x00000138 System.Void TMPro.Examples.Benchmark04::.ctor()
extern void Benchmark04__ctor_mB07A2FD29BE4AFE284B47F2F610BDB7539F5A5DE ();
// 0x00000139 System.Void TMPro.Examples.CameraController::Awake()
extern void CameraController_Awake_m5E24687E6D82C0EBC4984D01B90769B8FD8C38B3 ();
// 0x0000013A System.Void TMPro.Examples.CameraController::Start()
extern void CameraController_Start_m257B81C6062A725785739AFE4C0DF84B8931EFB2 ();
// 0x0000013B System.Void TMPro.Examples.CameraController::LateUpdate()
extern void CameraController_LateUpdate_m9660F57BCF4F8C2154D19B6B40208466E414DAEB ();
// 0x0000013C System.Void TMPro.Examples.CameraController::GetPlayerInput()
extern void CameraController_GetPlayerInput_m0B63EA708A63AF6852E099FD40F7C4E18793560A ();
// 0x0000013D System.Void TMPro.Examples.CameraController::.ctor()
extern void CameraController__ctor_m8379776EEE21556D56845974B8C505AAD366B656 ();
// 0x0000013E System.Void TMPro.Examples.ObjectSpin::Awake()
extern void ObjectSpin_Awake_m2E5B2D7FA6FE2F3B5516BD829EDC5522187E6359 ();
// 0x0000013F System.Void TMPro.Examples.ObjectSpin::Update()
extern void ObjectSpin_Update_mF8175B9157B852D3EC1BAF19D168858A8782BF0D ();
// 0x00000140 System.Void TMPro.Examples.ObjectSpin::.ctor()
extern void ObjectSpin__ctor_m1F951082C07A983F89779737E5A6071DD7BA67EB ();
// 0x00000141 System.Void TMPro.Examples.ShaderPropAnimator::Awake()
extern void ShaderPropAnimator_Awake_m44ACA60771EECABCB189FC78027D4ECD9726D31A ();
// 0x00000142 System.Void TMPro.Examples.ShaderPropAnimator::Start()
extern void ShaderPropAnimator_Start_m57178B42FF0BB90ACA497EC1AA942CC3D4D54C32 ();
// 0x00000143 System.Collections.IEnumerator TMPro.Examples.ShaderPropAnimator::AnimateProperties()
extern void ShaderPropAnimator_AnimateProperties_mB34C25C714FAEA4792465A981BAE46778C4F2409 ();
// 0x00000144 System.Void TMPro.Examples.ShaderPropAnimator::.ctor()
extern void ShaderPropAnimator__ctor_mDFAE260FD15CD3E704E86A25A57880A33B817BC6 ();
// 0x00000145 System.Void TMPro.Examples.SimpleScript::Start()
extern void SimpleScript_Start_m0238BE0F5DF0A15743D4D4B1B64C0A86505D1B76 ();
// 0x00000146 System.Void TMPro.Examples.SimpleScript::Update()
extern void SimpleScript_Update_mB92D578CAC3E0A0AFB055C7FEF47601C8822A0F8 ();
// 0x00000147 System.Void TMPro.Examples.SimpleScript::.ctor()
extern void SimpleScript__ctor_m0E919E8F3C12BAFF36B17E5692FCFA5AE602B2AA ();
// 0x00000148 System.Void TMPro.Examples.SkewTextExample::Awake()
extern void SkewTextExample_Awake_mC70E117C1F921453D2F448CABA234FAA17A277ED ();
// 0x00000149 System.Void TMPro.Examples.SkewTextExample::Start()
extern void SkewTextExample_Start_mE2308836BF90B959ABE6064CD2DDDFAF224F0F4A ();
// 0x0000014A UnityEngine.AnimationCurve TMPro.Examples.SkewTextExample::CopyAnimationCurve(UnityEngine.AnimationCurve)
extern void SkewTextExample_CopyAnimationCurve_m3CE7B666BEF4CFFE9EB110C8D57D9A5F6385720B ();
// 0x0000014B System.Collections.IEnumerator TMPro.Examples.SkewTextExample::WarpText()
extern void SkewTextExample_WarpText_m8B756AF1E1C065EEA486159E6C631A585B0C3461 ();
// 0x0000014C System.Void TMPro.Examples.SkewTextExample::.ctor()
extern void SkewTextExample__ctor_m44F3CBD12A19C44A000D705FB4AB02E20432EC02 ();
// 0x0000014D System.Void TMPro.Examples.TMP_ExampleScript_01::Awake()
extern void TMP_ExampleScript_01_Awake_mE2AAB8DF142D7BDB2C041CC7552A48745DBFDCFF ();
// 0x0000014E System.Void TMPro.Examples.TMP_ExampleScript_01::Update()
extern void TMP_ExampleScript_01_Update_m1593A7650860FD2A478E10EA12A2601E918DD1EC ();
// 0x0000014F System.Void TMPro.Examples.TMP_ExampleScript_01::.ctor()
extern void TMP_ExampleScript_01__ctor_m313B4F7ED747AD6979D8909858D0EF182C79BBC3 ();
// 0x00000150 System.Void TMPro.Examples.TMP_FrameRateCounter::Awake()
extern void TMP_FrameRateCounter_Awake_m2540DCD733523BCBB1757724D8546AC3F1BEB16C ();
// 0x00000151 System.Void TMPro.Examples.TMP_FrameRateCounter::Start()
extern void TMP_FrameRateCounter_Start_mEF10D80C419582C6944313FD100E2FD1C5AD1319 ();
// 0x00000152 System.Void TMPro.Examples.TMP_FrameRateCounter::Update()
extern void TMP_FrameRateCounter_Update_mF4798814F4F86850BB9248CA192EF5B65FA3A92B ();
// 0x00000153 System.Void TMPro.Examples.TMP_FrameRateCounter::Set_FrameCounter_Position(TMPro.Examples.TMP_FrameRateCounter_FpsCounterAnchorPositions)
extern void TMP_FrameRateCounter_Set_FrameCounter_Position_m19C3C5E637FB3ED2B0869E7650A1C30A3302AF53 ();
// 0x00000154 System.Void TMPro.Examples.TMP_FrameRateCounter::.ctor()
extern void TMP_FrameRateCounter__ctor_m55E3726473BA4825AC0B7B7B7EA48D0C5CE8D646 ();
// 0x00000155 System.Void TMPro.Examples.TMP_TextEventCheck::OnEnable()
extern void TMP_TextEventCheck_OnEnable_mAFF9E7581B7B0C93A4A7D811C978FFCEC87B3784 ();
// 0x00000156 System.Void TMPro.Examples.TMP_TextEventCheck::OnDisable()
extern void TMP_TextEventCheck_OnDisable_m270DBB9CC93731104E851797D6BF55EACAE9158A ();
// 0x00000157 System.Void TMPro.Examples.TMP_TextEventCheck::OnCharacterSelection(System.Char,System.Int32)
extern void TMP_TextEventCheck_OnCharacterSelection_m4394BE3A0CA37D319AA10BE200A26CFD17EEAA8F ();
// 0x00000158 System.Void TMPro.Examples.TMP_TextEventCheck::OnSpriteSelection(System.Char,System.Int32)
extern void TMP_TextEventCheck_OnSpriteSelection_mCBF0B6754C607CA140C405FF5B681154AC861992 ();
// 0x00000159 System.Void TMPro.Examples.TMP_TextEventCheck::OnWordSelection(System.String,System.Int32,System.Int32)
extern void TMP_TextEventCheck_OnWordSelection_m4C290E23BBA708FE259A5F53921B7B98480E5B08 ();
// 0x0000015A System.Void TMPro.Examples.TMP_TextEventCheck::OnLineSelection(System.String,System.Int32,System.Int32)
extern void TMP_TextEventCheck_OnLineSelection_mF68BE3244AFD53E84E037B39443B5B3B50336FF5 ();
// 0x0000015B System.Void TMPro.Examples.TMP_TextEventCheck::OnLinkSelection(System.String,System.String,System.Int32)
extern void TMP_TextEventCheck_OnLinkSelection_m23569DD32B2D3C4599B8D855AE89178C92BA25C7 ();
// 0x0000015C System.Void TMPro.Examples.TMP_TextEventCheck::.ctor()
extern void TMP_TextEventCheck__ctor_m4B49D7387750432FA7A15A804ABD6793422E0632 ();
// 0x0000015D System.Void TMPro.Examples.TMP_TextInfoDebugTool::.ctor()
extern void TMP_TextInfoDebugTool__ctor_m2A2D1B42F97BD424B7C61813B83FE46C91575EFB ();
// 0x0000015E System.Void TMPro.Examples.TMP_TextSelector_A::Awake()
extern void TMP_TextSelector_A_Awake_mEE6FCD85F7A6FDA4CC3B51173865E53F010AB0FF ();
// 0x0000015F System.Void TMPro.Examples.TMP_TextSelector_A::LateUpdate()
extern void TMP_TextSelector_A_LateUpdate_mF02F95A5D14806665404997F9ABAEE288A9879A0 ();
// 0x00000160 System.Void TMPro.Examples.TMP_TextSelector_A::OnPointerEnter(UnityEngine.EventSystems.PointerEventData)
extern void TMP_TextSelector_A_OnPointerEnter_m6D15B2FC399C52D9706DD85C796BAE40CA8362D3 ();
// 0x00000161 System.Void TMPro.Examples.TMP_TextSelector_A::OnPointerExit(UnityEngine.EventSystems.PointerEventData)
extern void TMP_TextSelector_A_OnPointerExit_m080D05700B1D3251085331369FCD2A131D45F963 ();
// 0x00000162 System.Void TMPro.Examples.TMP_TextSelector_A::.ctor()
extern void TMP_TextSelector_A__ctor_m6AB8BC86973365C192CF9EACA61459F2E0A5C88D ();
// 0x00000163 System.Void TMPro.Examples.TMP_TextSelector_B::Awake()
extern void TMP_TextSelector_B_Awake_m87D2FCFCEDEE1FA82DEF77A867D2DE56C3AA0973 ();
// 0x00000164 System.Void TMPro.Examples.TMP_TextSelector_B::OnEnable()
extern void TMP_TextSelector_B_OnEnable_mD1C87684FD94190654176B38EE7DC960795F08E8 ();
// 0x00000165 System.Void TMPro.Examples.TMP_TextSelector_B::OnDisable()
extern void TMP_TextSelector_B_OnDisable_m429F83E18507E278CA9E9B5A2AE891087ED0D830 ();
// 0x00000166 System.Void TMPro.Examples.TMP_TextSelector_B::ON_TEXT_CHANGED(UnityEngine.Object)
extern void TMP_TextSelector_B_ON_TEXT_CHANGED_m91D0E180681C5566066C366487B94A05FB376B12 ();
// 0x00000167 System.Void TMPro.Examples.TMP_TextSelector_B::LateUpdate()
extern void TMP_TextSelector_B_LateUpdate_m80F8343FAB19617468E94CD2B35636DBB9AC2064 ();
// 0x00000168 System.Void TMPro.Examples.TMP_TextSelector_B::OnPointerEnter(UnityEngine.EventSystems.PointerEventData)
extern void TMP_TextSelector_B_OnPointerEnter_m9A938ED5B0D70633B9099F5C1B213FD50380116D ();
// 0x00000169 System.Void TMPro.Examples.TMP_TextSelector_B::OnPointerExit(UnityEngine.EventSystems.PointerEventData)
extern void TMP_TextSelector_B_OnPointerExit_mD481099225DF156CA7CA904AA1C81AF26A974D28 ();
// 0x0000016A System.Void TMPro.Examples.TMP_TextSelector_B::OnPointerClick(UnityEngine.EventSystems.PointerEventData)
extern void TMP_TextSelector_B_OnPointerClick_mE4A6507E55DD05BBC99F81212CF26F2F11179FBE ();
// 0x0000016B System.Void TMPro.Examples.TMP_TextSelector_B::OnPointerUp(UnityEngine.EventSystems.PointerEventData)
extern void TMP_TextSelector_B_OnPointerUp_m5E52652A02A561F2E8AB7F0C00E280C76A090F74 ();
// 0x0000016C System.Void TMPro.Examples.TMP_TextSelector_B::RestoreCachedVertexAttributes(System.Int32)
extern void TMP_TextSelector_B_RestoreCachedVertexAttributes_m01B9A1E989D57BE8837E99C4359BCB6DD847CB35 ();
// 0x0000016D System.Void TMPro.Examples.TMP_TextSelector_B::.ctor()
extern void TMP_TextSelector_B__ctor_mC42D87810C72234A3360C0965CC1B7F45AB4EE26 ();
// 0x0000016E System.Void TMPro.Examples.TMP_UiFrameRateCounter::Awake()
extern void TMP_UiFrameRateCounter_Awake_mFAF9F495C66394DC36E9C6BC96C9E880C4A3B0A9 ();
// 0x0000016F System.Void TMPro.Examples.TMP_UiFrameRateCounter::Start()
extern void TMP_UiFrameRateCounter_Start_mC4A3331333B1DFA82B184A0701FCE26395B8D301 ();
// 0x00000170 System.Void TMPro.Examples.TMP_UiFrameRateCounter::Update()
extern void TMP_UiFrameRateCounter_Update_mCA98BB5342C50F9CE247A858E1942410537E0DAF ();
// 0x00000171 System.Void TMPro.Examples.TMP_UiFrameRateCounter::Set_FrameCounter_Position(TMPro.Examples.TMP_UiFrameRateCounter_FpsCounterAnchorPositions)
extern void TMP_UiFrameRateCounter_Set_FrameCounter_Position_mDD0EAB08CE58340555A6654BDD5BEE015E6C6ACE ();
// 0x00000172 System.Void TMPro.Examples.TMP_UiFrameRateCounter::.ctor()
extern void TMP_UiFrameRateCounter__ctor_mE3DC8B24D2819C55B66AEAEB9C9B93AFDA9C4573 ();
// 0x00000173 System.Void TMPro.Examples.TMPro_InstructionOverlay::Awake()
extern void TMPro_InstructionOverlay_Awake_m951573D9BF0200A4C4605E043E92BBD2EB33BA7C ();
// 0x00000174 System.Void TMPro.Examples.TMPro_InstructionOverlay::Set_FrameCounter_Position(TMPro.Examples.TMPro_InstructionOverlay_FpsCounterAnchorPositions)
extern void TMPro_InstructionOverlay_Set_FrameCounter_Position_m39D0BB71DCCB67271B96F8A9082D7638E4E1A694 ();
// 0x00000175 System.Void TMPro.Examples.TMPro_InstructionOverlay::.ctor()
extern void TMPro_InstructionOverlay__ctor_m103EF0B8818B248077CB97909BA806477DCEB8A5 ();
// 0x00000176 System.Void TMPro.Examples.TeleType::Awake()
extern void TeleType_Awake_m3501F8FA1B762D22972B9B2BAC1E20561088882B ();
// 0x00000177 System.Collections.IEnumerator TMPro.Examples.TeleType::Start()
extern void TeleType_Start_m2A3F19E0F9F2C72D48DDF5A4208AF18AE7769E69 ();
// 0x00000178 System.Void TMPro.Examples.TeleType::.ctor()
extern void TeleType__ctor_m8B985E4023A01F963A74E0FE5E8758B979FB3C3A ();
// 0x00000179 System.Void TMPro.Examples.TextConsoleSimulator::Awake()
extern void TextConsoleSimulator_Awake_m8B1E7254BFB2D0C7D5A803AEFAFCD1B5327F79AD ();
// 0x0000017A System.Void TMPro.Examples.TextConsoleSimulator::Start()
extern void TextConsoleSimulator_Start_m85E6334AFE22350A5715F9E45843FD865EF60C9D ();
// 0x0000017B System.Void TMPro.Examples.TextConsoleSimulator::OnEnable()
extern void TextConsoleSimulator_OnEnable_mB6F523D582FE4789A5B95C086AA7C168A5DD5AF7 ();
// 0x0000017C System.Void TMPro.Examples.TextConsoleSimulator::OnDisable()
extern void TextConsoleSimulator_OnDisable_m1EF25B5345586DD26BB8615624358EFB21B485DB ();
// 0x0000017D System.Void TMPro.Examples.TextConsoleSimulator::ON_TEXT_CHANGED(UnityEngine.Object)
extern void TextConsoleSimulator_ON_TEXT_CHANGED_mD4A85AE6FE4CD3AFF790859DEFB7E4AAF9304AE5 ();
// 0x0000017E System.Collections.IEnumerator TMPro.Examples.TextConsoleSimulator::RevealCharacters(TMPro.TMP_Text)
extern void TextConsoleSimulator_RevealCharacters_m7BF445A3B7B6A259450593775D10DE0D4BD901AD ();
// 0x0000017F System.Collections.IEnumerator TMPro.Examples.TextConsoleSimulator::RevealWords(TMPro.TMP_Text)
extern void TextConsoleSimulator_RevealWords_mD7D62A1D326528506154148148166B9196A9B903 ();
// 0x00000180 System.Void TMPro.Examples.TextConsoleSimulator::.ctor()
extern void TextConsoleSimulator__ctor_mA40DB76E1D63318E646CF2AE921084D0FDF4C3CA ();
// 0x00000181 System.Void TMPro.Examples.TextMeshProFloatingText::Awake()
extern void TextMeshProFloatingText_Awake_mB40A823A322B9EFD776230600A131BAE996580C3 ();
// 0x00000182 System.Void TMPro.Examples.TextMeshProFloatingText::Start()
extern void TextMeshProFloatingText_Start_mBFC04A0247294E62BD58CB3AC83F85AE61C3FB4F ();
// 0x00000183 System.Collections.IEnumerator TMPro.Examples.TextMeshProFloatingText::DisplayTextMeshProFloatingText()
extern void TextMeshProFloatingText_DisplayTextMeshProFloatingText_mB0DEABA5CC4A6B556D76ED30A3CF08E7F0B42AFC ();
// 0x00000184 System.Collections.IEnumerator TMPro.Examples.TextMeshProFloatingText::DisplayTextMeshFloatingText()
extern void TextMeshProFloatingText_DisplayTextMeshFloatingText_m8AB7E0B8313124F67FEDE857012B9E56397147E2 ();
// 0x00000185 System.Void TMPro.Examples.TextMeshProFloatingText::.ctor()
extern void TextMeshProFloatingText__ctor_m610430DD6E4FD84EBF6C499FB4415B5000109627 ();
// 0x00000186 System.Void TMPro.Examples.TextMeshSpawner::Awake()
extern void TextMeshSpawner_Awake_m31920E8DD53AD295AAD8B259391A28E1A57862ED ();
// 0x00000187 System.Void TMPro.Examples.TextMeshSpawner::Start()
extern void TextMeshSpawner_Start_m189316ED7CD62EFD10B40A23E4072C2CEB5A516B ();
// 0x00000188 System.Void TMPro.Examples.TextMeshSpawner::.ctor()
extern void TextMeshSpawner__ctor_m3995DDE2D7E7CBF8087A3B61242F35E09AC94668 ();
// 0x00000189 System.Void TMPro.Examples.VertexColorCycler::Awake()
extern void VertexColorCycler_Awake_m19D37F0DDC4E1D64EA67101852383862DCAAED1E ();
// 0x0000018A System.Void TMPro.Examples.VertexColorCycler::Start()
extern void VertexColorCycler_Start_m2CFBFF7F45A76D16C29B570E3468AFEEC2D1C443 ();
// 0x0000018B System.Collections.IEnumerator TMPro.Examples.VertexColorCycler::AnimateVertexColors()
extern void VertexColorCycler_AnimateVertexColors_mDB7F380B912148C792F857E42BFB042C6A267260 ();
// 0x0000018C System.Void TMPro.Examples.VertexColorCycler::.ctor()
extern void VertexColorCycler__ctor_mBAF42937750A7A22DB5BF09823489FDE25375816 ();
// 0x0000018D System.Void TMPro.Examples.VertexJitter::Awake()
extern void VertexJitter_Awake_m32ACAC43EDE2595CD4FFB6802D58DEBC0F65B52C ();
// 0x0000018E System.Void TMPro.Examples.VertexJitter::OnEnable()
extern void VertexJitter_OnEnable_m63CC97434F60690EE234794C9C2AD3B25EC69486 ();
// 0x0000018F System.Void TMPro.Examples.VertexJitter::OnDisable()
extern void VertexJitter_OnDisable_mE5E221B893D3E53F3A9516082E2C4A9BE174DDF5 ();
// 0x00000190 System.Void TMPro.Examples.VertexJitter::Start()
extern void VertexJitter_Start_mC977D71742279824F9DD719DD1F5CB10269BC531 ();
// 0x00000191 System.Void TMPro.Examples.VertexJitter::ON_TEXT_CHANGED(UnityEngine.Object)
extern void VertexJitter_ON_TEXT_CHANGED_mE5AE5146D67DA15512283617C41F194AEDD6A4AC ();
// 0x00000192 System.Collections.IEnumerator TMPro.Examples.VertexJitter::AnimateVertexColors()
extern void VertexJitter_AnimateVertexColors_m6B361C3B93A2CC219B98AACFC59288432EE6AC1E ();
// 0x00000193 System.Void TMPro.Examples.VertexJitter::.ctor()
extern void VertexJitter__ctor_mD5B5049BB3640662DD69EB1E14789891E8B2E720 ();
// 0x00000194 System.Void TMPro.Examples.VertexShakeA::Awake()
extern void VertexShakeA_Awake_m6075DA429A021C8CB3F6BE9A8B9C64127288CD19 ();
// 0x00000195 System.Void TMPro.Examples.VertexShakeA::OnEnable()
extern void VertexShakeA_OnEnable_m39AA373478F796E7C66763AA163D35811721F5CD ();
// 0x00000196 System.Void TMPro.Examples.VertexShakeA::OnDisable()
extern void VertexShakeA_OnDisable_mA087E96D94CB8213D28D9A601BC25ED784BB8421 ();
// 0x00000197 System.Void TMPro.Examples.VertexShakeA::Start()
extern void VertexShakeA_Start_mDED2AEA47D2E2EF346DE85112420F6E95D9A3CFD ();
// 0x00000198 System.Void TMPro.Examples.VertexShakeA::ON_TEXT_CHANGED(UnityEngine.Object)
extern void VertexShakeA_ON_TEXT_CHANGED_m0B59A798E6B193FE68F6A20E7004B223D5A2993E ();
// 0x00000199 System.Collections.IEnumerator TMPro.Examples.VertexShakeA::AnimateVertexColors()
extern void VertexShakeA_AnimateVertexColors_m238AB73BE06E33312281577CC896CEB7BB175245 ();
// 0x0000019A System.Void TMPro.Examples.VertexShakeA::.ctor()
extern void VertexShakeA__ctor_m41CBBA607D90D45E21C98CCDF347AE27FB50392F ();
// 0x0000019B System.Void TMPro.Examples.VertexShakeB::Awake()
extern void VertexShakeB_Awake_m7CBA45BF5135680A823536A18325ECA621EF7A1A ();
// 0x0000019C System.Void TMPro.Examples.VertexShakeB::OnEnable()
extern void VertexShakeB_OnEnable_m39EBB983A4FFFF6DD1C7923C8C23FF09CFF2F6E2 ();
// 0x0000019D System.Void TMPro.Examples.VertexShakeB::OnDisable()
extern void VertexShakeB_OnDisable_m8E3858FC1C976F311628466C411675E352F134A5 ();
// 0x0000019E System.Void TMPro.Examples.VertexShakeB::Start()
extern void VertexShakeB_Start_m666FA35D389B109F01A5FC229D32664D880ADE09 ();
// 0x0000019F System.Void TMPro.Examples.VertexShakeB::ON_TEXT_CHANGED(UnityEngine.Object)
extern void VertexShakeB_ON_TEXT_CHANGED_mF4858E4385EAA74F5A3008C50B8AD180FCBC8517 ();
// 0x000001A0 System.Collections.IEnumerator TMPro.Examples.VertexShakeB::AnimateVertexColors()
extern void VertexShakeB_AnimateVertexColors_m076A6C9D71EE8B5A54CD1CEDCA5AB15160112DD3 ();
// 0x000001A1 System.Void TMPro.Examples.VertexShakeB::.ctor()
extern void VertexShakeB__ctor_m5CAAD9DFA7B4D9C561473D53CA9E3D8B78AE5606 ();
// 0x000001A2 System.Void TMPro.Examples.VertexZoom::Awake()
extern void VertexZoom_Awake_mB18FF89A84E2AA75BDD486A698955A58E47686EE ();
// 0x000001A3 System.Void TMPro.Examples.VertexZoom::OnEnable()
extern void VertexZoom_OnEnable_mCD27B81253963B3D0CD2F6BA7B161F0DFDC08114 ();
// 0x000001A4 System.Void TMPro.Examples.VertexZoom::OnDisable()
extern void VertexZoom_OnDisable_mB32AD5B7DFF20E682BA4FC82B30C87707DD3BA10 ();
// 0x000001A5 System.Void TMPro.Examples.VertexZoom::Start()
extern void VertexZoom_Start_m6C64C692D81F64FB7F3244C3F0E37799B159A0DE ();
// 0x000001A6 System.Void TMPro.Examples.VertexZoom::ON_TEXT_CHANGED(UnityEngine.Object)
extern void VertexZoom_ON_TEXT_CHANGED_mC08504F9622CC709271C09EDB7A0DF1A35E45768 ();
// 0x000001A7 System.Collections.IEnumerator TMPro.Examples.VertexZoom::AnimateVertexColors()
extern void VertexZoom_AnimateVertexColors_mEC9842E0BC31D9D4E66FD30E6467D5A9A19034D6 ();
// 0x000001A8 System.Void TMPro.Examples.VertexZoom::.ctor()
extern void VertexZoom__ctor_mA4381FC291E17D67EA3C2292EAB8D3C959ADEA79 ();
// 0x000001A9 System.Void TMPro.Examples.WarpTextExample::Awake()
extern void WarpTextExample_Awake_mF6785C4DC8316E573F20A8356393946F6ABFC88C ();
// 0x000001AA System.Void TMPro.Examples.WarpTextExample::Start()
extern void WarpTextExample_Start_m8E7AC9FF62E37EAB89F93FD0C1457555F6DCB086 ();
// 0x000001AB UnityEngine.AnimationCurve TMPro.Examples.WarpTextExample::CopyAnimationCurve(UnityEngine.AnimationCurve)
extern void WarpTextExample_CopyAnimationCurve_m2C738EA265E2B35868110EE1D8FCBD4F1D61C038 ();
// 0x000001AC System.Collections.IEnumerator TMPro.Examples.WarpTextExample::WarpText()
extern void WarpTextExample_WarpText_m27664A46276B3D615ECB12315F5E77C4F2AF29EE ();
// 0x000001AD System.Void TMPro.Examples.WarpTextExample::.ctor()
extern void WarpTextExample__ctor_mF5BA8D140958AD2B5D2C8C5DE937E21A5D283C9F ();
// 0x000001AE System.Void AudioManger_<>c__DisplayClass4_0::.ctor()
extern void U3CU3Ec__DisplayClass4_0__ctor_mD15F906116CC6029665A46B6EADB889EEBD95482 ();
// 0x000001AF System.Boolean AudioManger_<>c__DisplayClass4_0::<Play>b__0(Sound)
extern void U3CU3Ec__DisplayClass4_0_U3CPlayU3Eb__0_mC9DE38DAF580450EE856067B6A57EBC3866414E3 ();
// 0x000001B0 System.Void AudioManger_<>c__DisplayClass5_0::.ctor()
extern void U3CU3Ec__DisplayClass5_0__ctor_m3559510BE1F66D8395B63621884097F380366B1F ();
// 0x000001B1 System.Boolean AudioManger_<>c__DisplayClass5_0::<StopPlaying>b__0(Sound)
extern void U3CU3Ec__DisplayClass5_0_U3CStopPlayingU3Eb__0_m2F4489418F7F6635FA1BDF451174A2B33B9EA5EA ();
// 0x000001B2 System.Void BannerManager_<ShowBannerWhenInitialized>d__4::.ctor(System.Int32)
extern void U3CShowBannerWhenInitializedU3Ed__4__ctor_mC2836E9A9DD80F67F06DA1C5AF7A942F670A1941 ();
// 0x000001B3 System.Void BannerManager_<ShowBannerWhenInitialized>d__4::System.IDisposable.Dispose()
extern void U3CShowBannerWhenInitializedU3Ed__4_System_IDisposable_Dispose_mF1FF864CFDDDD03F48FEA1F3BB4AD250776A15D3 ();
// 0x000001B4 System.Boolean BannerManager_<ShowBannerWhenInitialized>d__4::MoveNext()
extern void U3CShowBannerWhenInitializedU3Ed__4_MoveNext_mA4CBE3C67C3938D22E478FFBD1AF47B3E2BEB442 ();
// 0x000001B5 System.Object BannerManager_<ShowBannerWhenInitialized>d__4::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CShowBannerWhenInitializedU3Ed__4_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mCB2095A6011F88F6C2DABA15E9B42D0099AE8088 ();
// 0x000001B6 System.Void BannerManager_<ShowBannerWhenInitialized>d__4::System.Collections.IEnumerator.Reset()
extern void U3CShowBannerWhenInitializedU3Ed__4_System_Collections_IEnumerator_Reset_m4262E7FE22FDF832A2C0E331EF7EF54AB57CC4AE ();
// 0x000001B7 System.Object BannerManager_<ShowBannerWhenInitialized>d__4::System.Collections.IEnumerator.get_Current()
extern void U3CShowBannerWhenInitializedU3Ed__4_System_Collections_IEnumerator_get_Current_m5710BFA4E6BF78162D2F067D37743871016D811B ();
// 0x000001B8 System.Void DeployVirus_<virusWave>d__5::.ctor(System.Int32)
extern void U3CvirusWaveU3Ed__5__ctor_m9197609079958B4DD50C0063345F58E9B4930537 ();
// 0x000001B9 System.Void DeployVirus_<virusWave>d__5::System.IDisposable.Dispose()
extern void U3CvirusWaveU3Ed__5_System_IDisposable_Dispose_mA9B0B528CB5FAB10EBA85E40D3F269A2F45B3BAF ();
// 0x000001BA System.Boolean DeployVirus_<virusWave>d__5::MoveNext()
extern void U3CvirusWaveU3Ed__5_MoveNext_mA3A368256D44D033056549421218F9AF002AA655 ();
// 0x000001BB System.Object DeployVirus_<virusWave>d__5::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CvirusWaveU3Ed__5_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mD04ED0DEB64C79F77540C864E988F0B1CD3C67BA ();
// 0x000001BC System.Void DeployVirus_<virusWave>d__5::System.Collections.IEnumerator.Reset()
extern void U3CvirusWaveU3Ed__5_System_Collections_IEnumerator_Reset_m92C01568223AA760EC0AD613F219848EF9CFAF40 ();
// 0x000001BD System.Object DeployVirus_<virusWave>d__5::System.Collections.IEnumerator.get_Current()
extern void U3CvirusWaveU3Ed__5_System_Collections_IEnumerator_get_Current_m36D462B71EAC94FAB8B163376D2D34FCC5267204 ();
// 0x000001BE System.Void DestroyTime_<WaitThenRestoreTime>d__5::.ctor(System.Int32)
extern void U3CWaitThenRestoreTimeU3Ed__5__ctor_mA99DB7F931F9EFB1A4C0644EFD077DF8B434040C ();
// 0x000001BF System.Void DestroyTime_<WaitThenRestoreTime>d__5::System.IDisposable.Dispose()
extern void U3CWaitThenRestoreTimeU3Ed__5_System_IDisposable_Dispose_m76E6850E12EB3AD2C74009D7CD1C69A447CF23F4 ();
// 0x000001C0 System.Boolean DestroyTime_<WaitThenRestoreTime>d__5::MoveNext()
extern void U3CWaitThenRestoreTimeU3Ed__5_MoveNext_mB96607326F84C1F6E19C96A3206E77DF4BD59EE3 ();
// 0x000001C1 System.Object DestroyTime_<WaitThenRestoreTime>d__5::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CWaitThenRestoreTimeU3Ed__5_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m0A807B235A231477720E0BCEF3B6CA0898BB4A07 ();
// 0x000001C2 System.Void DestroyTime_<WaitThenRestoreTime>d__5::System.Collections.IEnumerator.Reset()
extern void U3CWaitThenRestoreTimeU3Ed__5_System_Collections_IEnumerator_Reset_m9026594DCEBE5570839D267F771473F4F43DA2CD ();
// 0x000001C3 System.Object DestroyTime_<WaitThenRestoreTime>d__5::System.Collections.IEnumerator.get_Current()
extern void U3CWaitThenRestoreTimeU3Ed__5_System_Collections_IEnumerator_get_Current_mB44EE192736790F1DCFA42A6433354B2C344C2A7 ();
// 0x000001C4 System.Void TestSpawn_<asteroidWave>d__5::.ctor(System.Int32)
extern void U3CasteroidWaveU3Ed__5__ctor_mC75A77524B0F328A32B5E8F8CB69300DCBCD5599 ();
// 0x000001C5 System.Void TestSpawn_<asteroidWave>d__5::System.IDisposable.Dispose()
extern void U3CasteroidWaveU3Ed__5_System_IDisposable_Dispose_mCADB2A23975A0EA92E1968803419AF5E1D6687E3 ();
// 0x000001C6 System.Boolean TestSpawn_<asteroidWave>d__5::MoveNext()
extern void U3CasteroidWaveU3Ed__5_MoveNext_mC0B2C5EEE45D3C3457615B0E1BE7599CC44B0C5E ();
// 0x000001C7 System.Object TestSpawn_<asteroidWave>d__5::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CasteroidWaveU3Ed__5_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m0C2CCC3CF9BA6FF97234D61499A6BD80CF91D413 ();
// 0x000001C8 System.Void TestSpawn_<asteroidWave>d__5::System.Collections.IEnumerator.Reset()
extern void U3CasteroidWaveU3Ed__5_System_Collections_IEnumerator_Reset_m49AA25E6533152B71D1D5BEF531353E3CCA0E207 ();
// 0x000001C9 System.Object TestSpawn_<asteroidWave>d__5::System.Collections.IEnumerator.get_Current()
extern void U3CasteroidWaveU3Ed__5_System_Collections_IEnumerator_get_Current_m4647ABDB7FE78877DB5CF9FDDCF8D3AF8D318A80 ();
// 0x000001CA System.Void EnvMapAnimator_<Start>d__4::.ctor(System.Int32)
extern void U3CStartU3Ed__4__ctor_m8B0264798939C569742263D32E0054DBAB9AE6FF ();
// 0x000001CB System.Void EnvMapAnimator_<Start>d__4::System.IDisposable.Dispose()
extern void U3CStartU3Ed__4_System_IDisposable_Dispose_m3EFE2ADAD412045F666CFA1C8C9FF53AF92CBD75 ();
// 0x000001CC System.Boolean EnvMapAnimator_<Start>d__4::MoveNext()
extern void U3CStartU3Ed__4_MoveNext_m84F94A5CD6012300AC80698CDCA870A0A146E226 ();
// 0x000001CD System.Object EnvMapAnimator_<Start>d__4::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CStartU3Ed__4_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m129CB3E5CAFFA1D19D4988182EEF116F2086A637 ();
// 0x000001CE System.Void EnvMapAnimator_<Start>d__4::System.Collections.IEnumerator.Reset()
extern void U3CStartU3Ed__4_System_Collections_IEnumerator_Reset_m345E255900454CC505A8AAE3BF6AEF3C06467EAB ();
// 0x000001CF System.Object EnvMapAnimator_<Start>d__4::System.Collections.IEnumerator.get_Current()
extern void U3CStartU3Ed__4_System_Collections_IEnumerator_get_Current_m5920F51DCC2DC7C8BC98EE95D6CD4D7784997272 ();
// 0x000001D0 System.Void TMPro.TMP_TextEventHandler_CharacterSelectionEvent::.ctor()
extern void CharacterSelectionEvent__ctor_mE2C306B8090F90261252C94D26AB5085580B11D5 ();
// 0x000001D1 System.Void TMPro.TMP_TextEventHandler_SpriteSelectionEvent::.ctor()
extern void SpriteSelectionEvent__ctor_m9D9F101CB717ACD5449336DFFF70F86AE32BB6EC ();
// 0x000001D2 System.Void TMPro.TMP_TextEventHandler_WordSelectionEvent::.ctor()
extern void WordSelectionEvent__ctor_mFD7F2937426D4AA1A8CBB13F62C3CC1D2061AD1E ();
// 0x000001D3 System.Void TMPro.TMP_TextEventHandler_LineSelectionEvent::.ctor()
extern void LineSelectionEvent__ctor_mA23AFEC8E11183CF472044FA72B07AD28ED6E675 ();
// 0x000001D4 System.Void TMPro.TMP_TextEventHandler_LinkSelectionEvent::.ctor()
extern void LinkSelectionEvent__ctor_m02CC491DBE4B2FF05A8FD4285813215ED3D323E5 ();
// 0x000001D5 System.Void TMPro.Examples.Benchmark01_<Start>d__10::.ctor(System.Int32)
extern void U3CStartU3Ed__10__ctor_m328932E4B6124311CD738F2F84F69BC149209129 ();
// 0x000001D6 System.Void TMPro.Examples.Benchmark01_<Start>d__10::System.IDisposable.Dispose()
extern void U3CStartU3Ed__10_System_IDisposable_Dispose_m209F531CE6ED7F07649497DD15817C1D7C1880A1 ();
// 0x000001D7 System.Boolean TMPro.Examples.Benchmark01_<Start>d__10::MoveNext()
extern void U3CStartU3Ed__10_MoveNext_mD927C85D41034011055A7CA3AFFAF4E10464F65D ();
// 0x000001D8 System.Object TMPro.Examples.Benchmark01_<Start>d__10::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CStartU3Ed__10_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m18BA91C8A20CBD6976D52E335563D9B42C1AE9A8 ();
// 0x000001D9 System.Void TMPro.Examples.Benchmark01_<Start>d__10::System.Collections.IEnumerator.Reset()
extern void U3CStartU3Ed__10_System_Collections_IEnumerator_Reset_m5A67B5BDE759A157229E6CF24E653B79B2AC0200 ();
// 0x000001DA System.Object TMPro.Examples.Benchmark01_<Start>d__10::System.Collections.IEnumerator.get_Current()
extern void U3CStartU3Ed__10_System_Collections_IEnumerator_get_Current_mA521C1EFA357A9F4F4CAA68A4D0B85468764323C ();
// 0x000001DB System.Void TMPro.Examples.Benchmark01_UGUI_<Start>d__10::.ctor(System.Int32)
extern void U3CStartU3Ed__10__ctor_m9A8C7C0644996520AD443A4F7CA527BF05C54C3C ();
// 0x000001DC System.Void TMPro.Examples.Benchmark01_UGUI_<Start>d__10::System.IDisposable.Dispose()
extern void U3CStartU3Ed__10_System_IDisposable_Dispose_m94D1420C08F57F2901E2499D36778BB8F1C76932 ();
// 0x000001DD System.Boolean TMPro.Examples.Benchmark01_UGUI_<Start>d__10::MoveNext()
extern void U3CStartU3Ed__10_MoveNext_m31AF957FFAEEED4BE0F39A1185C6112C4EB6F7AA ();
// 0x000001DE System.Object TMPro.Examples.Benchmark01_UGUI_<Start>d__10::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CStartU3Ed__10_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m39B535B222104759319A54A6D7E2E81482A1F71E ();
// 0x000001DF System.Void TMPro.Examples.Benchmark01_UGUI_<Start>d__10::System.Collections.IEnumerator.Reset()
extern void U3CStartU3Ed__10_System_Collections_IEnumerator_Reset_mC2B435140D045B6A20FB105E0E2CBD625218CA74 ();
// 0x000001E0 System.Object TMPro.Examples.Benchmark01_UGUI_<Start>d__10::System.Collections.IEnumerator.get_Current()
extern void U3CStartU3Ed__10_System_Collections_IEnumerator_get_Current_m9A98CCB7604AAD93919CAE48955C6A6CB8C38790 ();
// 0x000001E1 System.Void TMPro.Examples.ShaderPropAnimator_<AnimateProperties>d__6::.ctor(System.Int32)
extern void U3CAnimatePropertiesU3Ed__6__ctor_mB5F6ED6FCDA5BEAD56E22B64283D7A4D7F7EAE71 ();
// 0x000001E2 System.Void TMPro.Examples.ShaderPropAnimator_<AnimateProperties>d__6::System.IDisposable.Dispose()
extern void U3CAnimatePropertiesU3Ed__6_System_IDisposable_Dispose_m29AAE9560CA4EEB4A548A68ACA085EC9E4CB8EA5 ();
// 0x000001E3 System.Boolean TMPro.Examples.ShaderPropAnimator_<AnimateProperties>d__6::MoveNext()
extern void U3CAnimatePropertiesU3Ed__6_MoveNext_m4F2D37B672E95820F49489611196CDE334736157 ();
// 0x000001E4 System.Object TMPro.Examples.ShaderPropAnimator_<AnimateProperties>d__6::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CAnimatePropertiesU3Ed__6_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m21D2B0A0B0CADF520D05FE4948F1DE94CF119630 ();
// 0x000001E5 System.Void TMPro.Examples.ShaderPropAnimator_<AnimateProperties>d__6::System.Collections.IEnumerator.Reset()
extern void U3CAnimatePropertiesU3Ed__6_System_Collections_IEnumerator_Reset_m1E942C0FD32005FDBB182CF646FD2312BA273BC7 ();
// 0x000001E6 System.Object TMPro.Examples.ShaderPropAnimator_<AnimateProperties>d__6::System.Collections.IEnumerator.get_Current()
extern void U3CAnimatePropertiesU3Ed__6_System_Collections_IEnumerator_get_Current_mFC3602799F1D07BB002093DFB879FC759384FDD3 ();
// 0x000001E7 System.Void TMPro.Examples.SkewTextExample_<WarpText>d__7::.ctor(System.Int32)
extern void U3CWarpTextU3Ed__7__ctor_mA03118DB0FD3BF160500E127D1FACDAF45313047 ();
// 0x000001E8 System.Void TMPro.Examples.SkewTextExample_<WarpText>d__7::System.IDisposable.Dispose()
extern void U3CWarpTextU3Ed__7_System_IDisposable_Dispose_m9D7F6A90DA911D77EE72A2824FF9690CED05FBC8 ();
// 0x000001E9 System.Boolean TMPro.Examples.SkewTextExample_<WarpText>d__7::MoveNext()
extern void U3CWarpTextU3Ed__7_MoveNext_m7FE0DD003507BAD92E35CC5DACE5D043ADD766ED ();
// 0x000001EA System.Object TMPro.Examples.SkewTextExample_<WarpText>d__7::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CWarpTextU3Ed__7_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m349F81ECD49FF12E4009E2E56DB81974D68C6DAD ();
// 0x000001EB System.Void TMPro.Examples.SkewTextExample_<WarpText>d__7::System.Collections.IEnumerator.Reset()
extern void U3CWarpTextU3Ed__7_System_Collections_IEnumerator_Reset_m3122CE754238FB7815F7ABE8E7DFAF3AB7B03278 ();
// 0x000001EC System.Object TMPro.Examples.SkewTextExample_<WarpText>d__7::System.Collections.IEnumerator.get_Current()
extern void U3CWarpTextU3Ed__7_System_Collections_IEnumerator_get_Current_m79BF250C4ADC29ACF11370E2B5BD4FFD78709565 ();
// 0x000001ED System.Void TMPro.Examples.TeleType_<Start>d__4::.ctor(System.Int32)
extern void U3CStartU3Ed__4__ctor_m8231909D78A27061165C450481E233339F300046 ();
// 0x000001EE System.Void TMPro.Examples.TeleType_<Start>d__4::System.IDisposable.Dispose()
extern void U3CStartU3Ed__4_System_IDisposable_Dispose_m6886DB5D83361607B72BBCCB7D484B9C0BFE1981 ();
// 0x000001EF System.Boolean TMPro.Examples.TeleType_<Start>d__4::MoveNext()
extern void U3CStartU3Ed__4_MoveNext_m1CD1306C9E074D3F941AC906A48D3CA97C148774 ();
// 0x000001F0 System.Object TMPro.Examples.TeleType_<Start>d__4::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CStartU3Ed__4_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mE50AC5FA9F27773C51DD3E4188A748BA0A513F8A ();
// 0x000001F1 System.Void TMPro.Examples.TeleType_<Start>d__4::System.Collections.IEnumerator.Reset()
extern void U3CStartU3Ed__4_System_Collections_IEnumerator_Reset_m5D6EE5C4B2C20A433129D8BFD13DFC82681346A2 ();
// 0x000001F2 System.Object TMPro.Examples.TeleType_<Start>d__4::System.Collections.IEnumerator.get_Current()
extern void U3CStartU3Ed__4_System_Collections_IEnumerator_get_Current_m1FA5600514131056D8198F8442F37A4A22A9F065 ();
// 0x000001F3 System.Void TMPro.Examples.TextConsoleSimulator_<RevealCharacters>d__7::.ctor(System.Int32)
extern void U3CRevealCharactersU3Ed__7__ctor_m48510711FC78DFEA9CF4603E1E75F4DF7C5F1489 ();
// 0x000001F4 System.Void TMPro.Examples.TextConsoleSimulator_<RevealCharacters>d__7::System.IDisposable.Dispose()
extern void U3CRevealCharactersU3Ed__7_System_IDisposable_Dispose_m5B88486625A74566DF3FC7BFB4CE327A58C57ED4 ();
// 0x000001F5 System.Boolean TMPro.Examples.TextConsoleSimulator_<RevealCharacters>d__7::MoveNext()
extern void U3CRevealCharactersU3Ed__7_MoveNext_mE45076151810A7C1F83802B7754DE92E812EABAB ();
// 0x000001F6 System.Object TMPro.Examples.TextConsoleSimulator_<RevealCharacters>d__7::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CRevealCharactersU3Ed__7_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m9C330834C7113C8468CC1A09417B7C521CAE833B ();
// 0x000001F7 System.Void TMPro.Examples.TextConsoleSimulator_<RevealCharacters>d__7::System.Collections.IEnumerator.Reset()
extern void U3CRevealCharactersU3Ed__7_System_Collections_IEnumerator_Reset_m25B719FFD0CAB1DFF2853FF47A4EE2032176E287 ();
// 0x000001F8 System.Object TMPro.Examples.TextConsoleSimulator_<RevealCharacters>d__7::System.Collections.IEnumerator.get_Current()
extern void U3CRevealCharactersU3Ed__7_System_Collections_IEnumerator_get_Current_m9A540E1B18E93F749F4BFD4C8597AEC9F2C199F7 ();
// 0x000001F9 System.Void TMPro.Examples.TextConsoleSimulator_<RevealWords>d__8::.ctor(System.Int32)
extern void U3CRevealWordsU3Ed__8__ctor_mDF41BA5FE3D53FEC3CB8214FCA7853A1142DE70C ();
// 0x000001FA System.Void TMPro.Examples.TextConsoleSimulator_<RevealWords>d__8::System.IDisposable.Dispose()
extern void U3CRevealWordsU3Ed__8_System_IDisposable_Dispose_m46827499CD3657AF468926B6302D2340ED975965 ();
// 0x000001FB System.Boolean TMPro.Examples.TextConsoleSimulator_<RevealWords>d__8::MoveNext()
extern void U3CRevealWordsU3Ed__8_MoveNext_mE0CB1189CFAD7F7B3E74438A4528D9BFAABB48DE ();
// 0x000001FC System.Object TMPro.Examples.TextConsoleSimulator_<RevealWords>d__8::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CRevealWordsU3Ed__8_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m4A3E941DF6C67BC9ACEFEAA09D11167B3F3A38EC ();
// 0x000001FD System.Void TMPro.Examples.TextConsoleSimulator_<RevealWords>d__8::System.Collections.IEnumerator.Reset()
extern void U3CRevealWordsU3Ed__8_System_Collections_IEnumerator_Reset_m967B427886233CDB5DFFEA323F02A89CE9330CC8 ();
// 0x000001FE System.Object TMPro.Examples.TextConsoleSimulator_<RevealWords>d__8::System.Collections.IEnumerator.get_Current()
extern void U3CRevealWordsU3Ed__8_System_Collections_IEnumerator_get_Current_m0C1B2941BEC04593993127F6D9DCDBA6FAE7CC20 ();
// 0x000001FF System.Void TMPro.Examples.TextMeshProFloatingText_<DisplayTextMeshProFloatingText>d__12::.ctor(System.Int32)
extern void U3CDisplayTextMeshProFloatingTextU3Ed__12__ctor_m13B7271203EDC80E649C1CE40F09A93BDA2633DF ();
// 0x00000200 System.Void TMPro.Examples.TextMeshProFloatingText_<DisplayTextMeshProFloatingText>d__12::System.IDisposable.Dispose()
extern void U3CDisplayTextMeshProFloatingTextU3Ed__12_System_IDisposable_Dispose_m3D1611AA38746EF0827F5260DADCC361DD56DF0C ();
// 0x00000201 System.Boolean TMPro.Examples.TextMeshProFloatingText_<DisplayTextMeshProFloatingText>d__12::MoveNext()
extern void U3CDisplayTextMeshProFloatingTextU3Ed__12_MoveNext_m03111B7039F928512A7A53F8DA9C04671AA8D7EE ();
// 0x00000202 System.Object TMPro.Examples.TextMeshProFloatingText_<DisplayTextMeshProFloatingText>d__12::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CDisplayTextMeshProFloatingTextU3Ed__12_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m55B08E77035437C2B75332F29214C33214417414 ();
// 0x00000203 System.Void TMPro.Examples.TextMeshProFloatingText_<DisplayTextMeshProFloatingText>d__12::System.Collections.IEnumerator.Reset()
extern void U3CDisplayTextMeshProFloatingTextU3Ed__12_System_Collections_IEnumerator_Reset_m6737F2D695AB295240F15C5B0B4F24A59106BFDA ();
// 0x00000204 System.Object TMPro.Examples.TextMeshProFloatingText_<DisplayTextMeshProFloatingText>d__12::System.Collections.IEnumerator.get_Current()
extern void U3CDisplayTextMeshProFloatingTextU3Ed__12_System_Collections_IEnumerator_get_Current_m6BD4D2442BDDDFB6859CFE646182580A0A1E130A ();
// 0x00000205 System.Void TMPro.Examples.TextMeshProFloatingText_<DisplayTextMeshFloatingText>d__13::.ctor(System.Int32)
extern void U3CDisplayTextMeshFloatingTextU3Ed__13__ctor_m7E4C3B87E56A7B23D725D653E52ADE02554EAE3E ();
// 0x00000206 System.Void TMPro.Examples.TextMeshProFloatingText_<DisplayTextMeshFloatingText>d__13::System.IDisposable.Dispose()
extern void U3CDisplayTextMeshFloatingTextU3Ed__13_System_IDisposable_Dispose_m485A7C4CF3496858A72CBA647B29BC610F39FE39 ();
// 0x00000207 System.Boolean TMPro.Examples.TextMeshProFloatingText_<DisplayTextMeshFloatingText>d__13::MoveNext()
extern void U3CDisplayTextMeshFloatingTextU3Ed__13_MoveNext_m6A3C88B1149D12B58E6E580BC04622F553ED1424 ();
// 0x00000208 System.Object TMPro.Examples.TextMeshProFloatingText_<DisplayTextMeshFloatingText>d__13::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CDisplayTextMeshFloatingTextU3Ed__13_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m2EE54B2AC8AAE44BACF8EE8954A6D824045CFC55 ();
// 0x00000209 System.Void TMPro.Examples.TextMeshProFloatingText_<DisplayTextMeshFloatingText>d__13::System.Collections.IEnumerator.Reset()
extern void U3CDisplayTextMeshFloatingTextU3Ed__13_System_Collections_IEnumerator_Reset_m8524C9700DEF2DE7A28BBFDB938FE159985E86EE ();
// 0x0000020A System.Object TMPro.Examples.TextMeshProFloatingText_<DisplayTextMeshFloatingText>d__13::System.Collections.IEnumerator.get_Current()
extern void U3CDisplayTextMeshFloatingTextU3Ed__13_System_Collections_IEnumerator_get_Current_m2293C6A327D4D1CCC1ACBC90DBE00DC1C6F39EBE ();
// 0x0000020B System.Void TMPro.Examples.VertexColorCycler_<AnimateVertexColors>d__3::.ctor(System.Int32)
extern void U3CAnimateVertexColorsU3Ed__3__ctor_m3D7543ED636AFCD2C59E834668568DB2A4005F6A ();
// 0x0000020C System.Void TMPro.Examples.VertexColorCycler_<AnimateVertexColors>d__3::System.IDisposable.Dispose()
extern void U3CAnimateVertexColorsU3Ed__3_System_IDisposable_Dispose_m3F7092E831D4CFDACC5B6254958DFEC2D313D0EE ();
// 0x0000020D System.Boolean TMPro.Examples.VertexColorCycler_<AnimateVertexColors>d__3::MoveNext()
extern void U3CAnimateVertexColorsU3Ed__3_MoveNext_mC0D42DAE0A614F2B91AF1F9A2F8C0AF471CA0AE4 ();
// 0x0000020E System.Object TMPro.Examples.VertexColorCycler_<AnimateVertexColors>d__3::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CAnimateVertexColorsU3Ed__3_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m6597EE639379454CADA3823A1B955FEFBAF894BD ();
// 0x0000020F System.Void TMPro.Examples.VertexColorCycler_<AnimateVertexColors>d__3::System.Collections.IEnumerator.Reset()
extern void U3CAnimateVertexColorsU3Ed__3_System_Collections_IEnumerator_Reset_m9943586181F26EEE58A42138CE0489DDF07EA359 ();
// 0x00000210 System.Object TMPro.Examples.VertexColorCycler_<AnimateVertexColors>d__3::System.Collections.IEnumerator.get_Current()
extern void U3CAnimateVertexColorsU3Ed__3_System_Collections_IEnumerator_get_Current_m2D4E4AA5EEB4F07F283E61018685199A4C2D56BD ();
// 0x00000211 System.Void TMPro.Examples.VertexJitter_<AnimateVertexColors>d__11::.ctor(System.Int32)
extern void U3CAnimateVertexColorsU3Ed__11__ctor_mC74A801C40038DA74D856FACFBAD12F3BC3E11E7 ();
// 0x00000212 System.Void TMPro.Examples.VertexJitter_<AnimateVertexColors>d__11::System.IDisposable.Dispose()
extern void U3CAnimateVertexColorsU3Ed__11_System_IDisposable_Dispose_m07C61223FC885322B6066E81CB130879661D5A72 ();
// 0x00000213 System.Boolean TMPro.Examples.VertexJitter_<AnimateVertexColors>d__11::MoveNext()
extern void U3CAnimateVertexColorsU3Ed__11_MoveNext_m04CD6FB321DE3AD8D5890766C1F2CAAE4112EDF2 ();
// 0x00000214 System.Object TMPro.Examples.VertexJitter_<AnimateVertexColors>d__11::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CAnimateVertexColorsU3Ed__11_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m35F5F559A34D3F9BE1E5DD636FEAF517164A6B07 ();
// 0x00000215 System.Void TMPro.Examples.VertexJitter_<AnimateVertexColors>d__11::System.Collections.IEnumerator.Reset()
extern void U3CAnimateVertexColorsU3Ed__11_System_Collections_IEnumerator_Reset_m325AE901312C158848B79B302EBA7BE847C93D49 ();
// 0x00000216 System.Object TMPro.Examples.VertexJitter_<AnimateVertexColors>d__11::System.Collections.IEnumerator.get_Current()
extern void U3CAnimateVertexColorsU3Ed__11_System_Collections_IEnumerator_get_Current_mA688DA41E2C04FF9774F607794C114057FA055C6 ();
// 0x00000217 System.Void TMPro.Examples.VertexShakeA_<AnimateVertexColors>d__11::.ctor(System.Int32)
extern void U3CAnimateVertexColorsU3Ed__11__ctor_m89953000A887F8C0931B0E98B484FBAAC37748C5 ();
// 0x00000218 System.Void TMPro.Examples.VertexShakeA_<AnimateVertexColors>d__11::System.IDisposable.Dispose()
extern void U3CAnimateVertexColorsU3Ed__11_System_IDisposable_Dispose_m9AFBB2A87D38A1358F9EB09D617075D72DEED19B ();
// 0x00000219 System.Boolean TMPro.Examples.VertexShakeA_<AnimateVertexColors>d__11::MoveNext()
extern void U3CAnimateVertexColorsU3Ed__11_MoveNext_m9F607EF7DBDFFC4FB2307B0EC4C7F33EEE63BBE8 ();
// 0x0000021A System.Object TMPro.Examples.VertexShakeA_<AnimateVertexColors>d__11::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CAnimateVertexColorsU3Ed__11_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mF47F7A3AB51F9BC1B8F74E10FD82B29C1B223DCD ();
// 0x0000021B System.Void TMPro.Examples.VertexShakeA_<AnimateVertexColors>d__11::System.Collections.IEnumerator.Reset()
extern void U3CAnimateVertexColorsU3Ed__11_System_Collections_IEnumerator_Reset_m99B988724C4F53F7F8334C5F633C8B1603185ADD ();
// 0x0000021C System.Object TMPro.Examples.VertexShakeA_<AnimateVertexColors>d__11::System.Collections.IEnumerator.get_Current()
extern void U3CAnimateVertexColorsU3Ed__11_System_Collections_IEnumerator_get_Current_mE9127628FC1726149DA7C8FE95A7D4CFB1EE1655 ();
// 0x0000021D System.Void TMPro.Examples.VertexShakeB_<AnimateVertexColors>d__10::.ctor(System.Int32)
extern void U3CAnimateVertexColorsU3Ed__10__ctor_mBA04B89258FA2EF09266E1766AB0B815E521897A ();
// 0x0000021E System.Void TMPro.Examples.VertexShakeB_<AnimateVertexColors>d__10::System.IDisposable.Dispose()
extern void U3CAnimateVertexColorsU3Ed__10_System_IDisposable_Dispose_mE001B767DE85B4B3B86A0C080B9FC00381340A1C ();
// 0x0000021F System.Boolean TMPro.Examples.VertexShakeB_<AnimateVertexColors>d__10::MoveNext()
extern void U3CAnimateVertexColorsU3Ed__10_MoveNext_m611487BEE2BB82A9BFF5EA2157BDCA610F87876D ();
// 0x00000220 System.Object TMPro.Examples.VertexShakeB_<AnimateVertexColors>d__10::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CAnimateVertexColorsU3Ed__10_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m6A54A1BF63433F860822B43ABA9FAC6A4124409C ();
// 0x00000221 System.Void TMPro.Examples.VertexShakeB_<AnimateVertexColors>d__10::System.Collections.IEnumerator.Reset()
extern void U3CAnimateVertexColorsU3Ed__10_System_Collections_IEnumerator_Reset_m48F09B740CBEEC27459498932572D2869A1A4CBE ();
// 0x00000222 System.Object TMPro.Examples.VertexShakeB_<AnimateVertexColors>d__10::System.Collections.IEnumerator.get_Current()
extern void U3CAnimateVertexColorsU3Ed__10_System_Collections_IEnumerator_get_Current_mA915AC55E6DEE343235545FC1FE6F6CA5611DF3C ();
// 0x00000223 System.Void TMPro.Examples.VertexZoom_<>c__DisplayClass10_0::.ctor()
extern void U3CU3Ec__DisplayClass10_0__ctor_m1C2F2204ADD6E4BA14E14CF255F520B7E2464941 ();
// 0x00000224 System.Int32 TMPro.Examples.VertexZoom_<>c__DisplayClass10_0::<AnimateVertexColors>b__0(System.Int32,System.Int32)
extern void U3CU3Ec__DisplayClass10_0_U3CAnimateVertexColorsU3Eb__0_m673C7031DB1882DEEFB53F179E3C2FB13FB6CA5A ();
// 0x00000225 System.Void TMPro.Examples.VertexZoom_<AnimateVertexColors>d__10::.ctor(System.Int32)
extern void U3CAnimateVertexColorsU3Ed__10__ctor_m2F5D29C1CA797C0BCEC16C8B5D96D1CF5B07F6F3 ();
// 0x00000226 System.Void TMPro.Examples.VertexZoom_<AnimateVertexColors>d__10::System.IDisposable.Dispose()
extern void U3CAnimateVertexColorsU3Ed__10_System_IDisposable_Dispose_m1A43A8EA2FB689EE2B39D8A624580594374905B9 ();
// 0x00000227 System.Boolean TMPro.Examples.VertexZoom_<AnimateVertexColors>d__10::MoveNext()
extern void U3CAnimateVertexColorsU3Ed__10_MoveNext_mCA826F12F72BDBB79F9B50DC9CBC6E7F80B2110F ();
// 0x00000228 System.Object TMPro.Examples.VertexZoom_<AnimateVertexColors>d__10::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CAnimateVertexColorsU3Ed__10_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mFF0E754E9557C03F892EFA19C0307AECD6BA8C4D ();
// 0x00000229 System.Void TMPro.Examples.VertexZoom_<AnimateVertexColors>d__10::System.Collections.IEnumerator.Reset()
extern void U3CAnimateVertexColorsU3Ed__10_System_Collections_IEnumerator_Reset_m002A7C6C8AE61BE6CD6FD0B2173C75DBF47BCC56 ();
// 0x0000022A System.Object TMPro.Examples.VertexZoom_<AnimateVertexColors>d__10::System.Collections.IEnumerator.get_Current()
extern void U3CAnimateVertexColorsU3Ed__10_System_Collections_IEnumerator_get_Current_mE91B03C99FCCBC8ED4E37649C5364E83D047B053 ();
// 0x0000022B System.Void TMPro.Examples.WarpTextExample_<WarpText>d__8::.ctor(System.Int32)
extern void U3CWarpTextU3Ed__8__ctor_m845C9410F3856EF25585F59C425200EEFCEFB3C0 ();
// 0x0000022C System.Void TMPro.Examples.WarpTextExample_<WarpText>d__8::System.IDisposable.Dispose()
extern void U3CWarpTextU3Ed__8_System_IDisposable_Dispose_m63AC2AE8BC0FCF89812A33CAF150E9D1B56BAE6A ();
// 0x0000022D System.Boolean TMPro.Examples.WarpTextExample_<WarpText>d__8::MoveNext()
extern void U3CWarpTextU3Ed__8_MoveNext_m98D3E999A69E233C7AD5F357A0D0623D731DCDAA ();
// 0x0000022E System.Object TMPro.Examples.WarpTextExample_<WarpText>d__8::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CWarpTextU3Ed__8_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m3971C0D86C5903812972245A6F872D101ACB5189 ();
// 0x0000022F System.Void TMPro.Examples.WarpTextExample_<WarpText>d__8::System.Collections.IEnumerator.Reset()
extern void U3CWarpTextU3Ed__8_System_Collections_IEnumerator_Reset_mF17827612AC7C91DE879114D1D6428450B9504D0 ();
// 0x00000230 System.Object TMPro.Examples.WarpTextExample_<WarpText>d__8::System.Collections.IEnumerator.get_Current()
extern void U3CWarpTextU3Ed__8_System_Collections_IEnumerator_get_Current_m98A13A358D4E71D9612F68731A7AE11A3DD080DE ();
static Il2CppMethodPointer s_methodPointers[560] = 
{
	Flash_Start_m8B26902F759AE1F18A1FF54FF0A066551F0F3688,
	Flash_OnTriggerEnter2D_m061BBE509F31E435AA7B532B2B76390A0279AB46,
	Flash_End_m5068DFB8589D22BF984E243B60AD953FE1CFAB1E,
	Flash_ResetMaterial_mFE1D963684FF80E430ED7277CB13E3F3F0FE6FA0,
	Flash__ctor_mA632A5743328DCFC5891A1231933E50D81F1595C,
	HardDouble_Start_mB17F406E2C53FEDB876FC9434C56643C72286D57,
	HardDouble_Update_mA5BCAB98C6459967C3937AE5A211ACEDFD9BDB3F,
	HardDouble__ctor_m7AB5B8179CD08DD01B339F4AEF7121522697D864,
	PopReward_Start_m36933F0702D7F9A03919676D06CF0D8392BE9EAD,
	PopReward_ShowRewardedVideo_mC3C5917115C3342679FAAE58CB22C2BA9E2D331B,
	PopReward_OnUnityAdsReady_m57F6FB4D5C9E3C4545AD5723F06C822C21F6DB47,
	PopReward_OnUnityAdsDidFinish_m4A8059C0657243C712795119FE1F7AE351589C65,
	PopReward_OnUnityAdsDidError_m3629F72E0898984109176C5714E8C2C0C7534934,
	PopReward_OnUnityAdsDidStart_m1D5BBF3E4A730C48D4B6F6E2AC7E31AA27D2C64F,
	PopReward__ctor_mF48C7E97B29AE38BBB1B8CECB5E508314BD49FFA,
	RemoveAds_RemoveAd_mD661F9870C921E6C506F0A6E285692376D0E1F8C,
	RemoveAds__ctor_m484BCDFD8A6746837A8C28CBEFC680EC66780E6F,
	AudioManger_Awake_m55F957100F48CA3F327909F434F2979925602598,
	AudioManger_Start_m3C13AB431184579FAAA65714EC6E833F195AD8AB,
	AudioManger_Play_m08EFC2908A2E13C182E2D3562078944EC112BAA4,
	AudioManger_StopPlaying_m40F69ED32FE1832B6C6394EB7F1913A53F54A46B,
	AudioManger__ctor_m6016AF7021462D6CFAD2C2B48D94370E81DDEC87,
	BannerManager_Start_m55992CD2487295D18E24B8662213845A978702C6,
	BannerManager_ShowBannerWhenInitialized_m676BDCC05DE7151B3C81F13E5D60159AFE93BD38,
	BannerManager_LoadShoot_mAE9D9518D1E46D364C1920109D0983126B4508B9,
	BannerManager_LoadCatch_mF5E2C9AE9AAC91E61AEEB9255275F4DEE43B35C2,
	BannerManager_RemoveAds_mF98255599CC0DB310FED239100482738EAF417BA,
	BannerManager__ctor_m0AD620A047688F663C111848A7692153F093DCF3,
	BombSpawn_Start_m099F0CC3E1FF96ACEBD17E685957CDCCE3747A7C,
	BombSpawn_Update_mD785AEDF2F7DF905F436D2113896ECC17CFD4A04,
	BombSpawn__ctor_mEDA97D761DD5C4468E1603E15F7D8CECB3514267,
	BombSpawner_Start_mEEF4FD796E6F125D8FA6BD431C31D046CDBBF2A8,
	BombSpawner_Update_mAA11B63B2808969C2E4DA80B0B0847CFF156BA19,
	BombSpawner__ctor_mE300FC2E154A29A155E45AEB87AEF64E847F3747,
	Bullet_Start_m0C6AD7FCC791ADF08593B040294D8B7329617D04,
	Bullet_OnTriggerEnter2D_m9244231F2C1AB21C314A050A32331CA5BBA44834,
	Bullet__ctor_mFBA1E7297C133AE06ADA2EF2BA04567AD213A9D4,
	ButtonFX_Button_mBDED4D807C29028E0518F18098CE57DCE8F2A8AD,
	ButtonFX__ctor_m33A3B15214B840D82BF71CBB23E306A2BB8FCC1E,
	Catch2x_Start_m6A2D7AB2413CA27E6CF03FF1E45691B6F293C43E,
	Catch2x_OnTriggerEnter2D_mA6B716C793E5354099237C60E6E779D6853BFFAD,
	Catch2x__ctor_mE45A49ED1CA1314C06A8DA5ADAD3BD8E9F06590A,
	CatchAM_Start_mC618B2FE34F7C03C78C5633723788ADF48EC4D17,
	CatchAM_PlaySound_m8E3AA76BF692EEED752C5FED44783C8DE222536B,
	CatchAM__ctor_m3BD1C6BE9817EE19DE20B49D13DA0E2E452BDFF0,
	CatchBomb_Start_m5A9C8D1B7956A551A5E176FEDC4FD9C43D9F7345,
	CatchBomb_OnTriggerEnter2D_m02B6502F8D3C261E6A08C871285EC1260227DA17,
	CatchBomb__ctor_mE90366CB482D4058AD03DF509B81B977645FEB1D,
	CatchEnemy_Start_mDD09C54710C691DD56B9DD5AB3FC6BCEAAE02E9F,
	CatchEnemy_OnTriggerEnter2D_m08E3932BD2444F78470FCACA449FA970E2AB9160,
	CatchEnemy__ctor_mD29810C4D3D87F0486C6B8F68FA3ADA6ECE1FF48,
	CatchMenu_LoadMenu_m2AB39CAFFB9EC40174EB00FD45368AE107F0293C,
	CatchMenu__ctor_m2FAC1A68E1193A06A7B78CA61601856B6BC44876,
	CatchPointSystem_Start_mC14B56BBFE93513B54B20593D07B618BE73F3DB9,
	CatchPointSystem_Update_m3A2C68E0BDBDBC1F168B6829BBA9068E2528E4BB,
	CatchPointSystem__ctor_mFE4A25CF2B63001677710F8052C1EF7DAB4B44AB,
	CatchScore_Start_m9A0C00C7CC643E831032880AE895482B7B3EFFFA,
	CatchScore_Update_m008FA6BB11EDB68BA6F097EFD38561A33021A2ED,
	CatchScore_AddScore_mED9057926185F69782359763BC33A32C4BED253F,
	CatchScore_GameOver_mEB8B7D63B4EE6614296878800F561A95199EE7F1,
	CatchScore__ctor_mCECEAC6A245A82E8D508C9C9BD9E3DE111311617,
	CoinAdReward_Start_m28D67D3666895FD9B491B525F1A0689C86AF6D2C,
	CoinAdReward_ShowRewardedVideo_m8D36F381076CA846BE3E3EF939B6401844A5F5A9,
	CoinAdReward_OnUnityAdsReady_m90957FDBB0741B93071E915703BB75AA51D0FC6A,
	CoinAdReward_OnUnityAdsDidFinish_m7D8181831BA381EEB94D32632586959D594B42E7,
	CoinAdReward_OnUnityAdsDidError_mAC06C3CEA447B7899D0C3DB900F7FDA480D91255,
	CoinAdReward_OnUnityAdsDidStart_m27D632ECB28499438AA003A6522CD5FFC2F9CA67,
	CoinAdReward__ctor_mD0765993ADC955FBE3232F77D0071E7DBFFBD232,
	CoinTracker_Start_m5AD826DB751C9309E18CA4F6D2F7D7FAA6DE2F8E,
	CoinTracker_Update_mF7E677FBCD521A8182ED9187127A23A79F2718E0,
	CoinTracker_AddScore_m40D1C18B124C72CCC08E16D9332C7C1A214119B2,
	CoinTracker_GameOver_mD0772FDA4FA10B7161C07BDB238B8DA82B6F5172,
	CoinTracker__ctor_m5F588AA587478FCFB240FD7351039A61B79E8619,
	DeployVirus_Start_m91C8823912AF0D79B2ADB5C48D10C19012E1F9F7,
	DeployVirus_spawnVirus_m8A05CD118F8E95B9F236B866D8F4DCAE3FF85A3D,
	DeployVirus_virusWave_m147F6052081F7FA9C281088F656D37EC9CA1E7E1,
	DeployVirus__ctor_mA9E06CED6B34990D870F599C2BDE2162A582E800,
	DestroBoss_Start_m0D1EB2DA497E1F5F8F3837A138821DA79840CD76,
	DestroBoss_OnTriggerEnter2D_m32F0B42A968CAF1402845BA76E3D37F6968668C1,
	DestroBoss__ctor_mC988AE3C07E88381DF7CE688A74667DD27727029,
	DestroBoss__cctor_m82558AABD9AFA2373F84BCC23E9C041171234C81,
	DestroyBomb_OnMouseDown_mD187FDE1CE25ACEE0770F32DF62CE62D348FCB68,
	DestroyBomb__ctor_mFD313C2FE649DEF05985C8BF0C0FA6C2BA11C6FD,
	DestroyCatchCoin_Start_m885BB8FBF4E51CB024FF53AA12553F4F45B14839,
	DestroyCatchCoin_OnTriggerEnter2D_mD54A874EE4793A639EDEBFA20D501D90E0C23EE6,
	DestroyCatchCoin__ctor_m8415F77D06A57FBDFBD82043C4AF19C15EF0BBCC,
	DestroyCoin_OnMouseDown_m7562EBBED9BC657C973FAE80996D860BA3D82AEF,
	DestroyCoin__ctor_m20A221F9888831B5AEA23885C4EB1B76327E97A3,
	DestroyDoubler_Start_mA93BB48E7DCCF3427397D5AC208F33844675BE4E,
	DestroyDoubler_OnMouseDown_mBD30A513871D511CDD60CCF162AE301823B4F8EC,
	DestroyDoubler__ctor_m9F1820B69915A21613DC4E2C6845120DEF71A0BB,
	DestroyFive_Start_mC4D990F544BB6413A53DFD77D6744EDC9E33258E,
	DestroyFive_OnMouseDown_mB2A2A6CA49924E82D5171A9592EE8A814C34160C,
	DestroyFive__ctor_m63961DCA7B8DA4FE920AF415F4BFFDA3D23ADD8E,
	DestroyHardCoin_OnTriggerEnter2D_m4D08F566E2515A061DAD46BD7F70B1D48D3E3BBC,
	DestroyHardCoin__ctor_m10A55F14EA978FAFDEDCC167F3B934E90FF04057,
	DestroyTime_Start_m65F57F32C49BD1630C0BE6AC7EEA2BFCE3D92DAC,
	DestroyTime_WaitThenRestoreTime_mFCA4CD4EF8634211D695D6B8E4A03396E319EBE1,
	DestroyTime_OnMouseDown_m1DA55B94D0931EE09359FA114EDAEDDA9AAD2D36,
	DestroyTime__ctor_mB3397E61E00BF93B8EC946ECFD10623F4E81D35A,
	DestroyVirus_OnMouseDown_m706A8C0FE72604D1D143689BC5675802EB988CEB,
	DestroyVirus__ctor_mC8BBDD226E6D4FDF711FABC1D4F840F369DA47EC,
	Enemy_Start_m0681B66D4522F045EB7A33A21467994960D1E435,
	Enemy_OnTriggerEnter2D_mB5D8A9A3E7CFA603912813FE5D11B43F5F83634E,
	Enemy__ctor_mCD4E016A02FE662E339AA011EBA74D77B09556C5,
	EnemySpawner_Start_mC0F2354C1D2ED84F19D7BF22C89A2C198EBED26E,
	EnemySpawner_Update_m846CE9A8B10E8EBB82FF444060B85133DDEFD0D0,
	EnemySpawner_SpawnEnemy_m7BEBAA3A754FACF357E86E9886F4BC9A627A56C4,
	EnemySpawner_SelectWave_mE408638B531283B04509C24C58CA59137C6D129B,
	EnemySpawner__ctor_m637C6372D629C685D64F22E5E15FD64F9F715F24,
	Wave__ctor_m3446E431F89F15C279F37E857054908A70CEFF7E,
	FallingObjects_Update_m100967871ED390C30CF3D59FD5C74906AA92315E,
	FallingObjects__ctor_m8560F1BD49F8E2CA90E90116212BED550180EA90,
	GoBack_LoadMenu_m4D9C6324D65115B9C2CFD5B5213761853FBDD3B0,
	GoBack__ctor_m284DF5B1E05CFD89223704DA08C86BA499A5D2AF,
	HDestroyVirus_Start_mBF4BE8A94B81420312098D2FBC87707AEB0D2CFC,
	HDestroyVirus_OnTriggerEnter2D_m41C4E3BCADDC03D8CBF077F9369A27CDAEC19E90,
	HDestroyVirus__ctor_mB65D776487AAAB1B350BC9A93E939C677E750705,
	Hard2_Start_mA9613A5289BAB542C84BC4CD12C62B00E4090542,
	Hard2_OnTriggerEnter2D_m26EF8E60C277D5C8DC8AD9EF353EE125BE9B006F,
	Hard2__ctor_mCD3A744BF1B59F7B0C7956AC973DA51FE8C1C4FF,
	Hard5_Start_m8526FF8540C11E0FB803CDAC030911F407716D39,
	Hard5_OnMouseDown_m65B08ADC1EF0F594949BCFF146F0C63788C79BA0,
	Hard5__ctor_mE148252D2479C806DBB657C119C74BC8DF91E355,
	HardScoreTracker_Start_m9F058AF876214B4F8F2B18C405705E242BB6E297,
	HardScoreTracker_Update_mEE33D15D41E536AC8A5C53D143F95AE25677383D,
	HardScoreTracker_AddScore_m0C223064696E58DED92A073C140AA528FB052C1C,
	HardScoreTracker_GameOver_m2261217B7E361321FB8535BB4F50EC36560B46FC,
	HardScoreTracker__ctor_m17A7AA0EF7C5736E61DFEF1A7F756FEAEE4B99CC,
	HardSpawn_Start_m00EE51F0F061DF885C2490F602B8C9194A1EF27A,
	HardSpawn_Update_m623C6E5C3A695F4E40BCEE0D9FDC695749513AF0,
	HardSpawn_SpawnHardEnemy_m06757D17B212074518C072CD0E0A38ECBB421C4D,
	HardSpawn_SelectHardWave_m21FE3194D4B39ADDE94FE5D54A19BB67642B835D,
	HardSpawn__ctor_mE279FD91B24D4FEA5A04FBA8C8210D08223FA4D5,
	HardWWave__ctor_m117E84440A1FAAD01652D21A0FC8E60FB66A1238,
	LifeCount_Start_m28F37A454DD7218BBAA759E6F6B030C308BC1027,
	LifeCount_Update_m95841959A436E9E0B5DF7BF75CD3B6047D2D3A53,
	LifeCount__ctor_mB877DD577CE884B3F3B1CE0F0B0F452E953E67B6,
	LoseLife_OnTriggerEnter2D_m25752540A77AB407241B70F01204256B39213879,
	LoseLife__ctor_mD59ECCB364B74EB205D25D21B0C6CFE180BBF8DD,
	MoveandShoot_Start_mA964996AED1A73E8C8D02B7FB4BE5E997AAA2BF6,
	MoveandShoot_Update_m446CCF173390D0675F1FE9D129A852D63C0B6484,
	MoveandShoot__ctor_mE48AC1D25DE28DC38A8701C1A069C58B891C922B,
	Mover_Update_mC8652D13CE63EB52757504DEFAA34034CBC4FACF,
	Mover__ctor_mFAFEBAF042392E9011A10922FFFFCDBEED3EAA59,
	NewBehaviourScript_Start_mDB573B0B04591BBF1CDC10C7C835851EBF8D17F2,
	NewBehaviourScript_Update_mAA0BE51F329DE556FA585E93DD1B9CF6D917A85C,
	NewBehaviourScript__ctor_mC87DFFB91971C9C20A9487A744F5E68D74FB05FE,
	ObjectPoolItem__ctor_m08FCD752A19000480320167AB069B013BC8DCBB8,
	ObjectPooling_Awake_m8A7241F7A2052ECEE7E66804F4E2439ED8577FC9,
	ObjectPooling_GetPooledObject_mD2AEF887BB5BC3AE14EECE900E811404180CDC95,
	ObjectPooling_GetAllPooledObjects_m6BFF61A9C373EE2BAB0F7048A76F6C9F7B4B8261,
	ObjectPooling_AddObject_m909B3E5F0DCC58649D6D7672B26DE150B08553EE,
	ObjectPooling_ObjectPoolItemToPooledObject_mABB4DCB5247AD26B3E2AF8B88CE880E03E4C50F3,
	ObjectPooling__ctor_m7B0E6901E1D36230FF1AE52CC46468486BB1AE89,
	PauseMenu_Start_m87C554A1CF71A5E4A233FB35A6E0DB276388DF3B,
	PauseMenu_Update_m59D9098B173533E082A41253B251B1E5F5AB9EA9,
	PauseMenu_Resume_m69237FDC7E24AE034095A08093A78DA863B05A61,
	PauseMenu_Pause_m3E05CFCF9737962B2E1F4514848D7A59D879BA81,
	PauseMenu_LoadMain_mCE52911C1C540E219AEF14D7A3E065552242A63A,
	PauseMenu_QuitGame_m19B044FD48321942D4249C199C49B9F035F16F4A,
	PauseMenu__ctor_m1DE7CAFF465FE5BEB4E0ABDF165AFA208631EF28,
	PlayerController_Start_mC0C9B9461D0BDAC48EC43715818A4BA63C4F45EF,
	PlayerController_Update_m38903EF1C8F12B9388303741F8040EE26C33DC33,
	PlayerController__ctor_m648E40092E37395F4307411E855445886113CD60,
	Points_UpdateScore_mF2C01D69888483C76407A55F6D7A0B45AD9F8243,
	Points__ctor_mE666A3496B6E23C57AA4E9FFCD54A132E166F21A,
	PowerUpSpawner_Start_m87D14D12821222346CAE0066CBCF06F358B57475,
	PowerUpSpawner_Update_mE1D8765893DC5A9E0E584E5A35ECA9753120E9E9,
	PowerUpSpawner_SpawnEnemy_m0E1B4213C1628306F679A8CE59C540F6BB4B53A2,
	PowerUpSpawner_SelectWave_m86C6D26D8B2F21A20EE82F5B038CFDA3AE31BB23,
	PowerUpSpawner__ctor_m558DCC8B1EF843461FD029CE70D61C3BE20E2985,
	level__ctor_m43B8CB57506E35BA27451FF99C5DDCD0460DA410,
	PurchaseFX_Button_m8B977C16F2FBB225D8CC3B4E036BC2DB56B91CB1,
	PurchaseFX__ctor_mC3903CF3222A8EB4B5E02DD40BD2BFF64EFE187A,
	Restart_RestartGame_mE2CB28CB6105AAE4D4F715E0111C9D4033F1011E,
	Restart__ctor_m34586B1A8EF0A99076B81D9C768470378C934469,
	RestartHard_RestartGame_mEC82D82E7F547F705F198A738D13CA1FC4DD8094,
	RestartHard__ctor_m2A6325E1E1382134016A15BFEA66E7179EC252F1,
	RewardedAdsButton_Start_m014A67A1C7401E8226239F436FCAE3D82D470AA5,
	RewardedAdsButton_ShowRewardedVideo_mF5F5A234162E2B8DB694EC6BC8026B6FA27AFCEF,
	RewardedAdsButton_OnUnityAdsReady_mD14B0661E57DBB2A801E46EEAA465F8852898623,
	RewardedAdsButton_OnUnityAdsDidFinish_mFB400A89DDF3778E69F122BCBD6F5E54F18A9D34,
	RewardedAdsButton_OnUnityAdsDidError_m06538F8DFDB895C6E2872E43AC7EE7E0AE8D11DD,
	RewardedAdsButton_OnUnityAdsDidStart_m996CE3A0903A78F82D7B0236F1FE51F68E85A491,
	RewardedAdsButton__ctor_m7834FB47E0BF38EC317BC7366EB54197DF09F77B,
	RonaMenu_LoadMenu_m4580587AD40A2BE41D8927E0E61DB55E7E3FF032,
	RonaMenu__ctor_mAD02893B98A283EA1ACD03DCC5EDBB7173642F84,
	RonaSM_Start_mACAD79CFF93BDCE84FDEF6EA6DF6729FADA1D11F,
	RonaSM_PlaySound_m5A20379E2C16B7C28EDCD39D411EB26023AA7C11,
	RonaSM__ctor_m91988CDC238A613FC638161E84027A1948FD3FE1,
	ScoreTracker_Start_mCE3CC30C4A7DC9F85B576F53C9858940052FA01B,
	ScoreTracker_Update_mCAC5B848C06B902AA891C855164292E23F204817,
	ScoreTracker_AddScore_mAEACBFB376EE25AA9FCBD6EBD939ECE742634F52,
	ScoreTracker_GameOver_m7C1CD78FEDC664F2A61118138E1CD1E55CF9BD9F,
	ScoreTracker__ctor_mF1425BBD406E0C988CF84765B919C0F4C832ED3E,
	ShootAM_Start_m8DC4D3E1BF75C29A1036A180F702E288DC12981C,
	ShootAM_PlaySound_m27012327808F961669D9E3564CA494D5E60D55A0,
	ShootAM__ctor_m2230FAA02B5B7F2044D95773365D668A9AD4D450,
	ShootBomb_Start_mD1EE111A364236D07ADB2337D4947D7DA3ACD735,
	ShootBomb_OnTriggerEnter2D_m7611290EED6A5FD551B27B90300AE61605E47222,
	ShootBomb__ctor_m3DD1B217CED6080E2B245963788C684C0A7E3789,
	ShootMenu_LoadMenu_m46762EA7F99D069F48BB6A7E4866C54BD752C30D,
	ShootMenu__ctor_mC3F6CA874DCD6459327917016E83A82D6C455282,
	ShootReward_Start_mE41366D07EBA4DE15EF08D7A0F34B1305D87F104,
	ShootReward_ShowRewardedVideo_m08DEEF32A4D1BEC80F133A9D15B5463D39EF6EE9,
	ShootReward_OnUnityAdsReady_mE13D5B061DD03FE97F1BC802713A0E1B8B3FCF78,
	ShootReward_OnUnityAdsDidFinish_mA9F62C02D21A3D74EE187ACC408F7FA9DF41D5CB,
	ShootReward_OnUnityAdsDidError_m2EA4892D7EC6A3650EE7FA590D3514E2BEEB8F65,
	ShootReward_OnUnityAdsDidStart_m9DF4B56070646582C0FF14A03E23DB8F422D40F5,
	ShootReward__ctor_mD68DE4554D086AA6FE824518F6D6088AF84DAF66,
	ShopControl_Start_mD449C80429C8F6631E8AB1D11F901C20F6DBE3B9,
	ShopControl_Update_m1B5795C33A7CA460263A727367D62E866A7C8A94,
	ShopControl_buyVirus_mB7818C3195A915A236954EB08321C12EA9935809,
	ShopControl_resetPlayerPrefs_mEA1440AC727B3D6CB9569D77EDF4C105027619D5,
	ShopControl__ctor_m314EE77699352D462E71DA6E61698CE8B9D66786,
	ShotControl_Start_mD15539B71D300EE63D703FCC5F2CBFEF5F51177C,
	ShotControl_Update_mCF2882E75CBBF408A0AF210E6BB1C099661E4E64,
	ShotControl__ctor_mE82B524257A52175FF50654FA99A23F74001F058,
	Sound__ctor_m4594F1F1D68380A13C70A564C5C164901D725D44,
	SoundManager_Start_mB9D238182CC4B1023DE4C4D331E88EFB7E82F24F,
	SoundManager_Update_mA43265016234A06D51D1D96DAB646B758F6E4AB6,
	SoundManager__ctor_mFF8C696A5B666ABC1E2344581FE7FB06E038D422,
	Spawner_Start_mEA70C3EA61603E141DD386EC98864D2A80917900,
	Spawner_Update_mBBD680767D87C19E6B68AF774A049579F270A44E,
	Spawner__ctor_mA37BC0F6624E147B76FC192F6E53162998BCA0A5,
	StartMenu_PlayGame_mBAEFD143AAD31DD3708C50E90926987448F2E3D6,
	StartMenu_PlayHard_mB49F3E636E8AEDD5718AD935030088CB13FD4422,
	StartMenu_PlayCatch_m68EFFBEDDEE5B5753EBBCA300CA63D574623606F,
	StartMenu_Shop_m0213CF34B29312A9943DE97F837BFAB9011BADEA,
	StartMenu_QuitGame_mD9B21796AA52121FCE4C66E97B0D936A9B053D9A,
	StartMenu__ctor_mFE9B9682B9BBA1E057D5037188C932B5A77F8CE6,
	TMP_Update_m585303DE1012952E04D16ACBFFFEB5539F154153,
	TMP__ctor_m9A6D959D87D36ADA79D893BC40D35C8916151F98,
	TestSpawn_Start_m32F0390A74FDFA3FDE463E26B042840E6F3E24A9,
	TestSpawn_spawnEnemy_mF427E003628BAC54D157E558FE398FBDDA905383,
	TestSpawn_asteroidWave_m6AE9BD629E71D344E7A334B92BB3E638A49CBD8D,
	TestSpawn__ctor_m3424A5C0772CCE3330276C3370F412059D34D3A2,
	Virus1_Start_mFC03FAA0B7E45CE03AD1F16C8AABCF78C6385AE7,
	Virus1_Update_m7FE96DFD0B6D1B2319F97BFA1F5699664027A913,
	Virus1__ctor_mDE5F40446549F2B1485A83E2616E99F66B7058FB,
	Weapon_Update_mD65E9FD544FEE0974CED54FA39BB05A89FB6D99E,
	Weapon_Shoot_mF5B36E6C4428C1E8858F42526F5EEC7C7AF9D4E3,
	Weapon__ctor_mF7C215ECC1D7032E6DE76DE606A9159F840B62FB,
	back_BackButton_mDC05AAD2E262033B6374481666A6487078014694,
	back__ctor_mAEA62A3E124D04834F2C88189BAB1C27158D0D1A,
	bomb_Start_mA57F25109EAD258B089DB14F86774E77DD37DE31,
	bomb_OnTriggerEnter2D_m8530B9067160E6E77CB6C2D531FB428380A8DDFE,
	bomb__ctor_m9FD2695E5549D32964B3D6D4984E0C9EBF65F23D,
	catchDoubler_Start_m01C00C4BB40342C83BC3A542135F8AA69E31CBFA,
	catchDoubler_Update_m1741DC6DDB78BBE3146C0FAFF0DF04533E1D2B60,
	catchDoubler__ctor_m89A0C44885A58C4568C728A3EF6E65DB20F352B5,
	coin_Start_mE53E845441EF04E468CF50496C6A8828694EA296,
	coin_OnTriggerEnter2D_m6E3D7A0080F1C1EB62DE1B54344FD606FCEF9CF4,
	coin__ctor_mEEB2E0AE11DFC930658FFA5DF694A494C6E4C789,
	doubler_Start_m407F74D273BEF373109EC321360F27F064BFD444,
	doubler_OnTriggerEnter2D_m9F181ABDF4A940D4108DC95A6810694796F467D0,
	doubler__ctor_m38F0150C162CEC7080076A6E4D1E8042BBFC5827,
	freeze_Start_mBE48C56A85921EE0D9C7C531AF17F287FA5228D6,
	freeze_OnTriggerEnter2D_mBE189F6624A8D5DF78A07208CA748E473FB7B716,
	freeze__ctor_m400C3D97ECF7CAF42C0162C5B75E78DC31319F7F,
	restartCatch_RestartGame_m6F29261CB6B68A3F1294DF4E40C9510A9E8BE93A,
	restartCatch__ctor_m24EE53F73CAFFCCF1E7A34413FF586D5D0E92088,
	SettingsMenu_SetVolume_m8EBB34A1A9F07559F73F8EFE957B3771D54756FC,
	SettingsMenu__ctor_m038E1040393AAD26365313BCF704FB6FF638D065,
	ChatController_OnEnable_m168B1E78BFA288F42D4AE0A8F1424B8D68B07993,
	ChatController_OnDisable_m49C4A6501BCC216F924B3C37F243D1B5B54A69FF,
	ChatController_AddToChatOutput_m5E6DF0E37CB2E9FBBEACCB6EEE6452AB14BBE94C,
	ChatController__ctor_m2C7AAB67386BA2DC6742585988B914B3FAB30013,
	DropdownSample_OnButtonClick_mEAC0F8D33D13DE84DCEA5D99E5162E4D28F6B54D,
	DropdownSample__ctor_m901DB807D4DFA75581306389B7A21072E98E72A0,
	EnvMapAnimator_Awake_mDDD10A405C7152BEFA0ECEA0DCBD061B47C5802E,
	EnvMapAnimator_Start_m630E0BFAB4D647BC38B99A70F522EF80D25F3C71,
	EnvMapAnimator__ctor_m2A8770DA2E27EC52F6A6F704831B732638C76E84,
	WinGame_WinIt_m80DCFEEEBB7E4BA6CFA653204C0AD2F6DDBE2379,
	WinGame_ReturnIt_m2587EDAA56355D4EA808CA1F6A5F87249CF47542,
	WinGame__ctor_mA8DA79C5B3918EC310D2899B22AF6B11976FE2CA,
	TMP_DigitValidator_Validate_mEC7653F2228D8AA66F69D6B3539ED342AEE57691,
	TMP_DigitValidator__ctor_m4E1C1BEB96F76F2EE55E6FEC45D05F2AAC5DF325,
	TMP_PhoneNumberValidator_Validate_mBE0169BE01459AA37111A289EC422DDB0D5E3479,
	TMP_PhoneNumberValidator__ctor_mBF81DE006E19E49DAC3AFF685F8AF268A2FD0FFB,
	TMP_TextEventHandler_get_onCharacterSelection_mF70DBE3FF43B3D6E64053D37A2FADF802533E1FF,
	TMP_TextEventHandler_set_onCharacterSelection_mDEC285B6A284CC2EC9729E3DC16E81A182890D21,
	TMP_TextEventHandler_get_onSpriteSelection_m395603314F8CD073897DCAB5513270C6ADD94BF4,
	TMP_TextEventHandler_set_onSpriteSelection_m3D4E17778B0E3CC987A3EF74515E83CE39E3C094,
	TMP_TextEventHandler_get_onWordSelection_m415F4479934B1739658356B47DF4C2E90496AE2E,
	TMP_TextEventHandler_set_onWordSelection_m2EDD56E0024792DCE7F068228B4CA5A897808F4E,
	TMP_TextEventHandler_get_onLineSelection_m8E724700CC5DF1197B103F87156576A52F62AB2B,
	TMP_TextEventHandler_set_onLineSelection_m067512B3F057A225AF6DD251DD7E546FFF64CD93,
	TMP_TextEventHandler_get_onLinkSelection_m221527467F0606DD3561E0FB0D7678AA8329AD5D,
	TMP_TextEventHandler_set_onLinkSelection_mE3CE372F9FECD727FAB3B14D46439E0534EE8AA8,
	TMP_TextEventHandler_Awake_m67A37475531AC3EB75B43A640058AD52A605B8D9,
	TMP_TextEventHandler_LateUpdate_mB0ABBED08D5494DFFF85D9B56D4446D96DDBDDF5,
	TMP_TextEventHandler_OnPointerEnter_mE1CAF8C68C2356069FEB1AA1B53A56E24E5CE333,
	TMP_TextEventHandler_OnPointerExit_mB429546A32DCF6C8C64E703D07F9F1CDC697B009,
	TMP_TextEventHandler_SendOnCharacterSelection_mFBFC60A83107F26AA351246C10AB42CEB3A5A13C,
	TMP_TextEventHandler_SendOnSpriteSelection_mAB964EB5171AB07C48AC64E06C6BEC6A9C323E09,
	TMP_TextEventHandler_SendOnWordSelection_m3B76D7E79C65DB9D8E09EE834252C6E33C86D3AE,
	TMP_TextEventHandler_SendOnLineSelection_m9E9CAD5FA36FCA342A38EBD43E609A469E49F15F,
	TMP_TextEventHandler_SendOnLinkSelection_m1C55C664BB488E25AE746B99438EEDAE5B2B8DE8,
	TMP_TextEventHandler__ctor_m189A5951F5C0FA5FB1D0CFC461FAA1EBD7AED1AE,
	Benchmark01_Start_m20668FA5AD3945F18B5045459057C330E0B4D1F4,
	Benchmark01__ctor_m40EDCD3A3B6E8651A39C2220669A7689902C8B36,
	Benchmark01_UGUI_Start_mE8F5BC98EC6C16ECEBAD0FD78CD63E278B2DF215,
	Benchmark01_UGUI__ctor_m7F24B3D019827130B3D5F2D3E8C3FF23425F98BE,
	Benchmark02_Start_m3F848191079D3EF1E3B785830D74698325CA0BB7,
	Benchmark02__ctor_m3323414B806F63563E680918CC90EAF766A3D1AE,
	Benchmark03_Awake_m261B7F2CD25DC9E7144B2A2D167219A751AD9322,
	Benchmark03_Start_m649EFCC5BF0F199D102083583854DE87AC5EFBDD,
	Benchmark03__ctor_m90649FDE30CC915363C5B61AA19A7DE874FF18ED,
	Benchmark04_Start_mFDF88CB6DD4C5641A418DB08E105F9F62B897777,
	Benchmark04__ctor_mB07A2FD29BE4AFE284B47F2F610BDB7539F5A5DE,
	CameraController_Awake_m5E24687E6D82C0EBC4984D01B90769B8FD8C38B3,
	CameraController_Start_m257B81C6062A725785739AFE4C0DF84B8931EFB2,
	CameraController_LateUpdate_m9660F57BCF4F8C2154D19B6B40208466E414DAEB,
	CameraController_GetPlayerInput_m0B63EA708A63AF6852E099FD40F7C4E18793560A,
	CameraController__ctor_m8379776EEE21556D56845974B8C505AAD366B656,
	ObjectSpin_Awake_m2E5B2D7FA6FE2F3B5516BD829EDC5522187E6359,
	ObjectSpin_Update_mF8175B9157B852D3EC1BAF19D168858A8782BF0D,
	ObjectSpin__ctor_m1F951082C07A983F89779737E5A6071DD7BA67EB,
	ShaderPropAnimator_Awake_m44ACA60771EECABCB189FC78027D4ECD9726D31A,
	ShaderPropAnimator_Start_m57178B42FF0BB90ACA497EC1AA942CC3D4D54C32,
	ShaderPropAnimator_AnimateProperties_mB34C25C714FAEA4792465A981BAE46778C4F2409,
	ShaderPropAnimator__ctor_mDFAE260FD15CD3E704E86A25A57880A33B817BC6,
	SimpleScript_Start_m0238BE0F5DF0A15743D4D4B1B64C0A86505D1B76,
	SimpleScript_Update_mB92D578CAC3E0A0AFB055C7FEF47601C8822A0F8,
	SimpleScript__ctor_m0E919E8F3C12BAFF36B17E5692FCFA5AE602B2AA,
	SkewTextExample_Awake_mC70E117C1F921453D2F448CABA234FAA17A277ED,
	SkewTextExample_Start_mE2308836BF90B959ABE6064CD2DDDFAF224F0F4A,
	SkewTextExample_CopyAnimationCurve_m3CE7B666BEF4CFFE9EB110C8D57D9A5F6385720B,
	SkewTextExample_WarpText_m8B756AF1E1C065EEA486159E6C631A585B0C3461,
	SkewTextExample__ctor_m44F3CBD12A19C44A000D705FB4AB02E20432EC02,
	TMP_ExampleScript_01_Awake_mE2AAB8DF142D7BDB2C041CC7552A48745DBFDCFF,
	TMP_ExampleScript_01_Update_m1593A7650860FD2A478E10EA12A2601E918DD1EC,
	TMP_ExampleScript_01__ctor_m313B4F7ED747AD6979D8909858D0EF182C79BBC3,
	TMP_FrameRateCounter_Awake_m2540DCD733523BCBB1757724D8546AC3F1BEB16C,
	TMP_FrameRateCounter_Start_mEF10D80C419582C6944313FD100E2FD1C5AD1319,
	TMP_FrameRateCounter_Update_mF4798814F4F86850BB9248CA192EF5B65FA3A92B,
	TMP_FrameRateCounter_Set_FrameCounter_Position_m19C3C5E637FB3ED2B0869E7650A1C30A3302AF53,
	TMP_FrameRateCounter__ctor_m55E3726473BA4825AC0B7B7B7EA48D0C5CE8D646,
	TMP_TextEventCheck_OnEnable_mAFF9E7581B7B0C93A4A7D811C978FFCEC87B3784,
	TMP_TextEventCheck_OnDisable_m270DBB9CC93731104E851797D6BF55EACAE9158A,
	TMP_TextEventCheck_OnCharacterSelection_m4394BE3A0CA37D319AA10BE200A26CFD17EEAA8F,
	TMP_TextEventCheck_OnSpriteSelection_mCBF0B6754C607CA140C405FF5B681154AC861992,
	TMP_TextEventCheck_OnWordSelection_m4C290E23BBA708FE259A5F53921B7B98480E5B08,
	TMP_TextEventCheck_OnLineSelection_mF68BE3244AFD53E84E037B39443B5B3B50336FF5,
	TMP_TextEventCheck_OnLinkSelection_m23569DD32B2D3C4599B8D855AE89178C92BA25C7,
	TMP_TextEventCheck__ctor_m4B49D7387750432FA7A15A804ABD6793422E0632,
	TMP_TextInfoDebugTool__ctor_m2A2D1B42F97BD424B7C61813B83FE46C91575EFB,
	TMP_TextSelector_A_Awake_mEE6FCD85F7A6FDA4CC3B51173865E53F010AB0FF,
	TMP_TextSelector_A_LateUpdate_mF02F95A5D14806665404997F9ABAEE288A9879A0,
	TMP_TextSelector_A_OnPointerEnter_m6D15B2FC399C52D9706DD85C796BAE40CA8362D3,
	TMP_TextSelector_A_OnPointerExit_m080D05700B1D3251085331369FCD2A131D45F963,
	TMP_TextSelector_A__ctor_m6AB8BC86973365C192CF9EACA61459F2E0A5C88D,
	TMP_TextSelector_B_Awake_m87D2FCFCEDEE1FA82DEF77A867D2DE56C3AA0973,
	TMP_TextSelector_B_OnEnable_mD1C87684FD94190654176B38EE7DC960795F08E8,
	TMP_TextSelector_B_OnDisable_m429F83E18507E278CA9E9B5A2AE891087ED0D830,
	TMP_TextSelector_B_ON_TEXT_CHANGED_m91D0E180681C5566066C366487B94A05FB376B12,
	TMP_TextSelector_B_LateUpdate_m80F8343FAB19617468E94CD2B35636DBB9AC2064,
	TMP_TextSelector_B_OnPointerEnter_m9A938ED5B0D70633B9099F5C1B213FD50380116D,
	TMP_TextSelector_B_OnPointerExit_mD481099225DF156CA7CA904AA1C81AF26A974D28,
	TMP_TextSelector_B_OnPointerClick_mE4A6507E55DD05BBC99F81212CF26F2F11179FBE,
	TMP_TextSelector_B_OnPointerUp_m5E52652A02A561F2E8AB7F0C00E280C76A090F74,
	TMP_TextSelector_B_RestoreCachedVertexAttributes_m01B9A1E989D57BE8837E99C4359BCB6DD847CB35,
	TMP_TextSelector_B__ctor_mC42D87810C72234A3360C0965CC1B7F45AB4EE26,
	TMP_UiFrameRateCounter_Awake_mFAF9F495C66394DC36E9C6BC96C9E880C4A3B0A9,
	TMP_UiFrameRateCounter_Start_mC4A3331333B1DFA82B184A0701FCE26395B8D301,
	TMP_UiFrameRateCounter_Update_mCA98BB5342C50F9CE247A858E1942410537E0DAF,
	TMP_UiFrameRateCounter_Set_FrameCounter_Position_mDD0EAB08CE58340555A6654BDD5BEE015E6C6ACE,
	TMP_UiFrameRateCounter__ctor_mE3DC8B24D2819C55B66AEAEB9C9B93AFDA9C4573,
	TMPro_InstructionOverlay_Awake_m951573D9BF0200A4C4605E043E92BBD2EB33BA7C,
	TMPro_InstructionOverlay_Set_FrameCounter_Position_m39D0BB71DCCB67271B96F8A9082D7638E4E1A694,
	TMPro_InstructionOverlay__ctor_m103EF0B8818B248077CB97909BA806477DCEB8A5,
	TeleType_Awake_m3501F8FA1B762D22972B9B2BAC1E20561088882B,
	TeleType_Start_m2A3F19E0F9F2C72D48DDF5A4208AF18AE7769E69,
	TeleType__ctor_m8B985E4023A01F963A74E0FE5E8758B979FB3C3A,
	TextConsoleSimulator_Awake_m8B1E7254BFB2D0C7D5A803AEFAFCD1B5327F79AD,
	TextConsoleSimulator_Start_m85E6334AFE22350A5715F9E45843FD865EF60C9D,
	TextConsoleSimulator_OnEnable_mB6F523D582FE4789A5B95C086AA7C168A5DD5AF7,
	TextConsoleSimulator_OnDisable_m1EF25B5345586DD26BB8615624358EFB21B485DB,
	TextConsoleSimulator_ON_TEXT_CHANGED_mD4A85AE6FE4CD3AFF790859DEFB7E4AAF9304AE5,
	TextConsoleSimulator_RevealCharacters_m7BF445A3B7B6A259450593775D10DE0D4BD901AD,
	TextConsoleSimulator_RevealWords_mD7D62A1D326528506154148148166B9196A9B903,
	TextConsoleSimulator__ctor_mA40DB76E1D63318E646CF2AE921084D0FDF4C3CA,
	TextMeshProFloatingText_Awake_mB40A823A322B9EFD776230600A131BAE996580C3,
	TextMeshProFloatingText_Start_mBFC04A0247294E62BD58CB3AC83F85AE61C3FB4F,
	TextMeshProFloatingText_DisplayTextMeshProFloatingText_mB0DEABA5CC4A6B556D76ED30A3CF08E7F0B42AFC,
	TextMeshProFloatingText_DisplayTextMeshFloatingText_m8AB7E0B8313124F67FEDE857012B9E56397147E2,
	TextMeshProFloatingText__ctor_m610430DD6E4FD84EBF6C499FB4415B5000109627,
	TextMeshSpawner_Awake_m31920E8DD53AD295AAD8B259391A28E1A57862ED,
	TextMeshSpawner_Start_m189316ED7CD62EFD10B40A23E4072C2CEB5A516B,
	TextMeshSpawner__ctor_m3995DDE2D7E7CBF8087A3B61242F35E09AC94668,
	VertexColorCycler_Awake_m19D37F0DDC4E1D64EA67101852383862DCAAED1E,
	VertexColorCycler_Start_m2CFBFF7F45A76D16C29B570E3468AFEEC2D1C443,
	VertexColorCycler_AnimateVertexColors_mDB7F380B912148C792F857E42BFB042C6A267260,
	VertexColorCycler__ctor_mBAF42937750A7A22DB5BF09823489FDE25375816,
	VertexJitter_Awake_m32ACAC43EDE2595CD4FFB6802D58DEBC0F65B52C,
	VertexJitter_OnEnable_m63CC97434F60690EE234794C9C2AD3B25EC69486,
	VertexJitter_OnDisable_mE5E221B893D3E53F3A9516082E2C4A9BE174DDF5,
	VertexJitter_Start_mC977D71742279824F9DD719DD1F5CB10269BC531,
	VertexJitter_ON_TEXT_CHANGED_mE5AE5146D67DA15512283617C41F194AEDD6A4AC,
	VertexJitter_AnimateVertexColors_m6B361C3B93A2CC219B98AACFC59288432EE6AC1E,
	VertexJitter__ctor_mD5B5049BB3640662DD69EB1E14789891E8B2E720,
	VertexShakeA_Awake_m6075DA429A021C8CB3F6BE9A8B9C64127288CD19,
	VertexShakeA_OnEnable_m39AA373478F796E7C66763AA163D35811721F5CD,
	VertexShakeA_OnDisable_mA087E96D94CB8213D28D9A601BC25ED784BB8421,
	VertexShakeA_Start_mDED2AEA47D2E2EF346DE85112420F6E95D9A3CFD,
	VertexShakeA_ON_TEXT_CHANGED_m0B59A798E6B193FE68F6A20E7004B223D5A2993E,
	VertexShakeA_AnimateVertexColors_m238AB73BE06E33312281577CC896CEB7BB175245,
	VertexShakeA__ctor_m41CBBA607D90D45E21C98CCDF347AE27FB50392F,
	VertexShakeB_Awake_m7CBA45BF5135680A823536A18325ECA621EF7A1A,
	VertexShakeB_OnEnable_m39EBB983A4FFFF6DD1C7923C8C23FF09CFF2F6E2,
	VertexShakeB_OnDisable_m8E3858FC1C976F311628466C411675E352F134A5,
	VertexShakeB_Start_m666FA35D389B109F01A5FC229D32664D880ADE09,
	VertexShakeB_ON_TEXT_CHANGED_mF4858E4385EAA74F5A3008C50B8AD180FCBC8517,
	VertexShakeB_AnimateVertexColors_m076A6C9D71EE8B5A54CD1CEDCA5AB15160112DD3,
	VertexShakeB__ctor_m5CAAD9DFA7B4D9C561473D53CA9E3D8B78AE5606,
	VertexZoom_Awake_mB18FF89A84E2AA75BDD486A698955A58E47686EE,
	VertexZoom_OnEnable_mCD27B81253963B3D0CD2F6BA7B161F0DFDC08114,
	VertexZoom_OnDisable_mB32AD5B7DFF20E682BA4FC82B30C87707DD3BA10,
	VertexZoom_Start_m6C64C692D81F64FB7F3244C3F0E37799B159A0DE,
	VertexZoom_ON_TEXT_CHANGED_mC08504F9622CC709271C09EDB7A0DF1A35E45768,
	VertexZoom_AnimateVertexColors_mEC9842E0BC31D9D4E66FD30E6467D5A9A19034D6,
	VertexZoom__ctor_mA4381FC291E17D67EA3C2292EAB8D3C959ADEA79,
	WarpTextExample_Awake_mF6785C4DC8316E573F20A8356393946F6ABFC88C,
	WarpTextExample_Start_m8E7AC9FF62E37EAB89F93FD0C1457555F6DCB086,
	WarpTextExample_CopyAnimationCurve_m2C738EA265E2B35868110EE1D8FCBD4F1D61C038,
	WarpTextExample_WarpText_m27664A46276B3D615ECB12315F5E77C4F2AF29EE,
	WarpTextExample__ctor_mF5BA8D140958AD2B5D2C8C5DE937E21A5D283C9F,
	U3CU3Ec__DisplayClass4_0__ctor_mD15F906116CC6029665A46B6EADB889EEBD95482,
	U3CU3Ec__DisplayClass4_0_U3CPlayU3Eb__0_mC9DE38DAF580450EE856067B6A57EBC3866414E3,
	U3CU3Ec__DisplayClass5_0__ctor_m3559510BE1F66D8395B63621884097F380366B1F,
	U3CU3Ec__DisplayClass5_0_U3CStopPlayingU3Eb__0_m2F4489418F7F6635FA1BDF451174A2B33B9EA5EA,
	U3CShowBannerWhenInitializedU3Ed__4__ctor_mC2836E9A9DD80F67F06DA1C5AF7A942F670A1941,
	U3CShowBannerWhenInitializedU3Ed__4_System_IDisposable_Dispose_mF1FF864CFDDDD03F48FEA1F3BB4AD250776A15D3,
	U3CShowBannerWhenInitializedU3Ed__4_MoveNext_mA4CBE3C67C3938D22E478FFBD1AF47B3E2BEB442,
	U3CShowBannerWhenInitializedU3Ed__4_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mCB2095A6011F88F6C2DABA15E9B42D0099AE8088,
	U3CShowBannerWhenInitializedU3Ed__4_System_Collections_IEnumerator_Reset_m4262E7FE22FDF832A2C0E331EF7EF54AB57CC4AE,
	U3CShowBannerWhenInitializedU3Ed__4_System_Collections_IEnumerator_get_Current_m5710BFA4E6BF78162D2F067D37743871016D811B,
	U3CvirusWaveU3Ed__5__ctor_m9197609079958B4DD50C0063345F58E9B4930537,
	U3CvirusWaveU3Ed__5_System_IDisposable_Dispose_mA9B0B528CB5FAB10EBA85E40D3F269A2F45B3BAF,
	U3CvirusWaveU3Ed__5_MoveNext_mA3A368256D44D033056549421218F9AF002AA655,
	U3CvirusWaveU3Ed__5_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mD04ED0DEB64C79F77540C864E988F0B1CD3C67BA,
	U3CvirusWaveU3Ed__5_System_Collections_IEnumerator_Reset_m92C01568223AA760EC0AD613F219848EF9CFAF40,
	U3CvirusWaveU3Ed__5_System_Collections_IEnumerator_get_Current_m36D462B71EAC94FAB8B163376D2D34FCC5267204,
	U3CWaitThenRestoreTimeU3Ed__5__ctor_mA99DB7F931F9EFB1A4C0644EFD077DF8B434040C,
	U3CWaitThenRestoreTimeU3Ed__5_System_IDisposable_Dispose_m76E6850E12EB3AD2C74009D7CD1C69A447CF23F4,
	U3CWaitThenRestoreTimeU3Ed__5_MoveNext_mB96607326F84C1F6E19C96A3206E77DF4BD59EE3,
	U3CWaitThenRestoreTimeU3Ed__5_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m0A807B235A231477720E0BCEF3B6CA0898BB4A07,
	U3CWaitThenRestoreTimeU3Ed__5_System_Collections_IEnumerator_Reset_m9026594DCEBE5570839D267F771473F4F43DA2CD,
	U3CWaitThenRestoreTimeU3Ed__5_System_Collections_IEnumerator_get_Current_mB44EE192736790F1DCFA42A6433354B2C344C2A7,
	U3CasteroidWaveU3Ed__5__ctor_mC75A77524B0F328A32B5E8F8CB69300DCBCD5599,
	U3CasteroidWaveU3Ed__5_System_IDisposable_Dispose_mCADB2A23975A0EA92E1968803419AF5E1D6687E3,
	U3CasteroidWaveU3Ed__5_MoveNext_mC0B2C5EEE45D3C3457615B0E1BE7599CC44B0C5E,
	U3CasteroidWaveU3Ed__5_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m0C2CCC3CF9BA6FF97234D61499A6BD80CF91D413,
	U3CasteroidWaveU3Ed__5_System_Collections_IEnumerator_Reset_m49AA25E6533152B71D1D5BEF531353E3CCA0E207,
	U3CasteroidWaveU3Ed__5_System_Collections_IEnumerator_get_Current_m4647ABDB7FE78877DB5CF9FDDCF8D3AF8D318A80,
	U3CStartU3Ed__4__ctor_m8B0264798939C569742263D32E0054DBAB9AE6FF,
	U3CStartU3Ed__4_System_IDisposable_Dispose_m3EFE2ADAD412045F666CFA1C8C9FF53AF92CBD75,
	U3CStartU3Ed__4_MoveNext_m84F94A5CD6012300AC80698CDCA870A0A146E226,
	U3CStartU3Ed__4_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m129CB3E5CAFFA1D19D4988182EEF116F2086A637,
	U3CStartU3Ed__4_System_Collections_IEnumerator_Reset_m345E255900454CC505A8AAE3BF6AEF3C06467EAB,
	U3CStartU3Ed__4_System_Collections_IEnumerator_get_Current_m5920F51DCC2DC7C8BC98EE95D6CD4D7784997272,
	CharacterSelectionEvent__ctor_mE2C306B8090F90261252C94D26AB5085580B11D5,
	SpriteSelectionEvent__ctor_m9D9F101CB717ACD5449336DFFF70F86AE32BB6EC,
	WordSelectionEvent__ctor_mFD7F2937426D4AA1A8CBB13F62C3CC1D2061AD1E,
	LineSelectionEvent__ctor_mA23AFEC8E11183CF472044FA72B07AD28ED6E675,
	LinkSelectionEvent__ctor_m02CC491DBE4B2FF05A8FD4285813215ED3D323E5,
	U3CStartU3Ed__10__ctor_m328932E4B6124311CD738F2F84F69BC149209129,
	U3CStartU3Ed__10_System_IDisposable_Dispose_m209F531CE6ED7F07649497DD15817C1D7C1880A1,
	U3CStartU3Ed__10_MoveNext_mD927C85D41034011055A7CA3AFFAF4E10464F65D,
	U3CStartU3Ed__10_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m18BA91C8A20CBD6976D52E335563D9B42C1AE9A8,
	U3CStartU3Ed__10_System_Collections_IEnumerator_Reset_m5A67B5BDE759A157229E6CF24E653B79B2AC0200,
	U3CStartU3Ed__10_System_Collections_IEnumerator_get_Current_mA521C1EFA357A9F4F4CAA68A4D0B85468764323C,
	U3CStartU3Ed__10__ctor_m9A8C7C0644996520AD443A4F7CA527BF05C54C3C,
	U3CStartU3Ed__10_System_IDisposable_Dispose_m94D1420C08F57F2901E2499D36778BB8F1C76932,
	U3CStartU3Ed__10_MoveNext_m31AF957FFAEEED4BE0F39A1185C6112C4EB6F7AA,
	U3CStartU3Ed__10_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m39B535B222104759319A54A6D7E2E81482A1F71E,
	U3CStartU3Ed__10_System_Collections_IEnumerator_Reset_mC2B435140D045B6A20FB105E0E2CBD625218CA74,
	U3CStartU3Ed__10_System_Collections_IEnumerator_get_Current_m9A98CCB7604AAD93919CAE48955C6A6CB8C38790,
	U3CAnimatePropertiesU3Ed__6__ctor_mB5F6ED6FCDA5BEAD56E22B64283D7A4D7F7EAE71,
	U3CAnimatePropertiesU3Ed__6_System_IDisposable_Dispose_m29AAE9560CA4EEB4A548A68ACA085EC9E4CB8EA5,
	U3CAnimatePropertiesU3Ed__6_MoveNext_m4F2D37B672E95820F49489611196CDE334736157,
	U3CAnimatePropertiesU3Ed__6_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m21D2B0A0B0CADF520D05FE4948F1DE94CF119630,
	U3CAnimatePropertiesU3Ed__6_System_Collections_IEnumerator_Reset_m1E942C0FD32005FDBB182CF646FD2312BA273BC7,
	U3CAnimatePropertiesU3Ed__6_System_Collections_IEnumerator_get_Current_mFC3602799F1D07BB002093DFB879FC759384FDD3,
	U3CWarpTextU3Ed__7__ctor_mA03118DB0FD3BF160500E127D1FACDAF45313047,
	U3CWarpTextU3Ed__7_System_IDisposable_Dispose_m9D7F6A90DA911D77EE72A2824FF9690CED05FBC8,
	U3CWarpTextU3Ed__7_MoveNext_m7FE0DD003507BAD92E35CC5DACE5D043ADD766ED,
	U3CWarpTextU3Ed__7_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m349F81ECD49FF12E4009E2E56DB81974D68C6DAD,
	U3CWarpTextU3Ed__7_System_Collections_IEnumerator_Reset_m3122CE754238FB7815F7ABE8E7DFAF3AB7B03278,
	U3CWarpTextU3Ed__7_System_Collections_IEnumerator_get_Current_m79BF250C4ADC29ACF11370E2B5BD4FFD78709565,
	U3CStartU3Ed__4__ctor_m8231909D78A27061165C450481E233339F300046,
	U3CStartU3Ed__4_System_IDisposable_Dispose_m6886DB5D83361607B72BBCCB7D484B9C0BFE1981,
	U3CStartU3Ed__4_MoveNext_m1CD1306C9E074D3F941AC906A48D3CA97C148774,
	U3CStartU3Ed__4_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mE50AC5FA9F27773C51DD3E4188A748BA0A513F8A,
	U3CStartU3Ed__4_System_Collections_IEnumerator_Reset_m5D6EE5C4B2C20A433129D8BFD13DFC82681346A2,
	U3CStartU3Ed__4_System_Collections_IEnumerator_get_Current_m1FA5600514131056D8198F8442F37A4A22A9F065,
	U3CRevealCharactersU3Ed__7__ctor_m48510711FC78DFEA9CF4603E1E75F4DF7C5F1489,
	U3CRevealCharactersU3Ed__7_System_IDisposable_Dispose_m5B88486625A74566DF3FC7BFB4CE327A58C57ED4,
	U3CRevealCharactersU3Ed__7_MoveNext_mE45076151810A7C1F83802B7754DE92E812EABAB,
	U3CRevealCharactersU3Ed__7_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m9C330834C7113C8468CC1A09417B7C521CAE833B,
	U3CRevealCharactersU3Ed__7_System_Collections_IEnumerator_Reset_m25B719FFD0CAB1DFF2853FF47A4EE2032176E287,
	U3CRevealCharactersU3Ed__7_System_Collections_IEnumerator_get_Current_m9A540E1B18E93F749F4BFD4C8597AEC9F2C199F7,
	U3CRevealWordsU3Ed__8__ctor_mDF41BA5FE3D53FEC3CB8214FCA7853A1142DE70C,
	U3CRevealWordsU3Ed__8_System_IDisposable_Dispose_m46827499CD3657AF468926B6302D2340ED975965,
	U3CRevealWordsU3Ed__8_MoveNext_mE0CB1189CFAD7F7B3E74438A4528D9BFAABB48DE,
	U3CRevealWordsU3Ed__8_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m4A3E941DF6C67BC9ACEFEAA09D11167B3F3A38EC,
	U3CRevealWordsU3Ed__8_System_Collections_IEnumerator_Reset_m967B427886233CDB5DFFEA323F02A89CE9330CC8,
	U3CRevealWordsU3Ed__8_System_Collections_IEnumerator_get_Current_m0C1B2941BEC04593993127F6D9DCDBA6FAE7CC20,
	U3CDisplayTextMeshProFloatingTextU3Ed__12__ctor_m13B7271203EDC80E649C1CE40F09A93BDA2633DF,
	U3CDisplayTextMeshProFloatingTextU3Ed__12_System_IDisposable_Dispose_m3D1611AA38746EF0827F5260DADCC361DD56DF0C,
	U3CDisplayTextMeshProFloatingTextU3Ed__12_MoveNext_m03111B7039F928512A7A53F8DA9C04671AA8D7EE,
	U3CDisplayTextMeshProFloatingTextU3Ed__12_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m55B08E77035437C2B75332F29214C33214417414,
	U3CDisplayTextMeshProFloatingTextU3Ed__12_System_Collections_IEnumerator_Reset_m6737F2D695AB295240F15C5B0B4F24A59106BFDA,
	U3CDisplayTextMeshProFloatingTextU3Ed__12_System_Collections_IEnumerator_get_Current_m6BD4D2442BDDDFB6859CFE646182580A0A1E130A,
	U3CDisplayTextMeshFloatingTextU3Ed__13__ctor_m7E4C3B87E56A7B23D725D653E52ADE02554EAE3E,
	U3CDisplayTextMeshFloatingTextU3Ed__13_System_IDisposable_Dispose_m485A7C4CF3496858A72CBA647B29BC610F39FE39,
	U3CDisplayTextMeshFloatingTextU3Ed__13_MoveNext_m6A3C88B1149D12B58E6E580BC04622F553ED1424,
	U3CDisplayTextMeshFloatingTextU3Ed__13_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m2EE54B2AC8AAE44BACF8EE8954A6D824045CFC55,
	U3CDisplayTextMeshFloatingTextU3Ed__13_System_Collections_IEnumerator_Reset_m8524C9700DEF2DE7A28BBFDB938FE159985E86EE,
	U3CDisplayTextMeshFloatingTextU3Ed__13_System_Collections_IEnumerator_get_Current_m2293C6A327D4D1CCC1ACBC90DBE00DC1C6F39EBE,
	U3CAnimateVertexColorsU3Ed__3__ctor_m3D7543ED636AFCD2C59E834668568DB2A4005F6A,
	U3CAnimateVertexColorsU3Ed__3_System_IDisposable_Dispose_m3F7092E831D4CFDACC5B6254958DFEC2D313D0EE,
	U3CAnimateVertexColorsU3Ed__3_MoveNext_mC0D42DAE0A614F2B91AF1F9A2F8C0AF471CA0AE4,
	U3CAnimateVertexColorsU3Ed__3_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m6597EE639379454CADA3823A1B955FEFBAF894BD,
	U3CAnimateVertexColorsU3Ed__3_System_Collections_IEnumerator_Reset_m9943586181F26EEE58A42138CE0489DDF07EA359,
	U3CAnimateVertexColorsU3Ed__3_System_Collections_IEnumerator_get_Current_m2D4E4AA5EEB4F07F283E61018685199A4C2D56BD,
	U3CAnimateVertexColorsU3Ed__11__ctor_mC74A801C40038DA74D856FACFBAD12F3BC3E11E7,
	U3CAnimateVertexColorsU3Ed__11_System_IDisposable_Dispose_m07C61223FC885322B6066E81CB130879661D5A72,
	U3CAnimateVertexColorsU3Ed__11_MoveNext_m04CD6FB321DE3AD8D5890766C1F2CAAE4112EDF2,
	U3CAnimateVertexColorsU3Ed__11_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m35F5F559A34D3F9BE1E5DD636FEAF517164A6B07,
	U3CAnimateVertexColorsU3Ed__11_System_Collections_IEnumerator_Reset_m325AE901312C158848B79B302EBA7BE847C93D49,
	U3CAnimateVertexColorsU3Ed__11_System_Collections_IEnumerator_get_Current_mA688DA41E2C04FF9774F607794C114057FA055C6,
	U3CAnimateVertexColorsU3Ed__11__ctor_m89953000A887F8C0931B0E98B484FBAAC37748C5,
	U3CAnimateVertexColorsU3Ed__11_System_IDisposable_Dispose_m9AFBB2A87D38A1358F9EB09D617075D72DEED19B,
	U3CAnimateVertexColorsU3Ed__11_MoveNext_m9F607EF7DBDFFC4FB2307B0EC4C7F33EEE63BBE8,
	U3CAnimateVertexColorsU3Ed__11_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mF47F7A3AB51F9BC1B8F74E10FD82B29C1B223DCD,
	U3CAnimateVertexColorsU3Ed__11_System_Collections_IEnumerator_Reset_m99B988724C4F53F7F8334C5F633C8B1603185ADD,
	U3CAnimateVertexColorsU3Ed__11_System_Collections_IEnumerator_get_Current_mE9127628FC1726149DA7C8FE95A7D4CFB1EE1655,
	U3CAnimateVertexColorsU3Ed__10__ctor_mBA04B89258FA2EF09266E1766AB0B815E521897A,
	U3CAnimateVertexColorsU3Ed__10_System_IDisposable_Dispose_mE001B767DE85B4B3B86A0C080B9FC00381340A1C,
	U3CAnimateVertexColorsU3Ed__10_MoveNext_m611487BEE2BB82A9BFF5EA2157BDCA610F87876D,
	U3CAnimateVertexColorsU3Ed__10_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m6A54A1BF63433F860822B43ABA9FAC6A4124409C,
	U3CAnimateVertexColorsU3Ed__10_System_Collections_IEnumerator_Reset_m48F09B740CBEEC27459498932572D2869A1A4CBE,
	U3CAnimateVertexColorsU3Ed__10_System_Collections_IEnumerator_get_Current_mA915AC55E6DEE343235545FC1FE6F6CA5611DF3C,
	U3CU3Ec__DisplayClass10_0__ctor_m1C2F2204ADD6E4BA14E14CF255F520B7E2464941,
	U3CU3Ec__DisplayClass10_0_U3CAnimateVertexColorsU3Eb__0_m673C7031DB1882DEEFB53F179E3C2FB13FB6CA5A,
	U3CAnimateVertexColorsU3Ed__10__ctor_m2F5D29C1CA797C0BCEC16C8B5D96D1CF5B07F6F3,
	U3CAnimateVertexColorsU3Ed__10_System_IDisposable_Dispose_m1A43A8EA2FB689EE2B39D8A624580594374905B9,
	U3CAnimateVertexColorsU3Ed__10_MoveNext_mCA826F12F72BDBB79F9B50DC9CBC6E7F80B2110F,
	U3CAnimateVertexColorsU3Ed__10_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mFF0E754E9557C03F892EFA19C0307AECD6BA8C4D,
	U3CAnimateVertexColorsU3Ed__10_System_Collections_IEnumerator_Reset_m002A7C6C8AE61BE6CD6FD0B2173C75DBF47BCC56,
	U3CAnimateVertexColorsU3Ed__10_System_Collections_IEnumerator_get_Current_mE91B03C99FCCBC8ED4E37649C5364E83D047B053,
	U3CWarpTextU3Ed__8__ctor_m845C9410F3856EF25585F59C425200EEFCEFB3C0,
	U3CWarpTextU3Ed__8_System_IDisposable_Dispose_m63AC2AE8BC0FCF89812A33CAF150E9D1B56BAE6A,
	U3CWarpTextU3Ed__8_MoveNext_m98D3E999A69E233C7AD5F357A0D0623D731DCDAA,
	U3CWarpTextU3Ed__8_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m3971C0D86C5903812972245A6F872D101ACB5189,
	U3CWarpTextU3Ed__8_System_Collections_IEnumerator_Reset_mF17827612AC7C91DE879114D1D6428450B9504D0,
	U3CWarpTextU3Ed__8_System_Collections_IEnumerator_get_Current_m98A13A358D4E71D9612F68731A7AE11A3DD080DE,
};
static const int32_t s_InvokerIndices[560] = 
{
	23,
	26,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	26,
	124,
	26,
	26,
	23,
	23,
	23,
	23,
	23,
	26,
	26,
	23,
	23,
	14,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	26,
	23,
	23,
	23,
	23,
	26,
	23,
	23,
	111,
	23,
	23,
	26,
	23,
	23,
	26,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	26,
	124,
	26,
	26,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	14,
	23,
	23,
	26,
	23,
	3,
	23,
	23,
	23,
	26,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	26,
	23,
	23,
	14,
	23,
	23,
	23,
	23,
	23,
	26,
	23,
	23,
	23,
	276,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	26,
	23,
	23,
	26,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	276,
	23,
	23,
	23,
	23,
	23,
	23,
	26,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	300,
	23,
	34,
	34,
	87,
	32,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	276,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	26,
	124,
	26,
	26,
	23,
	23,
	23,
	23,
	111,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	111,
	23,
	23,
	26,
	23,
	23,
	23,
	23,
	23,
	26,
	124,
	26,
	26,
	23,
	23,
	23,
	23,
	26,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	14,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	26,
	23,
	23,
	23,
	23,
	23,
	26,
	23,
	23,
	26,
	23,
	23,
	26,
	23,
	23,
	23,
	276,
	23,
	23,
	23,
	26,
	23,
	23,
	23,
	23,
	14,
	23,
	23,
	23,
	23,
	1534,
	23,
	1534,
	23,
	14,
	26,
	14,
	26,
	14,
	26,
	14,
	26,
	14,
	26,
	23,
	23,
	26,
	26,
	430,
	430,
	35,
	35,
	584,
	23,
	14,
	23,
	14,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	14,
	23,
	23,
	23,
	23,
	23,
	23,
	28,
	14,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	32,
	23,
	23,
	23,
	430,
	430,
	35,
	35,
	584,
	23,
	23,
	23,
	23,
	26,
	26,
	23,
	23,
	23,
	23,
	26,
	23,
	26,
	26,
	26,
	26,
	32,
	23,
	23,
	23,
	23,
	32,
	23,
	23,
	32,
	23,
	23,
	14,
	23,
	23,
	23,
	23,
	23,
	26,
	28,
	28,
	23,
	23,
	23,
	14,
	14,
	23,
	23,
	23,
	23,
	23,
	23,
	14,
	23,
	23,
	23,
	23,
	23,
	26,
	14,
	23,
	23,
	23,
	23,
	23,
	26,
	14,
	23,
	23,
	23,
	23,
	23,
	26,
	14,
	23,
	23,
	23,
	23,
	23,
	26,
	14,
	23,
	23,
	23,
	28,
	14,
	23,
	23,
	9,
	23,
	9,
	32,
	23,
	102,
	14,
	23,
	14,
	32,
	23,
	102,
	14,
	23,
	14,
	32,
	23,
	102,
	14,
	23,
	14,
	32,
	23,
	102,
	14,
	23,
	14,
	32,
	23,
	102,
	14,
	23,
	14,
	23,
	23,
	23,
	23,
	23,
	32,
	23,
	102,
	14,
	23,
	14,
	32,
	23,
	102,
	14,
	23,
	14,
	32,
	23,
	102,
	14,
	23,
	14,
	32,
	23,
	102,
	14,
	23,
	14,
	32,
	23,
	102,
	14,
	23,
	14,
	32,
	23,
	102,
	14,
	23,
	14,
	32,
	23,
	102,
	14,
	23,
	14,
	32,
	23,
	102,
	14,
	23,
	14,
	32,
	23,
	102,
	14,
	23,
	14,
	32,
	23,
	102,
	14,
	23,
	14,
	32,
	23,
	102,
	14,
	23,
	14,
	32,
	23,
	102,
	14,
	23,
	14,
	32,
	23,
	102,
	14,
	23,
	14,
	23,
	56,
	32,
	23,
	102,
	14,
	23,
	14,
	32,
	23,
	102,
	14,
	23,
	14,
};
extern const Il2CppCodeGenModule g_AssemblyU2DCSharpCodeGenModule;
const Il2CppCodeGenModule g_AssemblyU2DCSharpCodeGenModule = 
{
	"Assembly-CSharp.dll",
	560,
	s_methodPointers,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
};
