﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"



extern const RuntimeMethod* IosBanner_UnityAdsBannerClick_m341C27892A0477BE144DBA166127267951B01C97_RuntimeMethod_var;
extern const RuntimeMethod* IosBanner_UnityAdsBannerDidError_m225A971BCDD9E56C1F883B1C0D4A058ABD3C88D4_RuntimeMethod_var;
extern const RuntimeMethod* IosBanner_UnityAdsBannerDidHide_m962A229232E642CBE004986D344E7E10003FC677_RuntimeMethod_var;
extern const RuntimeMethod* IosBanner_UnityAdsBannerDidLoad_mBA64C7497389CEAF35DE3ACE131D6AA95A8EE6D5_RuntimeMethod_var;
extern const RuntimeMethod* IosBanner_UnityAdsBannerDidShow_m479FF8DFCC5FF717DD0C697293AA0AE3344A5BAC_RuntimeMethod_var;
extern const RuntimeMethod* IosBanner_UnityAdsBannerDidUnload_m211228A6BA7CE8E28195354887A59605DFA5B55F_RuntimeMethod_var;
extern const RuntimeMethod* IosPlatform_UnityAdsDidError_m09DDB9048279569D3A5CA00BC8F25F8C20FCE61D_RuntimeMethod_var;
extern const RuntimeMethod* IosPlatform_UnityAdsDidFinish_m485AA4E38648E5DCB1A62345997336849D029C1B_RuntimeMethod_var;
extern const RuntimeMethod* IosPlatform_UnityAdsDidStart_m4819019842B1C7483EDF5614FAC5A00B25F4E0FE_RuntimeMethod_var;
extern const RuntimeMethod* IosPlatform_UnityAdsReady_m319BB195D43D7FC9155FB331FFD50D44C12238F6_RuntimeMethod_var;
extern const RuntimeMethod* PurchasingPlatform_UnityAdsDidInitiatePurchasingCommand_mE239DF35A9FA1DC1A39FC719A7BBE3DE7944AFD3_RuntimeMethod_var;
extern const RuntimeMethod* PurchasingPlatform_UnityAdsPurchasingGetProductCatalog_m8D60D398C4FEB99B98E3E9E155F9C7F215B32CA4_RuntimeMethod_var;
extern const RuntimeMethod* PurchasingPlatform_UnityAdsPurchasingGetPurchasingVersion_mF1D69129A470B6044F8FDBDBC3DF07BA13CB371C_RuntimeMethod_var;
extern const RuntimeMethod* PurchasingPlatform_UnityAdsPurchasingInitialize_m1388AD424E6D90AC991C7556C7CF74950173A0DE_RuntimeMethod_var;


IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 System.Action`1<UnityEngine.Advertisements.ShowResult> UnityEngine.Advertisements.ShowOptions::get_resultCallback()
extern void ShowOptions_get_resultCallback_mC3948B1267192174F92702667591E93985558B70 ();
// 0x00000002 System.String UnityEngine.Advertisements.ShowOptions::get_gamerSid()
extern void ShowOptions_get_gamerSid_mFDAB07F6EE1943128FF4B7750B9D61A12E200F76 ();
// 0x00000003 UnityEngine.Advertisements.BannerOptions_BannerCallback UnityEngine.Advertisements.BannerOptions::get_showCallback()
extern void BannerOptions_get_showCallback_m2EBCC1023270E883F0FAF6DFF2DB6DFB19785F39 ();
// 0x00000004 UnityEngine.Advertisements.BannerOptions_BannerCallback UnityEngine.Advertisements.BannerOptions::get_hideCallback()
extern void BannerOptions_get_hideCallback_mE3DB6C441CFAE02A22522DEEBDFE56DA7110CABF ();
// 0x00000005 UnityEngine.Advertisements.BannerOptions_BannerCallback UnityEngine.Advertisements.BannerOptions::get_clickCallback()
extern void BannerOptions_get_clickCallback_m723381DBDAA18D58F086B4BC7A9EB0A241DFE546 ();
// 0x00000006 System.Void UnityEngine.Advertisements.BannerOptions_BannerCallback::.ctor(System.Object,System.IntPtr)
extern void BannerCallback__ctor_m4A5CEE2B08DC1ED92500DE2D9973BA61638961C3 ();
// 0x00000007 System.Void UnityEngine.Advertisements.BannerOptions_BannerCallback::Invoke()
extern void BannerCallback_Invoke_m2EF171C33ED3F7EA79C1504F7EEDC14505EEFDAF ();
// 0x00000008 System.IAsyncResult UnityEngine.Advertisements.BannerOptions_BannerCallback::BeginInvoke(System.AsyncCallback,System.Object)
extern void BannerCallback_BeginInvoke_m9C7D41D41B14B03DAA22099079CEE0A214C85C5B ();
// 0x00000009 System.Void UnityEngine.Advertisements.BannerOptions_BannerCallback::EndInvoke(System.IAsyncResult)
extern void BannerCallback_EndInvoke_mA5E76201A8D3B2B0B44D7BD11B560131D66AC468 ();
// 0x0000000A System.Void UnityEngine.Advertisements.MetaData::.ctor(System.String)
extern void MetaData__ctor_m1EE75B864AC4AB45297350AF9F998579F9B453AC ();
// 0x0000000B System.String UnityEngine.Advertisements.MetaData::get_category()
extern void MetaData_get_category_m0801693A3D46ABD34D29C721FF280F15330F3DC3 ();
// 0x0000000C System.Void UnityEngine.Advertisements.MetaData::set_category(System.String)
extern void MetaData_set_category_m32438732A0862A12D370612605959108FA1D6B04 ();
// 0x0000000D System.Void UnityEngine.Advertisements.MetaData::Set(System.String,System.Object)
extern void MetaData_Set_mC0347747AEBC7A3CAA9799A7DAA1A26520550B61 ();
// 0x0000000E System.String UnityEngine.Advertisements.MetaData::ToJSON()
extern void MetaData_ToJSON_m57AA888160C99880EA1C4C5A012F860D8FB45A69 ();
// 0x0000000F System.Void UnityEngine.Advertisements.IBanner::Show(System.String,UnityEngine.Advertisements.BannerOptions)
// 0x00000010 System.Void UnityEngine.Advertisements.IBanner::Hide(System.Boolean)
// 0x00000011 System.Void UnityEngine.Advertisements.IBanner::SetPosition(UnityEngine.Advertisements.BannerPosition)
// 0x00000012 System.Void UnityEngine.Advertisements.IBanner::UnityAdsBannerDidShow(System.String,UnityEngine.Advertisements.BannerOptions)
// 0x00000013 System.Void UnityEngine.Advertisements.IBanner::UnityAdsBannerDidHide(System.String,UnityEngine.Advertisements.BannerOptions)
// 0x00000014 System.Void UnityEngine.Advertisements.IBanner::UnityAdsBannerClick(System.String,UnityEngine.Advertisements.BannerOptions)
// 0x00000015 System.Void UnityEngine.Advertisements.IBanner::UnityAdsBannerDidLoad(System.String,UnityEngine.Advertisements.BannerLoadOptions)
// 0x00000016 System.Void UnityEngine.Advertisements.IBanner::UnityAdsBannerDidError(System.String,UnityEngine.Advertisements.BannerLoadOptions)
// 0x00000017 System.Void UnityEngine.Advertisements.INativeBanner::SetupBanner(UnityEngine.Advertisements.IBanner)
// 0x00000018 System.Void UnityEngine.Advertisements.INativeBanner::Show(System.String,UnityEngine.Advertisements.BannerOptions)
// 0x00000019 System.Void UnityEngine.Advertisements.INativeBanner::Hide(System.Boolean)
// 0x0000001A System.Void UnityEngine.Advertisements.INativeBanner::SetPosition(UnityEngine.Advertisements.BannerPosition)
// 0x0000001B System.Void UnityEngine.Advertisements.IUnityAdsListener::OnUnityAdsReady(System.String)
// 0x0000001C System.Void UnityEngine.Advertisements.IUnityAdsListener::OnUnityAdsDidError(System.String)
// 0x0000001D System.Void UnityEngine.Advertisements.IUnityAdsListener::OnUnityAdsDidStart(System.String)
// 0x0000001E System.Void UnityEngine.Advertisements.IUnityAdsListener::OnUnityAdsDidFinish(System.String,UnityEngine.Advertisements.ShowResult)
// 0x0000001F UnityEngine.Advertisements.BannerLoadOptions_LoadCallback UnityEngine.Advertisements.BannerLoadOptions::get_loadCallback()
extern void BannerLoadOptions_get_loadCallback_mBBC0F2088F4E97189B2C5E2499D3EF0851654FDE ();
// 0x00000020 UnityEngine.Advertisements.BannerLoadOptions_ErrorCallback UnityEngine.Advertisements.BannerLoadOptions::get_errorCallback()
extern void BannerLoadOptions_get_errorCallback_m357E3E571C04C8060D9D4A3852DFAD120CC8FDC7 ();
// 0x00000021 System.Void UnityEngine.Advertisements.BannerLoadOptions_LoadCallback::.ctor(System.Object,System.IntPtr)
extern void LoadCallback__ctor_m8ADBF2C1CC3A87D11E2DA8AA427646C8BB84A281 ();
// 0x00000022 System.Void UnityEngine.Advertisements.BannerLoadOptions_LoadCallback::Invoke()
extern void LoadCallback_Invoke_mF8A5AD28B2BCACECCB4DE776B3D4CA8EBFE64092 ();
// 0x00000023 System.IAsyncResult UnityEngine.Advertisements.BannerLoadOptions_LoadCallback::BeginInvoke(System.AsyncCallback,System.Object)
extern void LoadCallback_BeginInvoke_mFD6EF4643E3B89A4FA252735ABFEF0CE017F6DCC ();
// 0x00000024 System.Void UnityEngine.Advertisements.BannerLoadOptions_LoadCallback::EndInvoke(System.IAsyncResult)
extern void LoadCallback_EndInvoke_m9D6940BF1FACF29FE272E5163C3E737AAD5E69B4 ();
// 0x00000025 System.Void UnityEngine.Advertisements.BannerLoadOptions_ErrorCallback::.ctor(System.Object,System.IntPtr)
extern void ErrorCallback__ctor_m9E5D36391B88115BE3162E8CBAA777E609196C4A ();
// 0x00000026 System.Void UnityEngine.Advertisements.BannerLoadOptions_ErrorCallback::Invoke(System.String)
extern void ErrorCallback_Invoke_m059AFC00B21E0276308B67BEC19DCBBF4AA5DF72 ();
// 0x00000027 System.IAsyncResult UnityEngine.Advertisements.BannerLoadOptions_ErrorCallback::BeginInvoke(System.String,System.AsyncCallback,System.Object)
extern void ErrorCallback_BeginInvoke_m3C14CFA75C836AB06A6C49FBCAF01062A30915DF ();
// 0x00000028 System.Void UnityEngine.Advertisements.BannerLoadOptions_ErrorCallback::EndInvoke(System.IAsyncResult)
extern void ErrorCallback_EndInvoke_mA8836BD90911979B479A0062CF21BD130F866F4C ();
// 0x00000029 System.Void UnityEngine.Advertisements.Banner::.ctor(UnityEngine.Advertisements.INativeBanner,UnityEngine.Advertisements.Utilities.IUnityLifecycleManager)
extern void Banner__ctor_mB35B9DCC5D3D226D12923FF2A5F80A3C2C3AE5A8 ();
// 0x0000002A UnityEngine.Advertisements.Utilities.IUnityLifecycleManager UnityEngine.Advertisements.Banner::get_UnityLifecycleManager()
extern void Banner_get_UnityLifecycleManager_m97C44211F5006FC2D8918F26CD9496C0F1E3B5BD ();
// 0x0000002B System.Void UnityEngine.Advertisements.Banner::Show(System.String,UnityEngine.Advertisements.BannerOptions)
extern void Banner_Show_m9561F00C63B7DAB87116BEECDCE34E6269657AA1 ();
// 0x0000002C System.Void UnityEngine.Advertisements.Banner::Hide(System.Boolean)
extern void Banner_Hide_m968C081FCB6CFEAB21A72B109BE5B0EB33C501D1 ();
// 0x0000002D System.Void UnityEngine.Advertisements.Banner::SetPosition(UnityEngine.Advertisements.BannerPosition)
extern void Banner_SetPosition_mD4AD41F0D92E03376D94859CF201895AF6929F99 ();
// 0x0000002E System.Void UnityEngine.Advertisements.Banner::UnityAdsBannerDidShow(System.String,UnityEngine.Advertisements.BannerOptions)
extern void Banner_UnityAdsBannerDidShow_m0122ED43437F1FCB4FFA4BB83C30FAF1430E0D18 ();
// 0x0000002F System.Void UnityEngine.Advertisements.Banner::UnityAdsBannerDidHide(System.String,UnityEngine.Advertisements.BannerOptions)
extern void Banner_UnityAdsBannerDidHide_mC8AB71EA7805B137F39F45677FE034455BED74A7 ();
// 0x00000030 System.Void UnityEngine.Advertisements.Banner::UnityAdsBannerClick(System.String,UnityEngine.Advertisements.BannerOptions)
extern void Banner_UnityAdsBannerClick_mC6ECBE3B7F8DA885033C9619E755B8850C330B3F ();
// 0x00000031 System.Void UnityEngine.Advertisements.Banner::UnityAdsBannerDidLoad(System.String,UnityEngine.Advertisements.BannerLoadOptions)
extern void Banner_UnityAdsBannerDidLoad_mFB34C6C0B89878F0E740F827BA96A2874121334A ();
// 0x00000032 System.Void UnityEngine.Advertisements.Banner::UnityAdsBannerDidError(System.String,UnityEngine.Advertisements.BannerLoadOptions)
extern void Banner_UnityAdsBannerDidError_m155CCCDD48983231EB3FB8BF8A7D47374CA4465F ();
// 0x00000033 System.Void UnityEngine.Advertisements.Banner_<UnityAdsBannerDidShow>c__AnonStorey0::.ctor()
extern void U3CUnityAdsBannerDidShowU3Ec__AnonStorey0__ctor_mEEB42B8011106629A20BD41CA2AD8E8707B03CC6 ();
// 0x00000034 System.Void UnityEngine.Advertisements.Banner_<UnityAdsBannerDidShow>c__AnonStorey0::<>m__0()
extern void U3CUnityAdsBannerDidShowU3Ec__AnonStorey0_U3CU3Em__0_m719872728637660A222D25A946D11306EE822FF5 ();
// 0x00000035 System.Void UnityEngine.Advertisements.Banner_<UnityAdsBannerDidHide>c__AnonStorey1::.ctor()
extern void U3CUnityAdsBannerDidHideU3Ec__AnonStorey1__ctor_mC39805B151259AE9AC2C0CD843FD5E24EEBC3F57 ();
// 0x00000036 System.Void UnityEngine.Advertisements.Banner_<UnityAdsBannerDidHide>c__AnonStorey1::<>m__0()
extern void U3CUnityAdsBannerDidHideU3Ec__AnonStorey1_U3CU3Em__0_m46B4B677BAADB30919E74D76525B56C8F7A90AF1 ();
// 0x00000037 System.Void UnityEngine.Advertisements.Banner_<UnityAdsBannerClick>c__AnonStorey2::.ctor()
extern void U3CUnityAdsBannerClickU3Ec__AnonStorey2__ctor_mBAA0B86F6D709CEA9D7CD28C4BCBE50B9320E5AB ();
// 0x00000038 System.Void UnityEngine.Advertisements.Banner_<UnityAdsBannerClick>c__AnonStorey2::<>m__0()
extern void U3CUnityAdsBannerClickU3Ec__AnonStorey2_U3CU3Em__0_m6945721AC093202F3B8EB363C52BA3C3436E7C2C ();
// 0x00000039 System.Void UnityEngine.Advertisements.Banner_<UnityAdsBannerDidLoad>c__AnonStorey3::.ctor()
extern void U3CUnityAdsBannerDidLoadU3Ec__AnonStorey3__ctor_mA9E9E6A4328B0B0CBC62FD191BE27D6EF357A23E ();
// 0x0000003A System.Void UnityEngine.Advertisements.Banner_<UnityAdsBannerDidLoad>c__AnonStorey3::<>m__0()
extern void U3CUnityAdsBannerDidLoadU3Ec__AnonStorey3_U3CU3Em__0_m4E8D505D5751A99869987CDE00F62804D1BD5C7E ();
// 0x0000003B System.Void UnityEngine.Advertisements.Banner_<UnityAdsBannerDidError>c__AnonStorey4::.ctor()
extern void U3CUnityAdsBannerDidErrorU3Ec__AnonStorey4__ctor_m3AC5F288AC7CD4E4C5A6BA0A68B22B6AD0462E25 ();
// 0x0000003C System.Void UnityEngine.Advertisements.Banner_<UnityAdsBannerDidError>c__AnonStorey4::<>m__0()
extern void U3CUnityAdsBannerDidErrorU3Ec__AnonStorey4_U3CU3Em__0_m7220D8E94FCADA52A99330CE161C9A5A1A360EC6 ();
// 0x0000003D System.Void UnityEngine.Advertisements.Advertisement::.cctor()
extern void Advertisement__cctor_mC890142D0DDB7F12D9624F4B5D47CDA2AD1050B8 ();
// 0x0000003E System.Boolean UnityEngine.Advertisements.Advertisement::get_isInitialized()
extern void Advertisement_get_isInitialized_mEEE939B4C7076C75A5F905747A55D9E17A9E184C ();
// 0x0000003F System.Void UnityEngine.Advertisements.Advertisement::Initialize(System.String,System.Boolean)
extern void Advertisement_Initialize_m148388763C32FB12D7CFC87F8316BC2FE8F59107 ();
// 0x00000040 System.Void UnityEngine.Advertisements.Advertisement::Initialize(System.String,System.Boolean,System.Boolean)
extern void Advertisement_Initialize_mF7B38D03551DF7610F28487B3BDA8B49AD699CBC ();
// 0x00000041 System.Boolean UnityEngine.Advertisements.Advertisement::IsReady(System.String)
extern void Advertisement_IsReady_m809BD2B6DD398ECCF7638A759D2B46032025655C ();
// 0x00000042 System.Void UnityEngine.Advertisements.Advertisement::Show(System.String)
extern void Advertisement_Show_m083D3FF59AB2E5BB4160504DD86C4350B3510DD2 ();
// 0x00000043 System.Void UnityEngine.Advertisements.Advertisement::AddListener(UnityEngine.Advertisements.IUnityAdsListener)
extern void Advertisement_AddListener_mA5F78EEF8B48CFC7CFB3EFEE7A4072480635102D ();
// 0x00000044 UnityEngine.Advertisements.Platform.IPlatform UnityEngine.Advertisements.Advertisement::CreatePlatform()
extern void Advertisement_CreatePlatform_mDFF4823F9F13CABBA0EB972D332E86934456D34D ();
// 0x00000045 System.Void UnityEngine.Advertisements.Advertisement_Banner::Show(System.String)
extern void Banner_Show_m096C8240D65605B7D8AD8229CC9C830F140715E7 ();
// 0x00000046 System.Void UnityEngine.Advertisements.Advertisement_Banner::Show(System.String,UnityEngine.Advertisements.BannerOptions)
extern void Banner_Show_m9F393EA3D089BF375B41FA23468F99DE6285411D ();
// 0x00000047 System.Void UnityEngine.Advertisements.Advertisement_Banner::Hide(System.Boolean)
extern void Banner_Hide_m20BEF43068CC52E4FDFDD036C7465C09EC51FA04 ();
// 0x00000048 System.Void UnityEngine.Advertisements.Advertisement_Banner::SetPosition(UnityEngine.Advertisements.BannerPosition)
extern void Banner_SetPosition_mCD9D0A9978CAC927B4FBCB107711CB06AB23FECE ();
// 0x00000049 System.Boolean UnityEngine.Advertisements.Purchasing.Purchasing::Initialize(UnityEngine.Advertisements.Purchasing.IPurchasingEventSender)
extern void Purchasing_Initialize_mF4A8374F4858B4E9BCE8D87B9DA0793236AC8EF1 ();
// 0x0000004A System.Boolean UnityEngine.Advertisements.Purchasing.Purchasing::InitiatePurchasingCommand(System.String)
extern void Purchasing_InitiatePurchasingCommand_mEBA0D3B87A1F4DA656437929C7144421153A17F1 ();
// 0x0000004B System.String UnityEngine.Advertisements.Purchasing.Purchasing::GetPurchasingCatalog()
extern void Purchasing_GetPurchasingCatalog_m9BA5C0687658841756A08E42123C484FD987A485 ();
// 0x0000004C System.String UnityEngine.Advertisements.Purchasing.Purchasing::GetPromoVersion()
extern void Purchasing_GetPromoVersion_m06F34E013F91BC43A8C5CF32CDEDB7FB95678839 ();
// 0x0000004D System.Void UnityEngine.Advertisements.Purchasing.Purchasing::.cctor()
extern void Purchasing__cctor_m7570A4768D9E7EAA1CE09D9DF60E5E7BA2D19E9A ();
// 0x0000004E System.Void UnityEngine.Advertisements.Purchasing.PurchasingPlatform::.ctor()
extern void PurchasingPlatform__ctor_mF3B8D47CA9732083F21BCC00536A4B6118093673 ();
// 0x0000004F UnityEngine.Advertisements.Purchasing.PurchasingPlatform UnityEngine.Advertisements.Purchasing.PurchasingPlatform::get_Instance()
extern void PurchasingPlatform_get_Instance_m72DA530720E565DF78BCCF604004F4F2F4A8B434 ();
// 0x00000050 System.Void UnityEngine.Advertisements.Purchasing.PurchasingPlatform::set_Instance(UnityEngine.Advertisements.Purchasing.PurchasingPlatform)
extern void PurchasingPlatform_set_Instance_m06C014D5A2B12148CC1BFF271E9243CECB4F240F ();
// 0x00000051 System.Void UnityEngine.Advertisements.Purchasing.PurchasingPlatform::UnityAdsPurchasingDispatchReturnEvent(System.Int64,System.String)
extern void PurchasingPlatform_UnityAdsPurchasingDispatchReturnEvent_mBF61122298091E8027B03BCA4E1E63A5FD2C12B5 ();
// 0x00000052 System.Void UnityEngine.Advertisements.Purchasing.PurchasingPlatform::UnityAdsSetDidInitiatePurchasingCommandCallback(UnityEngine.Advertisements.Purchasing.PurchasingPlatform_unityAdsPurchasingDidInitiatePurchasingCommand)
extern void PurchasingPlatform_UnityAdsSetDidInitiatePurchasingCommandCallback_m7B176FF13BA5586DD8B8305BE4BDEB3BBB094923 ();
// 0x00000053 System.Void UnityEngine.Advertisements.Purchasing.PurchasingPlatform::UnityAdsSetGetProductCatalogCallback(UnityEngine.Advertisements.Purchasing.PurchasingPlatform_unityAdsPurchasingGetProductCatalog)
extern void PurchasingPlatform_UnityAdsSetGetProductCatalogCallback_m0C53D7513574919071E4B4A9CB336DE7C47D4C94 ();
// 0x00000054 System.Void UnityEngine.Advertisements.Purchasing.PurchasingPlatform::UnityAdsSetGetVersionCallback(UnityEngine.Advertisements.Purchasing.PurchasingPlatform_unityAdsPurchasingGetPurchasingVersion)
extern void PurchasingPlatform_UnityAdsSetGetVersionCallback_mF2B05D19FD832B0A68CB27F1845B171586F0C432 ();
// 0x00000055 System.Void UnityEngine.Advertisements.Purchasing.PurchasingPlatform::UnityAdsSetInitializePurchasingCallback(UnityEngine.Advertisements.Purchasing.PurchasingPlatform_unityAdsPurchasingInitialize)
extern void PurchasingPlatform_UnityAdsSetInitializePurchasingCallback_m30A3EEC475DA824B4C8A7D3A30C9F5C4EE233898 ();
// 0x00000056 System.Void UnityEngine.Advertisements.Purchasing.PurchasingPlatform::UnityAdsDidInitiatePurchasingCommand(System.String)
extern void PurchasingPlatform_UnityAdsDidInitiatePurchasingCommand_mE239DF35A9FA1DC1A39FC719A7BBE3DE7944AFD3 ();
// 0x00000057 System.Void UnityEngine.Advertisements.Purchasing.PurchasingPlatform::UnityAdsPurchasingGetProductCatalog()
extern void PurchasingPlatform_UnityAdsPurchasingGetProductCatalog_m8D60D398C4FEB99B98E3E9E155F9C7F215B32CA4 ();
// 0x00000058 System.Void UnityEngine.Advertisements.Purchasing.PurchasingPlatform::UnityAdsPurchasingGetPurchasingVersion()
extern void PurchasingPlatform_UnityAdsPurchasingGetPurchasingVersion_mF1D69129A470B6044F8FDBDBC3DF07BA13CB371C ();
// 0x00000059 System.Void UnityEngine.Advertisements.Purchasing.PurchasingPlatform::UnityAdsPurchasingInitialize()
extern void PurchasingPlatform_UnityAdsPurchasingInitialize_m1388AD424E6D90AC991C7556C7CF74950173A0DE ();
// 0x0000005A System.Void UnityEngine.Advertisements.Purchasing.PurchasingPlatform::Initialize()
extern void PurchasingPlatform_Initialize_m2AE04AD473D437A6B6A9C8459E27C0CC092F748F ();
// 0x0000005B System.Void UnityEngine.Advertisements.Purchasing.PurchasingPlatform_unityAdsPurchasingDidInitiatePurchasingCommand::.ctor(System.Object,System.IntPtr)
extern void unityAdsPurchasingDidInitiatePurchasingCommand__ctor_m28E30D006BC66BC32C20D6839ED54404F945B134 ();
// 0x0000005C System.Void UnityEngine.Advertisements.Purchasing.PurchasingPlatform_unityAdsPurchasingDidInitiatePurchasingCommand::Invoke(System.String)
extern void unityAdsPurchasingDidInitiatePurchasingCommand_Invoke_mC5C5C7B26D69AADE2916B7F1F7A71488B342E645 ();
// 0x0000005D System.IAsyncResult UnityEngine.Advertisements.Purchasing.PurchasingPlatform_unityAdsPurchasingDidInitiatePurchasingCommand::BeginInvoke(System.String,System.AsyncCallback,System.Object)
extern void unityAdsPurchasingDidInitiatePurchasingCommand_BeginInvoke_m644D0444027B5319886F5D810B72E82D73C541E7 ();
// 0x0000005E System.Void UnityEngine.Advertisements.Purchasing.PurchasingPlatform_unityAdsPurchasingDidInitiatePurchasingCommand::EndInvoke(System.IAsyncResult)
extern void unityAdsPurchasingDidInitiatePurchasingCommand_EndInvoke_m799AAECFBB786E5A0FCF3BD4BD566BACFAA74D40 ();
// 0x0000005F System.Void UnityEngine.Advertisements.Purchasing.PurchasingPlatform_unityAdsPurchasingGetProductCatalog::.ctor(System.Object,System.IntPtr)
extern void unityAdsPurchasingGetProductCatalog__ctor_m278CBE91CC435FBBE733F85108449A709108F910 ();
// 0x00000060 System.Void UnityEngine.Advertisements.Purchasing.PurchasingPlatform_unityAdsPurchasingGetProductCatalog::Invoke()
extern void unityAdsPurchasingGetProductCatalog_Invoke_m47CCEE3CF2FEA122C64808D0C07204464AA41155 ();
// 0x00000061 System.IAsyncResult UnityEngine.Advertisements.Purchasing.PurchasingPlatform_unityAdsPurchasingGetProductCatalog::BeginInvoke(System.AsyncCallback,System.Object)
extern void unityAdsPurchasingGetProductCatalog_BeginInvoke_mE94C0EDEBAD4E37D92DEF4C7946D8DAEB9AF1525 ();
// 0x00000062 System.Void UnityEngine.Advertisements.Purchasing.PurchasingPlatform_unityAdsPurchasingGetProductCatalog::EndInvoke(System.IAsyncResult)
extern void unityAdsPurchasingGetProductCatalog_EndInvoke_m211938B4FF62457D47A271FF39EFFC994A9FB2D8 ();
// 0x00000063 System.Void UnityEngine.Advertisements.Purchasing.PurchasingPlatform_unityAdsPurchasingGetPurchasingVersion::.ctor(System.Object,System.IntPtr)
extern void unityAdsPurchasingGetPurchasingVersion__ctor_m6E2FD0205408F0F56B7412144E7BC1B3FEC9F88E ();
// 0x00000064 System.Void UnityEngine.Advertisements.Purchasing.PurchasingPlatform_unityAdsPurchasingGetPurchasingVersion::Invoke()
extern void unityAdsPurchasingGetPurchasingVersion_Invoke_m1B88E693E7CC7B2309387B87CCA07A42F9237E06 ();
// 0x00000065 System.IAsyncResult UnityEngine.Advertisements.Purchasing.PurchasingPlatform_unityAdsPurchasingGetPurchasingVersion::BeginInvoke(System.AsyncCallback,System.Object)
extern void unityAdsPurchasingGetPurchasingVersion_BeginInvoke_mF7741AC99775B183263DDDB273DE319818165014 ();
// 0x00000066 System.Void UnityEngine.Advertisements.Purchasing.PurchasingPlatform_unityAdsPurchasingGetPurchasingVersion::EndInvoke(System.IAsyncResult)
extern void unityAdsPurchasingGetPurchasingVersion_EndInvoke_mF064626A5DDAFD248156DE32FAD2A487019EAFCE ();
// 0x00000067 System.Void UnityEngine.Advertisements.Purchasing.PurchasingPlatform_unityAdsPurchasingInitialize::.ctor(System.Object,System.IntPtr)
extern void unityAdsPurchasingInitialize__ctor_m2CA7DBB4F8FDAE18351B4DE5C2A927E486A00664 ();
// 0x00000068 System.Void UnityEngine.Advertisements.Purchasing.PurchasingPlatform_unityAdsPurchasingInitialize::Invoke()
extern void unityAdsPurchasingInitialize_Invoke_m9B49A03FBCCCFB6880B4796F4709DF5722240603 ();
// 0x00000069 System.IAsyncResult UnityEngine.Advertisements.Purchasing.PurchasingPlatform_unityAdsPurchasingInitialize::BeginInvoke(System.AsyncCallback,System.Object)
extern void unityAdsPurchasingInitialize_BeginInvoke_m44F14ADAD392691289914061603F7AD14B845D51 ();
// 0x0000006A System.Void UnityEngine.Advertisements.Purchasing.PurchasingPlatform_unityAdsPurchasingInitialize::EndInvoke(System.IAsyncResult)
extern void unityAdsPurchasingInitialize_EndInvoke_mE57A3C79549C52C6C45FE51ECCF92C67F96A5B58 ();
// 0x0000006B UnityEngine.Advertisements.IBanner UnityEngine.Advertisements.Platform.IPlatform::get_Banner()
// 0x0000006C System.Boolean UnityEngine.Advertisements.Platform.IPlatform::get_IsInitialized()
// 0x0000006D System.Void UnityEngine.Advertisements.Platform.IPlatform::Initialize(System.String,System.Boolean,System.Boolean)
// 0x0000006E System.Void UnityEngine.Advertisements.Platform.IPlatform::Show(System.String,UnityEngine.Advertisements.ShowOptions)
// 0x0000006F System.Void UnityEngine.Advertisements.Platform.IPlatform::AddListener(UnityEngine.Advertisements.IUnityAdsListener)
// 0x00000070 System.Boolean UnityEngine.Advertisements.Platform.IPlatform::IsReady(System.String)
// 0x00000071 System.Void UnityEngine.Advertisements.Platform.IPlatform::UnityAdsReady(System.String)
// 0x00000072 System.Void UnityEngine.Advertisements.Platform.IPlatform::UnityAdsDidError(System.String)
// 0x00000073 System.Void UnityEngine.Advertisements.Platform.IPlatform::UnityAdsDidStart(System.String)
// 0x00000074 System.Void UnityEngine.Advertisements.Platform.IPlatform::UnityAdsDidFinish(System.String,UnityEngine.Advertisements.ShowResult)
// 0x00000075 System.Void UnityEngine.Advertisements.Platform.Platform::.ctor(UnityEngine.Advertisements.INativePlatform,UnityEngine.Advertisements.IBanner,UnityEngine.Advertisements.Utilities.IUnityLifecycleManager)
extern void Platform__ctor_m08E862A217AD3BCC538DBCB746D6CDDBB9D1BE9E ();
// 0x00000076 System.Void UnityEngine.Advertisements.Platform.Platform::add_OnStart(System.EventHandler`1<UnityEngine.Advertisements.Events.StartEventArgs>)
extern void Platform_add_OnStart_m792304EB0698E5AE304E0F60C0F7FF352CB11037 ();
// 0x00000077 System.Void UnityEngine.Advertisements.Platform.Platform::remove_OnStart(System.EventHandler`1<UnityEngine.Advertisements.Events.StartEventArgs>)
extern void Platform_remove_OnStart_m5D801D82BBA3E8FE44A6B3087B991E353C747206 ();
// 0x00000078 System.Void UnityEngine.Advertisements.Platform.Platform::add_OnFinish(System.EventHandler`1<UnityEngine.Advertisements.Events.FinishEventArgs>)
extern void Platform_add_OnFinish_mDFC773F30B590A2EB8FE28E524E58746B0EBC760 ();
// 0x00000079 System.Void UnityEngine.Advertisements.Platform.Platform::remove_OnFinish(System.EventHandler`1<UnityEngine.Advertisements.Events.FinishEventArgs>)
extern void Platform_remove_OnFinish_mEB885423D4D62EAE0E6F05B8150765CA3ED3174E ();
// 0x0000007A UnityEngine.Advertisements.IBanner UnityEngine.Advertisements.Platform.Platform::get_Banner()
extern void Platform_get_Banner_m5A4FFF22ABD28C1A6F71F206D44D52361B0533B3 ();
// 0x0000007B UnityEngine.Advertisements.Utilities.IUnityLifecycleManager UnityEngine.Advertisements.Platform.Platform::get_UnityLifecycleManager()
extern void Platform_get_UnityLifecycleManager_m2F9285DC280DBE54C036EB569069C52D0EDCFEC1 ();
// 0x0000007C UnityEngine.Advertisements.INativePlatform UnityEngine.Advertisements.Platform.Platform::get_NativePlatform()
extern void Platform_get_NativePlatform_mB585CB86329C4669F4BCBB750E8EF249842D1999 ();
// 0x0000007D System.Boolean UnityEngine.Advertisements.Platform.Platform::get_IsInitialized()
extern void Platform_get_IsInitialized_mB2B9D57DF48928E53C65ADDD24398BBA6589EBD8 ();
// 0x0000007E System.Boolean UnityEngine.Advertisements.Platform.Platform::get_IsShowing()
extern void Platform_get_IsShowing_m8A4E0658F585985073F809B2CCA3587C56D10337 ();
// 0x0000007F System.Void UnityEngine.Advertisements.Platform.Platform::set_IsShowing(System.Boolean)
extern void Platform_set_IsShowing_m9A4BEF7199F966CB29E139D4AB8AAA6908BF635B ();
// 0x00000080 System.String UnityEngine.Advertisements.Platform.Platform::get_Version()
extern void Platform_get_Version_m073B2F3853CF8E58403C3DEA6EFF79BBDC7592C3 ();
// 0x00000081 System.Collections.Generic.HashSet`1<UnityEngine.Advertisements.IUnityAdsListener> UnityEngine.Advertisements.Platform.Platform::get_Listeners()
extern void Platform_get_Listeners_m0B513E377340B1C9DD2653D336BB26B08AE7230D ();
// 0x00000082 System.Void UnityEngine.Advertisements.Platform.Platform::Initialize(System.String,System.Boolean,System.Boolean)
extern void Platform_Initialize_mE241B88B7E31648734C0031B144892BFD7AB0EF3 ();
// 0x00000083 System.Void UnityEngine.Advertisements.Platform.Platform::Show(System.String,UnityEngine.Advertisements.ShowOptions)
extern void Platform_Show_m66EF021A4AA7E072D76863209D90B24C082EEBBE ();
// 0x00000084 System.Void UnityEngine.Advertisements.Platform.Platform::AddListener(UnityEngine.Advertisements.IUnityAdsListener)
extern void Platform_AddListener_m10D88F995A14ABA6AB51686E1F5453C9CD085B20 ();
// 0x00000085 System.Boolean UnityEngine.Advertisements.Platform.Platform::IsReady(System.String)
extern void Platform_IsReady_m03ED55C3014138E68153FBB36384DE2828ABB823 ();
// 0x00000086 System.Void UnityEngine.Advertisements.Platform.Platform::SetMetaData(UnityEngine.Advertisements.MetaData)
extern void Platform_SetMetaData_mF7DB479133D95A29CDE63A3AC82E27B82114577D ();
// 0x00000087 System.Void UnityEngine.Advertisements.Platform.Platform::UnityAdsReady(System.String)
extern void Platform_UnityAdsReady_mBAC7A214B6059EA25119F89E402ABE9E3EEB3031 ();
// 0x00000088 System.Void UnityEngine.Advertisements.Platform.Platform::UnityAdsDidError(System.String)
extern void Platform_UnityAdsDidError_m86810671646400CDD496EC2088990830671F6F25 ();
// 0x00000089 System.Void UnityEngine.Advertisements.Platform.Platform::UnityAdsDidStart(System.String)
extern void Platform_UnityAdsDidStart_m4473FE0C5D24DFE28714CFD81451E72E4B9BEF50 ();
// 0x0000008A System.Void UnityEngine.Advertisements.Platform.Platform::UnityAdsDidFinish(System.String,UnityEngine.Advertisements.ShowResult)
extern void Platform_UnityAdsDidFinish_mE7EEE0FEA36F2C56333554D1D3DD4CF48921454E ();
// 0x0000008B System.Collections.Generic.HashSet`1<UnityEngine.Advertisements.IUnityAdsListener> UnityEngine.Advertisements.Platform.Platform::GetClonedHashSet(System.Collections.Generic.HashSet`1<UnityEngine.Advertisements.IUnityAdsListener>)
extern void Platform_GetClonedHashSet_mCD4507B8B9D1405987C47C80195E48EC9EDB071A ();
// 0x0000008C System.Void UnityEngine.Advertisements.Platform.Platform::<Initialize>m__0(System.Object,UnityEngine.Advertisements.Events.StartEventArgs)
extern void Platform_U3CInitializeU3Em__0_m4A24234C140B6FC007256CAEBA1C4A46728B03B7 ();
// 0x0000008D System.Void UnityEngine.Advertisements.Platform.Platform::<Initialize>m__1(System.Object,UnityEngine.Advertisements.Events.FinishEventArgs)
extern void Platform_U3CInitializeU3Em__1_mF4A5D389B28ACA046C818832B5711691628BB673 ();
// 0x0000008E System.Void UnityEngine.Advertisements.Platform.Platform_<Show>c__AnonStorey0::.ctor()
extern void U3CShowU3Ec__AnonStorey0__ctor_m1971B90A112FB89812BA91B3BB1D6D41AE45241D ();
// 0x0000008F System.Void UnityEngine.Advertisements.Platform.Platform_<Show>c__AnonStorey1::.ctor()
extern void U3CShowU3Ec__AnonStorey1__ctor_m1A22D5F3FFFB693A8C68FBC098A96550F735C529 ();
// 0x00000090 System.Void UnityEngine.Advertisements.Platform.Platform_<Show>c__AnonStorey1::<>m__0(System.Object,UnityEngine.Advertisements.Events.FinishEventArgs)
extern void U3CShowU3Ec__AnonStorey1_U3CU3Em__0_mEE89C80DD462405B1575D1B4C766E3EDA88A911C ();
// 0x00000091 System.Void UnityEngine.Advertisements.Platform.Platform_<UnityAdsReady>c__AnonStorey2::.ctor()
extern void U3CUnityAdsReadyU3Ec__AnonStorey2__ctor_m42DB75A81A8CD425E73DF80058C9670F5122D0CA ();
// 0x00000092 System.Void UnityEngine.Advertisements.Platform.Platform_<UnityAdsReady>c__AnonStorey2::<>m__0()
extern void U3CUnityAdsReadyU3Ec__AnonStorey2_U3CU3Em__0_m87928B642173FB247EDFC647B597269D34FE3A2A ();
// 0x00000093 System.Void UnityEngine.Advertisements.Platform.Platform_<UnityAdsDidError>c__AnonStorey3::.ctor()
extern void U3CUnityAdsDidErrorU3Ec__AnonStorey3__ctor_m84919A69D972B1891D13AEE64F9B7A917FFB1DA8 ();
// 0x00000094 System.Void UnityEngine.Advertisements.Platform.Platform_<UnityAdsDidError>c__AnonStorey3::<>m__0()
extern void U3CUnityAdsDidErrorU3Ec__AnonStorey3_U3CU3Em__0_m88746A068BBADC0BDF866EEE1E1CEAFE9CD8A9F8 ();
// 0x00000095 System.Void UnityEngine.Advertisements.Platform.Platform_<UnityAdsDidStart>c__AnonStorey4::.ctor()
extern void U3CUnityAdsDidStartU3Ec__AnonStorey4__ctor_mDAC2110307769014336CDB8757E7EA082D194220 ();
// 0x00000096 System.Void UnityEngine.Advertisements.Platform.Platform_<UnityAdsDidStart>c__AnonStorey4::<>m__0()
extern void U3CUnityAdsDidStartU3Ec__AnonStorey4_U3CU3Em__0_mE3D0F8D957A6FADC022A1210D35874A133A9FA28 ();
// 0x00000097 System.Void UnityEngine.Advertisements.Platform.Platform_<UnityAdsDidFinish>c__AnonStorey5::.ctor()
extern void U3CUnityAdsDidFinishU3Ec__AnonStorey5__ctor_mA43D96AF35CD28E89AA0B31DED224E8C8A599EE8 ();
// 0x00000098 System.Void UnityEngine.Advertisements.Platform.Platform_<UnityAdsDidFinish>c__AnonStorey5::<>m__0()
extern void U3CUnityAdsDidFinishU3Ec__AnonStorey5_U3CU3Em__0_m15ABB4C914B0280BFCDC37A763F2EA60C6994FD9 ();
// 0x00000099 System.Void UnityEngine.Advertisements.INativePlatform::SetupPlatform(UnityEngine.Advertisements.Platform.IPlatform)
// 0x0000009A System.Void UnityEngine.Advertisements.INativePlatform::Initialize(System.String,System.Boolean,System.Boolean)
// 0x0000009B System.Void UnityEngine.Advertisements.INativePlatform::Show(System.String)
// 0x0000009C System.Void UnityEngine.Advertisements.INativePlatform::SetMetaData(UnityEngine.Advertisements.MetaData)
// 0x0000009D System.String UnityEngine.Advertisements.INativePlatform::GetVersion()
// 0x0000009E System.Boolean UnityEngine.Advertisements.INativePlatform::IsInitialized()
// 0x0000009F System.Boolean UnityEngine.Advertisements.INativePlatform::IsReady(System.String)
// 0x000000A0 System.Void UnityEngine.Advertisements.Platform.Unsupported.UnsupportedPlatform::.ctor()
extern void UnsupportedPlatform__ctor_m5C391C1F4054AACEB65656A712FDA630F9EDA58C ();
// 0x000000A1 System.Void UnityEngine.Advertisements.Platform.Unsupported.UnsupportedPlatform::SetupPlatform(UnityEngine.Advertisements.Platform.IPlatform)
extern void UnsupportedPlatform_SetupPlatform_m2A2420F10F49EB741E3F47A16C6E894E5611F71C ();
// 0x000000A2 System.Void UnityEngine.Advertisements.Platform.Unsupported.UnsupportedPlatform::Initialize(System.String,System.Boolean,System.Boolean)
extern void UnsupportedPlatform_Initialize_mCF80912266B6AC82F0E857E2135784B67BCE7622 ();
// 0x000000A3 System.Void UnityEngine.Advertisements.Platform.Unsupported.UnsupportedPlatform::Show(System.String)
extern void UnsupportedPlatform_Show_mA5EB8A0295A8EBA6163D77D7C5A5F75FDB93DE01 ();
// 0x000000A4 System.Void UnityEngine.Advertisements.Platform.Unsupported.UnsupportedPlatform::SetMetaData(UnityEngine.Advertisements.MetaData)
extern void UnsupportedPlatform_SetMetaData_mCBC113C5E270591138DC51C19647BFCE026BC152 ();
// 0x000000A5 System.String UnityEngine.Advertisements.Platform.Unsupported.UnsupportedPlatform::GetVersion()
extern void UnsupportedPlatform_GetVersion_m0D75CB76941356B012804F863B3CB340AE08D93F ();
// 0x000000A6 System.Boolean UnityEngine.Advertisements.Platform.Unsupported.UnsupportedPlatform::IsInitialized()
extern void UnsupportedPlatform_IsInitialized_m4B088A3F553A6E94193E5E4C9E923356B31133E2 ();
// 0x000000A7 System.Boolean UnityEngine.Advertisements.Platform.Unsupported.UnsupportedPlatform::IsReady(System.String)
extern void UnsupportedPlatform_IsReady_m79613959C9355961166D55827EBCBBC4806D7938 ();
// 0x000000A8 System.Void UnityEngine.Advertisements.Platform.Unsupported.UnsupportedBanner::.ctor()
extern void UnsupportedBanner__ctor_m7F210B499A06A7A5956582B7F920CA5116F15019 ();
// 0x000000A9 System.Void UnityEngine.Advertisements.Platform.Unsupported.UnsupportedBanner::SetupBanner(UnityEngine.Advertisements.IBanner)
extern void UnsupportedBanner_SetupBanner_m78DCB47FF13B4C934D8C8EFCFFC6C0FDCCA3534D ();
// 0x000000AA System.Void UnityEngine.Advertisements.Platform.Unsupported.UnsupportedBanner::Show(System.String,UnityEngine.Advertisements.BannerOptions)
extern void UnsupportedBanner_Show_mD12A749775E08E9030EE02BCAD5B477766D4C7C6 ();
// 0x000000AB System.Void UnityEngine.Advertisements.Platform.Unsupported.UnsupportedBanner::Hide(System.Boolean)
extern void UnsupportedBanner_Hide_m04094D5CEEF142DE24CCABBEFA387D38F13C3865 ();
// 0x000000AC System.Void UnityEngine.Advertisements.Platform.Unsupported.UnsupportedBanner::SetPosition(UnityEngine.Advertisements.BannerPosition)
extern void UnsupportedBanner_SetPosition_mD4C6CC9F4D10CE99979B370F810E41E9AE6EC991 ();
// 0x000000AD System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner::.ctor()
extern void IosBanner__ctor_mFFE0864913014B3FB06C0B70EB6C5EE56F387381 ();
// 0x000000AE System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner::UnityAdsBannerShow(System.String,System.Boolean)
extern void IosBanner_UnityAdsBannerShow_mA18FC45EA1736F29A5EDCF16E4517BF5546C8625 ();
// 0x000000AF System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner::UnityAdsBannerHide(System.Boolean)
extern void IosBanner_UnityAdsBannerHide_m07DF7BBF0EBBD2815F9A1A8191D73B53440F3D2D ();
// 0x000000B0 System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner::UnityAdsBannerSetPosition(System.Int32)
extern void IosBanner_UnityAdsBannerSetPosition_m1A0700BE5976BE34744413D6BAAB122A2FAA5C7C ();
// 0x000000B1 System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner::UnityAdsSetBannerShowCallback(UnityEngine.Advertisements.Platform.iOS.IosBanner_UnityAdsBannerShowDelegate)
extern void IosBanner_UnityAdsSetBannerShowCallback_mF187E366DF81797104E020418AD3B3DADA813C74 ();
// 0x000000B2 System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner::UnityAdsSetBannerHideCallback(UnityEngine.Advertisements.Platform.iOS.IosBanner_UnityAdsBannerHideDelegate)
extern void IosBanner_UnityAdsSetBannerHideCallback_m2B973AA69E5DF1DB80C667C62C24FD64329F8FC2 ();
// 0x000000B3 System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner::UnityAdsSetBannerClickCallback(UnityEngine.Advertisements.Platform.iOS.IosBanner_UnityAdsBannerClickDelegate)
extern void IosBanner_UnityAdsSetBannerClickCallback_m7F8C336F2EB3DF345AD8AEE707D652E3769F08B2 ();
// 0x000000B4 System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner::UnityAdsSetBannerErrorCallback(UnityEngine.Advertisements.Platform.iOS.IosBanner_UnityAdsBannerErrorDelegate)
extern void IosBanner_UnityAdsSetBannerErrorCallback_mE89232FFF832B2269E9F12FA6EA443A24F551CD6 ();
// 0x000000B5 System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner::UnityAdsSetBannerUnloadCallback(UnityEngine.Advertisements.Platform.iOS.IosBanner_UnityAdsBannerUnloadDelegate)
extern void IosBanner_UnityAdsSetBannerUnloadCallback_m5AF802647514704499357A4056B814CDF32D600F ();
// 0x000000B6 System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner::UnityAdsSetBannerLoadCallback(UnityEngine.Advertisements.Platform.iOS.IosBanner_UnityAdsBannerLoadDelegate)
extern void IosBanner_UnityAdsSetBannerLoadCallback_m1A3E70A31CD0B32135529D7ED5F1B1BAEAAF23BA ();
// 0x000000B7 System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner::UnityBannerInitialize()
extern void IosBanner_UnityBannerInitialize_mB0E2E075FAF91CF7B7ED45D3D3FDBC31EE07E929 ();
// 0x000000B8 System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner::UnityAdsBannerDidShow(System.String)
extern void IosBanner_UnityAdsBannerDidShow_m479FF8DFCC5FF717DD0C697293AA0AE3344A5BAC ();
// 0x000000B9 System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner::UnityAdsBannerDidHide(System.String)
extern void IosBanner_UnityAdsBannerDidHide_m962A229232E642CBE004986D344E7E10003FC677 ();
// 0x000000BA System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner::UnityAdsBannerClick(System.String)
extern void IosBanner_UnityAdsBannerClick_m341C27892A0477BE144DBA166127267951B01C97 ();
// 0x000000BB System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner::UnityAdsBannerDidError(System.String)
extern void IosBanner_UnityAdsBannerDidError_m225A971BCDD9E56C1F883B1C0D4A058ABD3C88D4 ();
// 0x000000BC System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner::UnityAdsBannerDidUnload(System.String)
extern void IosBanner_UnityAdsBannerDidUnload_m211228A6BA7CE8E28195354887A59605DFA5B55F ();
// 0x000000BD System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner::UnityAdsBannerDidLoad(System.String)
extern void IosBanner_UnityAdsBannerDidLoad_mBA64C7497389CEAF35DE3ACE131D6AA95A8EE6D5 ();
// 0x000000BE System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner::SetupBanner(UnityEngine.Advertisements.IBanner)
extern void IosBanner_SetupBanner_mD2519FCCCCDF25B49744EB8FBBFF0CE69E95686E ();
// 0x000000BF System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner::Show(System.String,UnityEngine.Advertisements.BannerOptions)
extern void IosBanner_Show_m4D4F439ECB0254938FA7730B794B7BA9AEA53C34 ();
// 0x000000C0 System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner::Hide(System.Boolean)
extern void IosBanner_Hide_mDC01869E0FE7F6D2E7C017664BFFD79F4F60DFE0 ();
// 0x000000C1 System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner::SetPosition(UnityEngine.Advertisements.BannerPosition)
extern void IosBanner_SetPosition_m536BEA054507000F39D4B20C85444280DB4221F8 ();
// 0x000000C2 System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner_UnityAdsBannerShowDelegate::.ctor(System.Object,System.IntPtr)
extern void UnityAdsBannerShowDelegate__ctor_m58C5C5AF77864A6C4DBA2DA019FBF8245A059ECB ();
// 0x000000C3 System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner_UnityAdsBannerShowDelegate::Invoke(System.String)
extern void UnityAdsBannerShowDelegate_Invoke_mCA53DCB8CD50B605675E7D208E62F3EB63E920D8 ();
// 0x000000C4 System.IAsyncResult UnityEngine.Advertisements.Platform.iOS.IosBanner_UnityAdsBannerShowDelegate::BeginInvoke(System.String,System.AsyncCallback,System.Object)
extern void UnityAdsBannerShowDelegate_BeginInvoke_m2C5D1DBE7DE2F4B1D018A7A91ACEF4A6496A0928 ();
// 0x000000C5 System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner_UnityAdsBannerShowDelegate::EndInvoke(System.IAsyncResult)
extern void UnityAdsBannerShowDelegate_EndInvoke_m268768360F8A9E0A704C1C1B007AFE964412C408 ();
// 0x000000C6 System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner_UnityAdsBannerHideDelegate::.ctor(System.Object,System.IntPtr)
extern void UnityAdsBannerHideDelegate__ctor_m7A3C1ED12E7059296722579E176EFD8846D5C650 ();
// 0x000000C7 System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner_UnityAdsBannerHideDelegate::Invoke(System.String)
extern void UnityAdsBannerHideDelegate_Invoke_mC9A6F7DDFAD5C190D9AA89484CDF829C38948CFA ();
// 0x000000C8 System.IAsyncResult UnityEngine.Advertisements.Platform.iOS.IosBanner_UnityAdsBannerHideDelegate::BeginInvoke(System.String,System.AsyncCallback,System.Object)
extern void UnityAdsBannerHideDelegate_BeginInvoke_mF92984308E973F433C390F68916B861DB407EC19 ();
// 0x000000C9 System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner_UnityAdsBannerHideDelegate::EndInvoke(System.IAsyncResult)
extern void UnityAdsBannerHideDelegate_EndInvoke_m64E3DA97B4BB237BC0D8EF39D5DF1276ED6DCA58 ();
// 0x000000CA System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner_UnityAdsBannerClickDelegate::.ctor(System.Object,System.IntPtr)
extern void UnityAdsBannerClickDelegate__ctor_mBC8B60745DD52DC05021B467755CFD843E376184 ();
// 0x000000CB System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner_UnityAdsBannerClickDelegate::Invoke(System.String)
extern void UnityAdsBannerClickDelegate_Invoke_mF275E8B52F919689654D0C2D1D3B41CB99424C72 ();
// 0x000000CC System.IAsyncResult UnityEngine.Advertisements.Platform.iOS.IosBanner_UnityAdsBannerClickDelegate::BeginInvoke(System.String,System.AsyncCallback,System.Object)
extern void UnityAdsBannerClickDelegate_BeginInvoke_m4A0A6E54E4E3BA990EA0A7C6E871CC80C68C3D08 ();
// 0x000000CD System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner_UnityAdsBannerClickDelegate::EndInvoke(System.IAsyncResult)
extern void UnityAdsBannerClickDelegate_EndInvoke_mAB4A2F2289F5858D0C70C08595245F399C3413C8 ();
// 0x000000CE System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner_UnityAdsBannerUnloadDelegate::.ctor(System.Object,System.IntPtr)
extern void UnityAdsBannerUnloadDelegate__ctor_mEEE0AADAB430564C2A56DAC0C51775D21C882D2D ();
// 0x000000CF System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner_UnityAdsBannerUnloadDelegate::Invoke(System.String)
extern void UnityAdsBannerUnloadDelegate_Invoke_m6812BC7EF8C948A4AC2425B78E3B76B880995EDF ();
// 0x000000D0 System.IAsyncResult UnityEngine.Advertisements.Platform.iOS.IosBanner_UnityAdsBannerUnloadDelegate::BeginInvoke(System.String,System.AsyncCallback,System.Object)
extern void UnityAdsBannerUnloadDelegate_BeginInvoke_m31E6451E35C7EF9D5C1DD20C644FE5D9E9E487F1 ();
// 0x000000D1 System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner_UnityAdsBannerUnloadDelegate::EndInvoke(System.IAsyncResult)
extern void UnityAdsBannerUnloadDelegate_EndInvoke_mD8928FE1F5C1D3AFB09EC6C2D40B22295459D0A3 ();
// 0x000000D2 System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner_UnityAdsBannerLoadDelegate::.ctor(System.Object,System.IntPtr)
extern void UnityAdsBannerLoadDelegate__ctor_m997345F50409E831F2913CC8C003685582500D44 ();
// 0x000000D3 System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner_UnityAdsBannerLoadDelegate::Invoke(System.String)
extern void UnityAdsBannerLoadDelegate_Invoke_m1D32F28BBC6213B53293201184BDF253B77495C0 ();
// 0x000000D4 System.IAsyncResult UnityEngine.Advertisements.Platform.iOS.IosBanner_UnityAdsBannerLoadDelegate::BeginInvoke(System.String,System.AsyncCallback,System.Object)
extern void UnityAdsBannerLoadDelegate_BeginInvoke_mDACCC685513EF4392C1E3B39CA56BD0259B00440 ();
// 0x000000D5 System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner_UnityAdsBannerLoadDelegate::EndInvoke(System.IAsyncResult)
extern void UnityAdsBannerLoadDelegate_EndInvoke_m53E71490E3A827400B671D107D170F13C5A26696 ();
// 0x000000D6 System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner_UnityAdsBannerErrorDelegate::.ctor(System.Object,System.IntPtr)
extern void UnityAdsBannerErrorDelegate__ctor_mAB4E556FBD8A452522E48C16676355B05D0CF8A0 ();
// 0x000000D7 System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner_UnityAdsBannerErrorDelegate::Invoke(System.String)
extern void UnityAdsBannerErrorDelegate_Invoke_m9C97872F54EAFA38DC78003DC808C80735B3F940 ();
// 0x000000D8 System.IAsyncResult UnityEngine.Advertisements.Platform.iOS.IosBanner_UnityAdsBannerErrorDelegate::BeginInvoke(System.String,System.AsyncCallback,System.Object)
extern void UnityAdsBannerErrorDelegate_BeginInvoke_m60CB636B28A61DB7623F4793C05EF8A0131F3F1F ();
// 0x000000D9 System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner_UnityAdsBannerErrorDelegate::EndInvoke(System.IAsyncResult)
extern void UnityAdsBannerErrorDelegate_EndInvoke_m06DD1AE71093308843E14543242D4BC48D3B7B51 ();
// 0x000000DA System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform::.ctor()
extern void IosPlatform__ctor_m3D3D0FAC2AE502C0D5B93F739F97CA5637B6CC3B ();
// 0x000000DB System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform::UnityAdsInitialize(System.String,System.Boolean,System.Boolean)
extern void IosPlatform_UnityAdsInitialize_m5F098102ACA1E143FDFC737EFDF6A9806CC1EE1A ();
// 0x000000DC System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform::UnityAdsShow(System.String)
extern void IosPlatform_UnityAdsShow_m09E9D10BABAF0D2A96EF7650E1A934B70BAFEC2B ();
// 0x000000DD System.Boolean UnityEngine.Advertisements.Platform.iOS.IosPlatform::UnityAdsIsReady(System.String)
extern void IosPlatform_UnityAdsIsReady_m9D6458623E59709C17ADF5C017F2CE544E28E2A6 ();
// 0x000000DE System.String UnityEngine.Advertisements.Platform.iOS.IosPlatform::UnityAdsGetVersion()
extern void IosPlatform_UnityAdsGetVersion_m77D93817AA4DB86BF8CC4501B7A88E652428A734 ();
// 0x000000DF System.Boolean UnityEngine.Advertisements.Platform.iOS.IosPlatform::UnityAdsIsInitialized()
extern void IosPlatform_UnityAdsIsInitialized_m0FF2150A002EA1AAB62CC8D78DE03507C5993734 ();
// 0x000000E0 System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform::UnityAdsSetMetaData(System.String,System.String)
extern void IosPlatform_UnityAdsSetMetaData_mB87910548FD22ADC04CA55C02084EA455AE7BC35 ();
// 0x000000E1 System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform::UnityAdsSetReadyCallback(UnityEngine.Advertisements.Platform.iOS.IosPlatform_UnityAdsReadyDelegate)
extern void IosPlatform_UnityAdsSetReadyCallback_m1ADC03B31059B9C4A8186B3E107CB00A297D4509 ();
// 0x000000E2 System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform::UnityAdsSetDidErrorCallback(UnityEngine.Advertisements.Platform.iOS.IosPlatform_UnityAdsDidErrorDelegate)
extern void IosPlatform_UnityAdsSetDidErrorCallback_mFC3F70FDF28D1A9F921775052923B99E835D267C ();
// 0x000000E3 System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform::UnityAdsSetDidStartCallback(UnityEngine.Advertisements.Platform.iOS.IosPlatform_UnityAdsDidStartDelegate)
extern void IosPlatform_UnityAdsSetDidStartCallback_mEE161FCD2CB10217D6C84B4CA0D431EB49420462 ();
// 0x000000E4 System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform::UnityAdsSetDidFinishCallback(UnityEngine.Advertisements.Platform.iOS.IosPlatform_UnityAdsDidFinishDelegate)
extern void IosPlatform_UnityAdsSetDidFinishCallback_m2E96CF362CB100596FA47DB04B2A4172D5557B3B ();
// 0x000000E5 System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform::UnityAdsReady(System.String)
extern void IosPlatform_UnityAdsReady_m319BB195D43D7FC9155FB331FFD50D44C12238F6 ();
// 0x000000E6 System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform::UnityAdsDidError(System.Int64,System.String)
extern void IosPlatform_UnityAdsDidError_m09DDB9048279569D3A5CA00BC8F25F8C20FCE61D ();
// 0x000000E7 System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform::UnityAdsDidStart(System.String)
extern void IosPlatform_UnityAdsDidStart_m4819019842B1C7483EDF5614FAC5A00B25F4E0FE ();
// 0x000000E8 System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform::UnityAdsDidFinish(System.String,System.Int64)
extern void IosPlatform_UnityAdsDidFinish_m485AA4E38648E5DCB1A62345997336849D029C1B ();
// 0x000000E9 System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform::SetupPlatform(UnityEngine.Advertisements.Platform.IPlatform)
extern void IosPlatform_SetupPlatform_m442553120CB307740C3C34451B2E09C75FE9AD23 ();
// 0x000000EA System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform::Initialize(System.String,System.Boolean,System.Boolean)
extern void IosPlatform_Initialize_m3BAD840E050CFB69A238E2967D5EB156E7B95C0C ();
// 0x000000EB System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform::Show(System.String)
extern void IosPlatform_Show_mC81369DB7EE3169853210D799826319886501955 ();
// 0x000000EC System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform::SetMetaData(UnityEngine.Advertisements.MetaData)
extern void IosPlatform_SetMetaData_m8F9C86DDAD5BA6448EED1B662055699C4B71F8A4 ();
// 0x000000ED System.String UnityEngine.Advertisements.Platform.iOS.IosPlatform::GetVersion()
extern void IosPlatform_GetVersion_mB30223FDCB0DBB7531B997F08F60C22F8125B4F8 ();
// 0x000000EE System.Boolean UnityEngine.Advertisements.Platform.iOS.IosPlatform::IsInitialized()
extern void IosPlatform_IsInitialized_m360B5F6BE16341E6B9DB44F0F297F857035C0DEF ();
// 0x000000EF System.Boolean UnityEngine.Advertisements.Platform.iOS.IosPlatform::IsReady(System.String)
extern void IosPlatform_IsReady_m78C6455A3BA23DECC45A256C998AA6C3E4F6618E ();
// 0x000000F0 System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform_UnityAdsReadyDelegate::.ctor(System.Object,System.IntPtr)
extern void UnityAdsReadyDelegate__ctor_mB97B6CF31BFBE8B2F04A6C0685D145522298F47F ();
// 0x000000F1 System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform_UnityAdsReadyDelegate::Invoke(System.String)
extern void UnityAdsReadyDelegate_Invoke_m914C2C386FCF9E43B13B259D57A92DAAE10F8966 ();
// 0x000000F2 System.IAsyncResult UnityEngine.Advertisements.Platform.iOS.IosPlatform_UnityAdsReadyDelegate::BeginInvoke(System.String,System.AsyncCallback,System.Object)
extern void UnityAdsReadyDelegate_BeginInvoke_m76FF9719993F3BFFBFC1D0B8C984E6FD596682CC ();
// 0x000000F3 System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform_UnityAdsReadyDelegate::EndInvoke(System.IAsyncResult)
extern void UnityAdsReadyDelegate_EndInvoke_m0B98E46310ABF044A6CF4A83275C54D331773395 ();
// 0x000000F4 System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform_UnityAdsDidErrorDelegate::.ctor(System.Object,System.IntPtr)
extern void UnityAdsDidErrorDelegate__ctor_mCEA29A147D82C71BBE633915E6BABD9D4FD68D34 ();
// 0x000000F5 System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform_UnityAdsDidErrorDelegate::Invoke(System.Int64,System.String)
extern void UnityAdsDidErrorDelegate_Invoke_mAA1782FFEA4F69C98DFEF4CE081E19A08A95E677 ();
// 0x000000F6 System.IAsyncResult UnityEngine.Advertisements.Platform.iOS.IosPlatform_UnityAdsDidErrorDelegate::BeginInvoke(System.Int64,System.String,System.AsyncCallback,System.Object)
extern void UnityAdsDidErrorDelegate_BeginInvoke_m334D69D401B1A7DA54CAC346116F598386266515 ();
// 0x000000F7 System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform_UnityAdsDidErrorDelegate::EndInvoke(System.IAsyncResult)
extern void UnityAdsDidErrorDelegate_EndInvoke_m1E9699CDFAE3EAF267FED5C782CC1C91F1091291 ();
// 0x000000F8 System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform_UnityAdsDidStartDelegate::.ctor(System.Object,System.IntPtr)
extern void UnityAdsDidStartDelegate__ctor_m278241276B577F0BBBBAB0110DE6E0B5C1F92C2F ();
// 0x000000F9 System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform_UnityAdsDidStartDelegate::Invoke(System.String)
extern void UnityAdsDidStartDelegate_Invoke_mF154BF1D5C699CB95779FA24AF57A6749F04FFCB ();
// 0x000000FA System.IAsyncResult UnityEngine.Advertisements.Platform.iOS.IosPlatform_UnityAdsDidStartDelegate::BeginInvoke(System.String,System.AsyncCallback,System.Object)
extern void UnityAdsDidStartDelegate_BeginInvoke_m4E3610D946FFD06B7687F493F7EA873B670EDCDB ();
// 0x000000FB System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform_UnityAdsDidStartDelegate::EndInvoke(System.IAsyncResult)
extern void UnityAdsDidStartDelegate_EndInvoke_mC05FD7E899DACDD3DB88F927CA56352D868E3750 ();
// 0x000000FC System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform_UnityAdsDidFinishDelegate::.ctor(System.Object,System.IntPtr)
extern void UnityAdsDidFinishDelegate__ctor_mE82556EDCC3FA994F55B319AF3B644DF65C04E49 ();
// 0x000000FD System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform_UnityAdsDidFinishDelegate::Invoke(System.String,System.Int64)
extern void UnityAdsDidFinishDelegate_Invoke_m03960E9E67E81CE243CC8C816EC0EB8FA571855A ();
// 0x000000FE System.IAsyncResult UnityEngine.Advertisements.Platform.iOS.IosPlatform_UnityAdsDidFinishDelegate::BeginInvoke(System.String,System.Int64,System.AsyncCallback,System.Object)
extern void UnityAdsDidFinishDelegate_BeginInvoke_m20798A9FA0BA7AA7BE16981577F59BE59FDB7C85 ();
// 0x000000FF System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform_UnityAdsDidFinishDelegate::EndInvoke(System.IAsyncResult)
extern void UnityAdsDidFinishDelegate_EndInvoke_m2C9891F854E2A1E1D7B57CFEB8A72E6980A7B79D ();
// 0x00000100 System.Void UnityEngine.Advertisements.Platform.Editor.BannerPlaceholder::.ctor()
extern void BannerPlaceholder__ctor_m42D595877049425245A79797739CC663517C340A ();
// 0x00000101 System.Void UnityEngine.Advertisements.Platform.Editor.BannerPlaceholder::Awake()
extern void BannerPlaceholder_Awake_m05F8072675DCBA4136A980738CE7CCAB7CB2D5BC ();
// 0x00000102 System.Void UnityEngine.Advertisements.Platform.Editor.BannerPlaceholder::OnGUI()
extern void BannerPlaceholder_OnGUI_m0DD6CC6081016571928BA57B5160412DDACFAAEF ();
// 0x00000103 System.Void UnityEngine.Advertisements.Platform.Editor.BannerPlaceholder::ShowBanner(UnityEngine.Advertisements.BannerPosition,UnityEngine.Advertisements.BannerOptions)
extern void BannerPlaceholder_ShowBanner_m62C03D1AC62034FB73309A4345312AB2254AFDA4 ();
// 0x00000104 System.Void UnityEngine.Advertisements.Platform.Editor.BannerPlaceholder::HideBanner()
extern void BannerPlaceholder_HideBanner_mF51A34112B197F2482B2FC5A7EF6EA43C10BA8F6 ();
// 0x00000105 UnityEngine.Texture2D UnityEngine.Advertisements.Platform.Editor.BannerPlaceholder::BackgroundTexture(System.Int32,System.Int32,UnityEngine.Color)
extern void BannerPlaceholder_BackgroundTexture_mAED97D50A7E019FD73B53CA40A57C2CB3DDB3D2C ();
// 0x00000106 UnityEngine.Rect UnityEngine.Advertisements.Platform.Editor.BannerPlaceholder::GetBannerRect(UnityEngine.Advertisements.BannerPosition)
extern void BannerPlaceholder_GetBannerRect_mFBC1439AC4A275B580934C3DD8D7DE75BAD19B07 ();
// 0x00000107 System.Void UnityEngine.Advertisements.Utilities.CoroutineExecutor::.ctor()
extern void CoroutineExecutor__ctor_m6E3F440976148531A2C26801601B79AE0CBE17D8 ();
// 0x00000108 System.Void UnityEngine.Advertisements.Utilities.CoroutineExecutor::Update()
extern void CoroutineExecutor_Update_mFF1EF39361E7600E3C622F1D6677437D734500AA ();
// 0x00000109 System.Void UnityEngine.Advertisements.Utilities.UnityLifecycleManager::.ctor()
extern void UnityLifecycleManager__ctor_mCE539A0B02C434157694A631324BD519DA7D522C ();
// 0x0000010A System.Void UnityEngine.Advertisements.Utilities.UnityLifecycleManager::Initialize()
extern void UnityLifecycleManager_Initialize_mC1298AF398B8696F752C3B69C82AA089922DA0A3 ();
// 0x0000010B System.Void UnityEngine.Advertisements.Utilities.UnityLifecycleManager::Post(System.Action)
extern void UnityLifecycleManager_Post_m4012D24BC270B3C3CD3F0AE181664F1C411263C6 ();
// 0x0000010C System.Void UnityEngine.Advertisements.Utilities.UnityLifecycleManager::Dispose()
extern void UnityLifecycleManager_Dispose_mC557F087108E69FA821C5D45683594AF411F85B7 ();
// 0x0000010D System.Void UnityEngine.Advertisements.Utilities.IUnityLifecycleManager::Post(System.Action)
// 0x0000010E System.Void UnityEngine.Advertisements.Utilities.ApplicationQuit::.ctor()
extern void ApplicationQuit__ctor_m7D6F9F429C9C7FC9F149F939D7BA312286E0F4C5 ();
// 0x0000010F System.Void UnityEngine.Advertisements.Utilities.ApplicationQuit::add_OnApplicationQuitEventHandler(UnityEngine.Events.UnityAction)
extern void ApplicationQuit_add_OnApplicationQuitEventHandler_m4C0EA50764A840FFCEAC0F1B26B6B74F781B9B41 ();
// 0x00000110 System.Void UnityEngine.Advertisements.Utilities.ApplicationQuit::remove_OnApplicationQuitEventHandler(UnityEngine.Events.UnityAction)
extern void ApplicationQuit_remove_OnApplicationQuitEventHandler_mE74B8DC6642B26013B2B9EC104E86EF5D1BB9AEB ();
// 0x00000111 System.Void UnityEngine.Advertisements.Utilities.ApplicationQuit::OnApplicationQuit()
extern void ApplicationQuit_OnApplicationQuit_m470F95E4EE4D9486DC5114B69C27EFECB0C34CCD ();
// 0x00000112 System.String UnityEngine.Advertisements.Utilities.Json::Serialize(System.Object)
extern void Json_Serialize_m68A7236E65EBD6B1AD9102B4E59C1A9D26BE26C3 ();
// 0x00000113 System.Void UnityEngine.Advertisements.Utilities.Json_Serializer::.ctor()
extern void Serializer__ctor_m5F6AB25FBE2D75ADB7E6F312834DA8BB64C99071 ();
// 0x00000114 System.String UnityEngine.Advertisements.Utilities.Json_Serializer::Serialize(System.Object)
extern void Serializer_Serialize_m6E705AA0C97D3B9B207CF0E5855D8B3A32CD8E14 ();
// 0x00000115 System.Void UnityEngine.Advertisements.Utilities.Json_Serializer::SerializeValue(System.Object)
extern void Serializer_SerializeValue_m693E9D860C8818EAA2BD342129062FCC1E8A2CDE ();
// 0x00000116 System.Void UnityEngine.Advertisements.Utilities.Json_Serializer::SerializeObject(System.Collections.IDictionary)
extern void Serializer_SerializeObject_m3C84A8E910E016AA99919EEAFB0C32ED242A5BDD ();
// 0x00000117 System.Void UnityEngine.Advertisements.Utilities.Json_Serializer::SerializeArray(System.Collections.IList)
extern void Serializer_SerializeArray_m9AF495B0B15492784A25B35817602D0293641212 ();
// 0x00000118 System.Void UnityEngine.Advertisements.Utilities.Json_Serializer::SerializeString(System.String)
extern void Serializer_SerializeString_m4E597CF9226136E22D9AB1BF3879813B93C3C521 ();
// 0x00000119 System.Void UnityEngine.Advertisements.Utilities.Json_Serializer::SerializeOther(System.Object)
extern void Serializer_SerializeOther_mF72BE34FE03E7BD04D5F1447254EB0011E7E655E ();
// 0x0000011A System.Void UnityEngine.Advertisements.Events.FinishEventArgs::.ctor(System.String,UnityEngine.Advertisements.ShowResult)
extern void FinishEventArgs__ctor_m50A823827CD440BA8B0613C7EE3F088576653512 ();
// 0x0000011B UnityEngine.Advertisements.ShowResult UnityEngine.Advertisements.Events.FinishEventArgs::get_showResult()
extern void FinishEventArgs_get_showResult_m8C9B4D0595B80FC4CDAED80069D8C2760CDE82D3 ();
// 0x0000011C System.Void UnityEngine.Advertisements.Events.StartEventArgs::.ctor(System.String)
extern void StartEventArgs__ctor_m8ABE0DAE8061CB485842A0CD9248DE8EDA5A4940 ();
static Il2CppMethodPointer s_methodPointers[284] = 
{
	ShowOptions_get_resultCallback_mC3948B1267192174F92702667591E93985558B70,
	ShowOptions_get_gamerSid_mFDAB07F6EE1943128FF4B7750B9D61A12E200F76,
	BannerOptions_get_showCallback_m2EBCC1023270E883F0FAF6DFF2DB6DFB19785F39,
	BannerOptions_get_hideCallback_mE3DB6C441CFAE02A22522DEEBDFE56DA7110CABF,
	BannerOptions_get_clickCallback_m723381DBDAA18D58F086B4BC7A9EB0A241DFE546,
	BannerCallback__ctor_m4A5CEE2B08DC1ED92500DE2D9973BA61638961C3,
	BannerCallback_Invoke_m2EF171C33ED3F7EA79C1504F7EEDC14505EEFDAF,
	BannerCallback_BeginInvoke_m9C7D41D41B14B03DAA22099079CEE0A214C85C5B,
	BannerCallback_EndInvoke_mA5E76201A8D3B2B0B44D7BD11B560131D66AC468,
	MetaData__ctor_m1EE75B864AC4AB45297350AF9F998579F9B453AC,
	MetaData_get_category_m0801693A3D46ABD34D29C721FF280F15330F3DC3,
	MetaData_set_category_m32438732A0862A12D370612605959108FA1D6B04,
	MetaData_Set_mC0347747AEBC7A3CAA9799A7DAA1A26520550B61,
	MetaData_ToJSON_m57AA888160C99880EA1C4C5A012F860D8FB45A69,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	BannerLoadOptions_get_loadCallback_mBBC0F2088F4E97189B2C5E2499D3EF0851654FDE,
	BannerLoadOptions_get_errorCallback_m357E3E571C04C8060D9D4A3852DFAD120CC8FDC7,
	LoadCallback__ctor_m8ADBF2C1CC3A87D11E2DA8AA427646C8BB84A281,
	LoadCallback_Invoke_mF8A5AD28B2BCACECCB4DE776B3D4CA8EBFE64092,
	LoadCallback_BeginInvoke_mFD6EF4643E3B89A4FA252735ABFEF0CE017F6DCC,
	LoadCallback_EndInvoke_m9D6940BF1FACF29FE272E5163C3E737AAD5E69B4,
	ErrorCallback__ctor_m9E5D36391B88115BE3162E8CBAA777E609196C4A,
	ErrorCallback_Invoke_m059AFC00B21E0276308B67BEC19DCBBF4AA5DF72,
	ErrorCallback_BeginInvoke_m3C14CFA75C836AB06A6C49FBCAF01062A30915DF,
	ErrorCallback_EndInvoke_mA8836BD90911979B479A0062CF21BD130F866F4C,
	Banner__ctor_mB35B9DCC5D3D226D12923FF2A5F80A3C2C3AE5A8,
	Banner_get_UnityLifecycleManager_m97C44211F5006FC2D8918F26CD9496C0F1E3B5BD,
	Banner_Show_m9561F00C63B7DAB87116BEECDCE34E6269657AA1,
	Banner_Hide_m968C081FCB6CFEAB21A72B109BE5B0EB33C501D1,
	Banner_SetPosition_mD4AD41F0D92E03376D94859CF201895AF6929F99,
	Banner_UnityAdsBannerDidShow_m0122ED43437F1FCB4FFA4BB83C30FAF1430E0D18,
	Banner_UnityAdsBannerDidHide_mC8AB71EA7805B137F39F45677FE034455BED74A7,
	Banner_UnityAdsBannerClick_mC6ECBE3B7F8DA885033C9619E755B8850C330B3F,
	Banner_UnityAdsBannerDidLoad_mFB34C6C0B89878F0E740F827BA96A2874121334A,
	Banner_UnityAdsBannerDidError_m155CCCDD48983231EB3FB8BF8A7D47374CA4465F,
	U3CUnityAdsBannerDidShowU3Ec__AnonStorey0__ctor_mEEB42B8011106629A20BD41CA2AD8E8707B03CC6,
	U3CUnityAdsBannerDidShowU3Ec__AnonStorey0_U3CU3Em__0_m719872728637660A222D25A946D11306EE822FF5,
	U3CUnityAdsBannerDidHideU3Ec__AnonStorey1__ctor_mC39805B151259AE9AC2C0CD843FD5E24EEBC3F57,
	U3CUnityAdsBannerDidHideU3Ec__AnonStorey1_U3CU3Em__0_m46B4B677BAADB30919E74D76525B56C8F7A90AF1,
	U3CUnityAdsBannerClickU3Ec__AnonStorey2__ctor_mBAA0B86F6D709CEA9D7CD28C4BCBE50B9320E5AB,
	U3CUnityAdsBannerClickU3Ec__AnonStorey2_U3CU3Em__0_m6945721AC093202F3B8EB363C52BA3C3436E7C2C,
	U3CUnityAdsBannerDidLoadU3Ec__AnonStorey3__ctor_mA9E9E6A4328B0B0CBC62FD191BE27D6EF357A23E,
	U3CUnityAdsBannerDidLoadU3Ec__AnonStorey3_U3CU3Em__0_m4E8D505D5751A99869987CDE00F62804D1BD5C7E,
	U3CUnityAdsBannerDidErrorU3Ec__AnonStorey4__ctor_m3AC5F288AC7CD4E4C5A6BA0A68B22B6AD0462E25,
	U3CUnityAdsBannerDidErrorU3Ec__AnonStorey4_U3CU3Em__0_m7220D8E94FCADA52A99330CE161C9A5A1A360EC6,
	Advertisement__cctor_mC890142D0DDB7F12D9624F4B5D47CDA2AD1050B8,
	Advertisement_get_isInitialized_mEEE939B4C7076C75A5F905747A55D9E17A9E184C,
	Advertisement_Initialize_m148388763C32FB12D7CFC87F8316BC2FE8F59107,
	Advertisement_Initialize_mF7B38D03551DF7610F28487B3BDA8B49AD699CBC,
	Advertisement_IsReady_m809BD2B6DD398ECCF7638A759D2B46032025655C,
	Advertisement_Show_m083D3FF59AB2E5BB4160504DD86C4350B3510DD2,
	Advertisement_AddListener_mA5F78EEF8B48CFC7CFB3EFEE7A4072480635102D,
	Advertisement_CreatePlatform_mDFF4823F9F13CABBA0EB972D332E86934456D34D,
	Banner_Show_m096C8240D65605B7D8AD8229CC9C830F140715E7,
	Banner_Show_m9F393EA3D089BF375B41FA23468F99DE6285411D,
	Banner_Hide_m20BEF43068CC52E4FDFDD036C7465C09EC51FA04,
	Banner_SetPosition_mCD9D0A9978CAC927B4FBCB107711CB06AB23FECE,
	Purchasing_Initialize_mF4A8374F4858B4E9BCE8D87B9DA0793236AC8EF1,
	Purchasing_InitiatePurchasingCommand_mEBA0D3B87A1F4DA656437929C7144421153A17F1,
	Purchasing_GetPurchasingCatalog_m9BA5C0687658841756A08E42123C484FD987A485,
	Purchasing_GetPromoVersion_m06F34E013F91BC43A8C5CF32CDEDB7FB95678839,
	Purchasing__cctor_m7570A4768D9E7EAA1CE09D9DF60E5E7BA2D19E9A,
	PurchasingPlatform__ctor_mF3B8D47CA9732083F21BCC00536A4B6118093673,
	PurchasingPlatform_get_Instance_m72DA530720E565DF78BCCF604004F4F2F4A8B434,
	PurchasingPlatform_set_Instance_m06C014D5A2B12148CC1BFF271E9243CECB4F240F,
	PurchasingPlatform_UnityAdsPurchasingDispatchReturnEvent_mBF61122298091E8027B03BCA4E1E63A5FD2C12B5,
	PurchasingPlatform_UnityAdsSetDidInitiatePurchasingCommandCallback_m7B176FF13BA5586DD8B8305BE4BDEB3BBB094923,
	PurchasingPlatform_UnityAdsSetGetProductCatalogCallback_m0C53D7513574919071E4B4A9CB336DE7C47D4C94,
	PurchasingPlatform_UnityAdsSetGetVersionCallback_mF2B05D19FD832B0A68CB27F1845B171586F0C432,
	PurchasingPlatform_UnityAdsSetInitializePurchasingCallback_m30A3EEC475DA824B4C8A7D3A30C9F5C4EE233898,
	PurchasingPlatform_UnityAdsDidInitiatePurchasingCommand_mE239DF35A9FA1DC1A39FC719A7BBE3DE7944AFD3,
	PurchasingPlatform_UnityAdsPurchasingGetProductCatalog_m8D60D398C4FEB99B98E3E9E155F9C7F215B32CA4,
	PurchasingPlatform_UnityAdsPurchasingGetPurchasingVersion_mF1D69129A470B6044F8FDBDBC3DF07BA13CB371C,
	PurchasingPlatform_UnityAdsPurchasingInitialize_m1388AD424E6D90AC991C7556C7CF74950173A0DE,
	PurchasingPlatform_Initialize_m2AE04AD473D437A6B6A9C8459E27C0CC092F748F,
	unityAdsPurchasingDidInitiatePurchasingCommand__ctor_m28E30D006BC66BC32C20D6839ED54404F945B134,
	unityAdsPurchasingDidInitiatePurchasingCommand_Invoke_mC5C5C7B26D69AADE2916B7F1F7A71488B342E645,
	unityAdsPurchasingDidInitiatePurchasingCommand_BeginInvoke_m644D0444027B5319886F5D810B72E82D73C541E7,
	unityAdsPurchasingDidInitiatePurchasingCommand_EndInvoke_m799AAECFBB786E5A0FCF3BD4BD566BACFAA74D40,
	unityAdsPurchasingGetProductCatalog__ctor_m278CBE91CC435FBBE733F85108449A709108F910,
	unityAdsPurchasingGetProductCatalog_Invoke_m47CCEE3CF2FEA122C64808D0C07204464AA41155,
	unityAdsPurchasingGetProductCatalog_BeginInvoke_mE94C0EDEBAD4E37D92DEF4C7946D8DAEB9AF1525,
	unityAdsPurchasingGetProductCatalog_EndInvoke_m211938B4FF62457D47A271FF39EFFC994A9FB2D8,
	unityAdsPurchasingGetPurchasingVersion__ctor_m6E2FD0205408F0F56B7412144E7BC1B3FEC9F88E,
	unityAdsPurchasingGetPurchasingVersion_Invoke_m1B88E693E7CC7B2309387B87CCA07A42F9237E06,
	unityAdsPurchasingGetPurchasingVersion_BeginInvoke_mF7741AC99775B183263DDDB273DE319818165014,
	unityAdsPurchasingGetPurchasingVersion_EndInvoke_mF064626A5DDAFD248156DE32FAD2A487019EAFCE,
	unityAdsPurchasingInitialize__ctor_m2CA7DBB4F8FDAE18351B4DE5C2A927E486A00664,
	unityAdsPurchasingInitialize_Invoke_m9B49A03FBCCCFB6880B4796F4709DF5722240603,
	unityAdsPurchasingInitialize_BeginInvoke_m44F14ADAD392691289914061603F7AD14B845D51,
	unityAdsPurchasingInitialize_EndInvoke_mE57A3C79549C52C6C45FE51ECCF92C67F96A5B58,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	Platform__ctor_m08E862A217AD3BCC538DBCB746D6CDDBB9D1BE9E,
	Platform_add_OnStart_m792304EB0698E5AE304E0F60C0F7FF352CB11037,
	Platform_remove_OnStart_m5D801D82BBA3E8FE44A6B3087B991E353C747206,
	Platform_add_OnFinish_mDFC773F30B590A2EB8FE28E524E58746B0EBC760,
	Platform_remove_OnFinish_mEB885423D4D62EAE0E6F05B8150765CA3ED3174E,
	Platform_get_Banner_m5A4FFF22ABD28C1A6F71F206D44D52361B0533B3,
	Platform_get_UnityLifecycleManager_m2F9285DC280DBE54C036EB569069C52D0EDCFEC1,
	Platform_get_NativePlatform_mB585CB86329C4669F4BCBB750E8EF249842D1999,
	Platform_get_IsInitialized_mB2B9D57DF48928E53C65ADDD24398BBA6589EBD8,
	Platform_get_IsShowing_m8A4E0658F585985073F809B2CCA3587C56D10337,
	Platform_set_IsShowing_m9A4BEF7199F966CB29E139D4AB8AAA6908BF635B,
	Platform_get_Version_m073B2F3853CF8E58403C3DEA6EFF79BBDC7592C3,
	Platform_get_Listeners_m0B513E377340B1C9DD2653D336BB26B08AE7230D,
	Platform_Initialize_mE241B88B7E31648734C0031B144892BFD7AB0EF3,
	Platform_Show_m66EF021A4AA7E072D76863209D90B24C082EEBBE,
	Platform_AddListener_m10D88F995A14ABA6AB51686E1F5453C9CD085B20,
	Platform_IsReady_m03ED55C3014138E68153FBB36384DE2828ABB823,
	Platform_SetMetaData_mF7DB479133D95A29CDE63A3AC82E27B82114577D,
	Platform_UnityAdsReady_mBAC7A214B6059EA25119F89E402ABE9E3EEB3031,
	Platform_UnityAdsDidError_m86810671646400CDD496EC2088990830671F6F25,
	Platform_UnityAdsDidStart_m4473FE0C5D24DFE28714CFD81451E72E4B9BEF50,
	Platform_UnityAdsDidFinish_mE7EEE0FEA36F2C56333554D1D3DD4CF48921454E,
	Platform_GetClonedHashSet_mCD4507B8B9D1405987C47C80195E48EC9EDB071A,
	Platform_U3CInitializeU3Em__0_m4A24234C140B6FC007256CAEBA1C4A46728B03B7,
	Platform_U3CInitializeU3Em__1_mF4A5D389B28ACA046C818832B5711691628BB673,
	U3CShowU3Ec__AnonStorey0__ctor_m1971B90A112FB89812BA91B3BB1D6D41AE45241D,
	U3CShowU3Ec__AnonStorey1__ctor_m1A22D5F3FFFB693A8C68FBC098A96550F735C529,
	U3CShowU3Ec__AnonStorey1_U3CU3Em__0_mEE89C80DD462405B1575D1B4C766E3EDA88A911C,
	U3CUnityAdsReadyU3Ec__AnonStorey2__ctor_m42DB75A81A8CD425E73DF80058C9670F5122D0CA,
	U3CUnityAdsReadyU3Ec__AnonStorey2_U3CU3Em__0_m87928B642173FB247EDFC647B597269D34FE3A2A,
	U3CUnityAdsDidErrorU3Ec__AnonStorey3__ctor_m84919A69D972B1891D13AEE64F9B7A917FFB1DA8,
	U3CUnityAdsDidErrorU3Ec__AnonStorey3_U3CU3Em__0_m88746A068BBADC0BDF866EEE1E1CEAFE9CD8A9F8,
	U3CUnityAdsDidStartU3Ec__AnonStorey4__ctor_mDAC2110307769014336CDB8757E7EA082D194220,
	U3CUnityAdsDidStartU3Ec__AnonStorey4_U3CU3Em__0_mE3D0F8D957A6FADC022A1210D35874A133A9FA28,
	U3CUnityAdsDidFinishU3Ec__AnonStorey5__ctor_mA43D96AF35CD28E89AA0B31DED224E8C8A599EE8,
	U3CUnityAdsDidFinishU3Ec__AnonStorey5_U3CU3Em__0_m15ABB4C914B0280BFCDC37A763F2EA60C6994FD9,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	UnsupportedPlatform__ctor_m5C391C1F4054AACEB65656A712FDA630F9EDA58C,
	UnsupportedPlatform_SetupPlatform_m2A2420F10F49EB741E3F47A16C6E894E5611F71C,
	UnsupportedPlatform_Initialize_mCF80912266B6AC82F0E857E2135784B67BCE7622,
	UnsupportedPlatform_Show_mA5EB8A0295A8EBA6163D77D7C5A5F75FDB93DE01,
	UnsupportedPlatform_SetMetaData_mCBC113C5E270591138DC51C19647BFCE026BC152,
	UnsupportedPlatform_GetVersion_m0D75CB76941356B012804F863B3CB340AE08D93F,
	UnsupportedPlatform_IsInitialized_m4B088A3F553A6E94193E5E4C9E923356B31133E2,
	UnsupportedPlatform_IsReady_m79613959C9355961166D55827EBCBBC4806D7938,
	UnsupportedBanner__ctor_m7F210B499A06A7A5956582B7F920CA5116F15019,
	UnsupportedBanner_SetupBanner_m78DCB47FF13B4C934D8C8EFCFFC6C0FDCCA3534D,
	UnsupportedBanner_Show_mD12A749775E08E9030EE02BCAD5B477766D4C7C6,
	UnsupportedBanner_Hide_m04094D5CEEF142DE24CCABBEFA387D38F13C3865,
	UnsupportedBanner_SetPosition_mD4C6CC9F4D10CE99979B370F810E41E9AE6EC991,
	IosBanner__ctor_mFFE0864913014B3FB06C0B70EB6C5EE56F387381,
	IosBanner_UnityAdsBannerShow_mA18FC45EA1736F29A5EDCF16E4517BF5546C8625,
	IosBanner_UnityAdsBannerHide_m07DF7BBF0EBBD2815F9A1A8191D73B53440F3D2D,
	IosBanner_UnityAdsBannerSetPosition_m1A0700BE5976BE34744413D6BAAB122A2FAA5C7C,
	IosBanner_UnityAdsSetBannerShowCallback_mF187E366DF81797104E020418AD3B3DADA813C74,
	IosBanner_UnityAdsSetBannerHideCallback_m2B973AA69E5DF1DB80C667C62C24FD64329F8FC2,
	IosBanner_UnityAdsSetBannerClickCallback_m7F8C336F2EB3DF345AD8AEE707D652E3769F08B2,
	IosBanner_UnityAdsSetBannerErrorCallback_mE89232FFF832B2269E9F12FA6EA443A24F551CD6,
	IosBanner_UnityAdsSetBannerUnloadCallback_m5AF802647514704499357A4056B814CDF32D600F,
	IosBanner_UnityAdsSetBannerLoadCallback_m1A3E70A31CD0B32135529D7ED5F1B1BAEAAF23BA,
	IosBanner_UnityBannerInitialize_mB0E2E075FAF91CF7B7ED45D3D3FDBC31EE07E929,
	IosBanner_UnityAdsBannerDidShow_m479FF8DFCC5FF717DD0C697293AA0AE3344A5BAC,
	IosBanner_UnityAdsBannerDidHide_m962A229232E642CBE004986D344E7E10003FC677,
	IosBanner_UnityAdsBannerClick_m341C27892A0477BE144DBA166127267951B01C97,
	IosBanner_UnityAdsBannerDidError_m225A971BCDD9E56C1F883B1C0D4A058ABD3C88D4,
	IosBanner_UnityAdsBannerDidUnload_m211228A6BA7CE8E28195354887A59605DFA5B55F,
	IosBanner_UnityAdsBannerDidLoad_mBA64C7497389CEAF35DE3ACE131D6AA95A8EE6D5,
	IosBanner_SetupBanner_mD2519FCCCCDF25B49744EB8FBBFF0CE69E95686E,
	IosBanner_Show_m4D4F439ECB0254938FA7730B794B7BA9AEA53C34,
	IosBanner_Hide_mDC01869E0FE7F6D2E7C017664BFFD79F4F60DFE0,
	IosBanner_SetPosition_m536BEA054507000F39D4B20C85444280DB4221F8,
	UnityAdsBannerShowDelegate__ctor_m58C5C5AF77864A6C4DBA2DA019FBF8245A059ECB,
	UnityAdsBannerShowDelegate_Invoke_mCA53DCB8CD50B605675E7D208E62F3EB63E920D8,
	UnityAdsBannerShowDelegate_BeginInvoke_m2C5D1DBE7DE2F4B1D018A7A91ACEF4A6496A0928,
	UnityAdsBannerShowDelegate_EndInvoke_m268768360F8A9E0A704C1C1B007AFE964412C408,
	UnityAdsBannerHideDelegate__ctor_m7A3C1ED12E7059296722579E176EFD8846D5C650,
	UnityAdsBannerHideDelegate_Invoke_mC9A6F7DDFAD5C190D9AA89484CDF829C38948CFA,
	UnityAdsBannerHideDelegate_BeginInvoke_mF92984308E973F433C390F68916B861DB407EC19,
	UnityAdsBannerHideDelegate_EndInvoke_m64E3DA97B4BB237BC0D8EF39D5DF1276ED6DCA58,
	UnityAdsBannerClickDelegate__ctor_mBC8B60745DD52DC05021B467755CFD843E376184,
	UnityAdsBannerClickDelegate_Invoke_mF275E8B52F919689654D0C2D1D3B41CB99424C72,
	UnityAdsBannerClickDelegate_BeginInvoke_m4A0A6E54E4E3BA990EA0A7C6E871CC80C68C3D08,
	UnityAdsBannerClickDelegate_EndInvoke_mAB4A2F2289F5858D0C70C08595245F399C3413C8,
	UnityAdsBannerUnloadDelegate__ctor_mEEE0AADAB430564C2A56DAC0C51775D21C882D2D,
	UnityAdsBannerUnloadDelegate_Invoke_m6812BC7EF8C948A4AC2425B78E3B76B880995EDF,
	UnityAdsBannerUnloadDelegate_BeginInvoke_m31E6451E35C7EF9D5C1DD20C644FE5D9E9E487F1,
	UnityAdsBannerUnloadDelegate_EndInvoke_mD8928FE1F5C1D3AFB09EC6C2D40B22295459D0A3,
	UnityAdsBannerLoadDelegate__ctor_m997345F50409E831F2913CC8C003685582500D44,
	UnityAdsBannerLoadDelegate_Invoke_m1D32F28BBC6213B53293201184BDF253B77495C0,
	UnityAdsBannerLoadDelegate_BeginInvoke_mDACCC685513EF4392C1E3B39CA56BD0259B00440,
	UnityAdsBannerLoadDelegate_EndInvoke_m53E71490E3A827400B671D107D170F13C5A26696,
	UnityAdsBannerErrorDelegate__ctor_mAB4E556FBD8A452522E48C16676355B05D0CF8A0,
	UnityAdsBannerErrorDelegate_Invoke_m9C97872F54EAFA38DC78003DC808C80735B3F940,
	UnityAdsBannerErrorDelegate_BeginInvoke_m60CB636B28A61DB7623F4793C05EF8A0131F3F1F,
	UnityAdsBannerErrorDelegate_EndInvoke_m06DD1AE71093308843E14543242D4BC48D3B7B51,
	IosPlatform__ctor_m3D3D0FAC2AE502C0D5B93F739F97CA5637B6CC3B,
	IosPlatform_UnityAdsInitialize_m5F098102ACA1E143FDFC737EFDF6A9806CC1EE1A,
	IosPlatform_UnityAdsShow_m09E9D10BABAF0D2A96EF7650E1A934B70BAFEC2B,
	IosPlatform_UnityAdsIsReady_m9D6458623E59709C17ADF5C017F2CE544E28E2A6,
	IosPlatform_UnityAdsGetVersion_m77D93817AA4DB86BF8CC4501B7A88E652428A734,
	IosPlatform_UnityAdsIsInitialized_m0FF2150A002EA1AAB62CC8D78DE03507C5993734,
	IosPlatform_UnityAdsSetMetaData_mB87910548FD22ADC04CA55C02084EA455AE7BC35,
	IosPlatform_UnityAdsSetReadyCallback_m1ADC03B31059B9C4A8186B3E107CB00A297D4509,
	IosPlatform_UnityAdsSetDidErrorCallback_mFC3F70FDF28D1A9F921775052923B99E835D267C,
	IosPlatform_UnityAdsSetDidStartCallback_mEE161FCD2CB10217D6C84B4CA0D431EB49420462,
	IosPlatform_UnityAdsSetDidFinishCallback_m2E96CF362CB100596FA47DB04B2A4172D5557B3B,
	IosPlatform_UnityAdsReady_m319BB195D43D7FC9155FB331FFD50D44C12238F6,
	IosPlatform_UnityAdsDidError_m09DDB9048279569D3A5CA00BC8F25F8C20FCE61D,
	IosPlatform_UnityAdsDidStart_m4819019842B1C7483EDF5614FAC5A00B25F4E0FE,
	IosPlatform_UnityAdsDidFinish_m485AA4E38648E5DCB1A62345997336849D029C1B,
	IosPlatform_SetupPlatform_m442553120CB307740C3C34451B2E09C75FE9AD23,
	IosPlatform_Initialize_m3BAD840E050CFB69A238E2967D5EB156E7B95C0C,
	IosPlatform_Show_mC81369DB7EE3169853210D799826319886501955,
	IosPlatform_SetMetaData_m8F9C86DDAD5BA6448EED1B662055699C4B71F8A4,
	IosPlatform_GetVersion_mB30223FDCB0DBB7531B997F08F60C22F8125B4F8,
	IosPlatform_IsInitialized_m360B5F6BE16341E6B9DB44F0F297F857035C0DEF,
	IosPlatform_IsReady_m78C6455A3BA23DECC45A256C998AA6C3E4F6618E,
	UnityAdsReadyDelegate__ctor_mB97B6CF31BFBE8B2F04A6C0685D145522298F47F,
	UnityAdsReadyDelegate_Invoke_m914C2C386FCF9E43B13B259D57A92DAAE10F8966,
	UnityAdsReadyDelegate_BeginInvoke_m76FF9719993F3BFFBFC1D0B8C984E6FD596682CC,
	UnityAdsReadyDelegate_EndInvoke_m0B98E46310ABF044A6CF4A83275C54D331773395,
	UnityAdsDidErrorDelegate__ctor_mCEA29A147D82C71BBE633915E6BABD9D4FD68D34,
	UnityAdsDidErrorDelegate_Invoke_mAA1782FFEA4F69C98DFEF4CE081E19A08A95E677,
	UnityAdsDidErrorDelegate_BeginInvoke_m334D69D401B1A7DA54CAC346116F598386266515,
	UnityAdsDidErrorDelegate_EndInvoke_m1E9699CDFAE3EAF267FED5C782CC1C91F1091291,
	UnityAdsDidStartDelegate__ctor_m278241276B577F0BBBBAB0110DE6E0B5C1F92C2F,
	UnityAdsDidStartDelegate_Invoke_mF154BF1D5C699CB95779FA24AF57A6749F04FFCB,
	UnityAdsDidStartDelegate_BeginInvoke_m4E3610D946FFD06B7687F493F7EA873B670EDCDB,
	UnityAdsDidStartDelegate_EndInvoke_mC05FD7E899DACDD3DB88F927CA56352D868E3750,
	UnityAdsDidFinishDelegate__ctor_mE82556EDCC3FA994F55B319AF3B644DF65C04E49,
	UnityAdsDidFinishDelegate_Invoke_m03960E9E67E81CE243CC8C816EC0EB8FA571855A,
	UnityAdsDidFinishDelegate_BeginInvoke_m20798A9FA0BA7AA7BE16981577F59BE59FDB7C85,
	UnityAdsDidFinishDelegate_EndInvoke_m2C9891F854E2A1E1D7B57CFEB8A72E6980A7B79D,
	BannerPlaceholder__ctor_m42D595877049425245A79797739CC663517C340A,
	BannerPlaceholder_Awake_m05F8072675DCBA4136A980738CE7CCAB7CB2D5BC,
	BannerPlaceholder_OnGUI_m0DD6CC6081016571928BA57B5160412DDACFAAEF,
	BannerPlaceholder_ShowBanner_m62C03D1AC62034FB73309A4345312AB2254AFDA4,
	BannerPlaceholder_HideBanner_mF51A34112B197F2482B2FC5A7EF6EA43C10BA8F6,
	BannerPlaceholder_BackgroundTexture_mAED97D50A7E019FD73B53CA40A57C2CB3DDB3D2C,
	BannerPlaceholder_GetBannerRect_mFBC1439AC4A275B580934C3DD8D7DE75BAD19B07,
	CoroutineExecutor__ctor_m6E3F440976148531A2C26801601B79AE0CBE17D8,
	CoroutineExecutor_Update_mFF1EF39361E7600E3C622F1D6677437D734500AA,
	UnityLifecycleManager__ctor_mCE539A0B02C434157694A631324BD519DA7D522C,
	UnityLifecycleManager_Initialize_mC1298AF398B8696F752C3B69C82AA089922DA0A3,
	UnityLifecycleManager_Post_m4012D24BC270B3C3CD3F0AE181664F1C411263C6,
	UnityLifecycleManager_Dispose_mC557F087108E69FA821C5D45683594AF411F85B7,
	NULL,
	ApplicationQuit__ctor_m7D6F9F429C9C7FC9F149F939D7BA312286E0F4C5,
	ApplicationQuit_add_OnApplicationQuitEventHandler_m4C0EA50764A840FFCEAC0F1B26B6B74F781B9B41,
	ApplicationQuit_remove_OnApplicationQuitEventHandler_mE74B8DC6642B26013B2B9EC104E86EF5D1BB9AEB,
	ApplicationQuit_OnApplicationQuit_m470F95E4EE4D9486DC5114B69C27EFECB0C34CCD,
	Json_Serialize_m68A7236E65EBD6B1AD9102B4E59C1A9D26BE26C3,
	Serializer__ctor_m5F6AB25FBE2D75ADB7E6F312834DA8BB64C99071,
	Serializer_Serialize_m6E705AA0C97D3B9B207CF0E5855D8B3A32CD8E14,
	Serializer_SerializeValue_m693E9D860C8818EAA2BD342129062FCC1E8A2CDE,
	Serializer_SerializeObject_m3C84A8E910E016AA99919EEAFB0C32ED242A5BDD,
	Serializer_SerializeArray_m9AF495B0B15492784A25B35817602D0293641212,
	Serializer_SerializeString_m4E597CF9226136E22D9AB1BF3879813B93C3C521,
	Serializer_SerializeOther_mF72BE34FE03E7BD04D5F1447254EB0011E7E655E,
	FinishEventArgs__ctor_m50A823827CD440BA8B0613C7EE3F088576653512,
	FinishEventArgs_get_showResult_m8C9B4D0595B80FC4CDAED80069D8C2760CDE82D3,
	StartEventArgs__ctor_m8ABE0DAE8061CB485842A0CD9248DE8EDA5A4940,
};
static const int32_t s_InvokerIndices[284] = 
{
	14,
	14,
	14,
	14,
	14,
	163,
	23,
	101,
	26,
	26,
	14,
	26,
	27,
	14,
	27,
	31,
	32,
	27,
	27,
	27,
	27,
	27,
	26,
	27,
	31,
	32,
	26,
	26,
	26,
	124,
	14,
	14,
	163,
	23,
	101,
	26,
	163,
	26,
	166,
	26,
	27,
	14,
	27,
	31,
	32,
	27,
	27,
	27,
	27,
	27,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	3,
	49,
	547,
	1348,
	109,
	111,
	111,
	4,
	111,
	122,
	766,
	121,
	109,
	109,
	4,
	4,
	3,
	23,
	4,
	111,
	1597,
	111,
	111,
	111,
	111,
	111,
	3,
	3,
	3,
	23,
	163,
	26,
	166,
	26,
	163,
	23,
	101,
	26,
	163,
	23,
	101,
	26,
	163,
	23,
	101,
	26,
	14,
	102,
	721,
	27,
	26,
	9,
	26,
	26,
	26,
	124,
	156,
	26,
	26,
	26,
	26,
	14,
	14,
	14,
	102,
	102,
	31,
	14,
	14,
	721,
	27,
	26,
	9,
	26,
	26,
	26,
	26,
	124,
	0,
	27,
	27,
	23,
	23,
	27,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	26,
	721,
	26,
	26,
	14,
	102,
	9,
	23,
	26,
	721,
	26,
	26,
	14,
	102,
	9,
	23,
	26,
	27,
	31,
	32,
	23,
	547,
	766,
	121,
	111,
	111,
	111,
	111,
	111,
	111,
	3,
	111,
	111,
	111,
	111,
	111,
	111,
	26,
	27,
	31,
	32,
	163,
	26,
	166,
	26,
	163,
	26,
	166,
	26,
	163,
	26,
	166,
	26,
	163,
	26,
	166,
	26,
	163,
	26,
	166,
	26,
	163,
	26,
	166,
	26,
	23,
	1348,
	111,
	109,
	4,
	49,
	122,
	111,
	111,
	111,
	111,
	111,
	1597,
	111,
	108,
	26,
	721,
	26,
	26,
	14,
	102,
	9,
	163,
	26,
	166,
	26,
	163,
	1598,
	1599,
	26,
	163,
	26,
	166,
	26,
	163,
	129,
	1600,
	26,
	23,
	23,
	23,
	62,
	23,
	1601,
	1246,
	23,
	23,
	23,
	23,
	26,
	23,
	26,
	23,
	26,
	26,
	23,
	0,
	23,
	0,
	26,
	26,
	26,
	26,
	26,
	124,
	10,
	26,
};
static const Il2CppTokenIndexMethodTuple s_reversePInvokeIndices[14] = 
{
	{ 0x06000056, 11,  (void**)&PurchasingPlatform_UnityAdsDidInitiatePurchasingCommand_mE239DF35A9FA1DC1A39FC719A7BBE3DE7944AFD3_RuntimeMethod_var, 0 },
	{ 0x06000057, 12,  (void**)&PurchasingPlatform_UnityAdsPurchasingGetProductCatalog_m8D60D398C4FEB99B98E3E9E155F9C7F215B32CA4_RuntimeMethod_var, 0 },
	{ 0x06000058, 13,  (void**)&PurchasingPlatform_UnityAdsPurchasingGetPurchasingVersion_mF1D69129A470B6044F8FDBDBC3DF07BA13CB371C_RuntimeMethod_var, 0 },
	{ 0x06000059, 14,  (void**)&PurchasingPlatform_UnityAdsPurchasingInitialize_m1388AD424E6D90AC991C7556C7CF74950173A0DE_RuntimeMethod_var, 0 },
	{ 0x060000B8, 1,  (void**)&IosBanner_UnityAdsBannerDidShow_m479FF8DFCC5FF717DD0C697293AA0AE3344A5BAC_RuntimeMethod_var, 0 },
	{ 0x060000B9, 2,  (void**)&IosBanner_UnityAdsBannerDidHide_m962A229232E642CBE004986D344E7E10003FC677_RuntimeMethod_var, 0 },
	{ 0x060000BA, 3,  (void**)&IosBanner_UnityAdsBannerClick_m341C27892A0477BE144DBA166127267951B01C97_RuntimeMethod_var, 0 },
	{ 0x060000BB, 4,  (void**)&IosBanner_UnityAdsBannerDidError_m225A971BCDD9E56C1F883B1C0D4A058ABD3C88D4_RuntimeMethod_var, 0 },
	{ 0x060000BC, 5,  (void**)&IosBanner_UnityAdsBannerDidUnload_m211228A6BA7CE8E28195354887A59605DFA5B55F_RuntimeMethod_var, 0 },
	{ 0x060000BD, 6,  (void**)&IosBanner_UnityAdsBannerDidLoad_mBA64C7497389CEAF35DE3ACE131D6AA95A8EE6D5_RuntimeMethod_var, 0 },
	{ 0x060000E5, 7,  (void**)&IosPlatform_UnityAdsReady_m319BB195D43D7FC9155FB331FFD50D44C12238F6_RuntimeMethod_var, 0 },
	{ 0x060000E6, 8,  (void**)&IosPlatform_UnityAdsDidError_m09DDB9048279569D3A5CA00BC8F25F8C20FCE61D_RuntimeMethod_var, 0 },
	{ 0x060000E7, 9,  (void**)&IosPlatform_UnityAdsDidStart_m4819019842B1C7483EDF5614FAC5A00B25F4E0FE_RuntimeMethod_var, 0 },
	{ 0x060000E8, 10,  (void**)&IosPlatform_UnityAdsDidFinish_m485AA4E38648E5DCB1A62345997336849D029C1B_RuntimeMethod_var, 0 },
};
extern const Il2CppCodeGenModule g_UnityEngine_Advertisements_iOSCodeGenModule;
const Il2CppCodeGenModule g_UnityEngine_Advertisements_iOSCodeGenModule = 
{
	"UnityEngine.Advertisements.iOS.dll",
	284,
	s_methodPointers,
	s_InvokerIndices,
	14,
	s_reversePInvokeIndices,
	0,
	NULL,
	0,
	NULL,
	NULL,
};
