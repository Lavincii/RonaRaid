﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"





IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 System.String UnityEngineInternal.WebRequestUtils::RedirectTo(System.String,System.String)
extern void WebRequestUtils_RedirectTo_m8AC7C0BFC562550118F6FF4AE218898717E922C1 ();
// 0x00000002 System.Void UnityEngineInternal.WebRequestUtils::.cctor()
extern void WebRequestUtils__cctor_m31EB3E45EC49AB6B33C7A10F79F1CD4FF2BE715A ();
// 0x00000003 System.Boolean UnityEngine.Networking.CertificateHandler::ValidateCertificate(System.Byte[])
extern void CertificateHandler_ValidateCertificate_m10584FA8D39D238AA435AB440279D3943273817D ();
// 0x00000004 System.Boolean UnityEngine.Networking.CertificateHandler::ValidateCertificateNative(System.Byte[])
extern void CertificateHandler_ValidateCertificateNative_mE500FAB5B59229D61E85A5DC0E28A0F583679170 ();
static Il2CppMethodPointer s_methodPointers[4] = 
{
	WebRequestUtils_RedirectTo_m8AC7C0BFC562550118F6FF4AE218898717E922C1,
	WebRequestUtils__cctor_m31EB3E45EC49AB6B33C7A10F79F1CD4FF2BE715A,
	CertificateHandler_ValidateCertificate_m10584FA8D39D238AA435AB440279D3943273817D,
	CertificateHandler_ValidateCertificateNative_mE500FAB5B59229D61E85A5DC0E28A0F583679170,
};
static const int32_t s_InvokerIndices[4] = 
{
	1,
	3,
	9,
	9,
};
extern const Il2CppCodeGenModule g_UnityEngine_UnityWebRequestModuleCodeGenModule;
const Il2CppCodeGenModule g_UnityEngine_UnityWebRequestModuleCodeGenModule = 
{
	"UnityEngine.UnityWebRequestModule.dll",
	4,
	s_methodPointers,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
};
