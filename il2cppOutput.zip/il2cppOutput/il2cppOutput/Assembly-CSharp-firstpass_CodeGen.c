﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"





IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 System.Void TestAnimations::Update()
extern void TestAnimations_Update_m13E59AB2D132C422A2FB10C4DBBB0FE0EBFC2C58 ();
// 0x00000002 System.Void TestAnimations::.ctor()
extern void TestAnimations__ctor_m209959676C951161D54BE378FDA95CC1130FF276 ();
// 0x00000003 System.Void UnityStandardAssets.CrossPlatformInput.AxisTouchButton::OnEnable()
extern void AxisTouchButton_OnEnable_mCB6F2E22CE0ED2867462D2B6477319CA34EC6923 ();
// 0x00000004 System.Void UnityStandardAssets.CrossPlatformInput.AxisTouchButton::FindPairedButton()
extern void AxisTouchButton_FindPairedButton_m40E5A08627D81FC2C9B18410E0A315A00AFB8E5E ();
// 0x00000005 System.Void UnityStandardAssets.CrossPlatformInput.AxisTouchButton::OnDisable()
extern void AxisTouchButton_OnDisable_mA60CC8A5ACA0AF8EA245F67C774CC15489D26F0D ();
// 0x00000006 System.Void UnityStandardAssets.CrossPlatformInput.AxisTouchButton::OnPointerDown(UnityEngine.EventSystems.PointerEventData)
extern void AxisTouchButton_OnPointerDown_mF8ED454A7629EC10D5D65B0806B1575B969CC151 ();
// 0x00000007 System.Void UnityStandardAssets.CrossPlatformInput.AxisTouchButton::OnPointerUp(UnityEngine.EventSystems.PointerEventData)
extern void AxisTouchButton_OnPointerUp_m47ACA384B0AB0496024E2BA07670DE7F416442A6 ();
// 0x00000008 System.Void UnityStandardAssets.CrossPlatformInput.AxisTouchButton::.ctor()
extern void AxisTouchButton__ctor_m92FC868F9C30069B6E82AEFB601E72D7958146EB ();
// 0x00000009 System.Void UnityStandardAssets.CrossPlatformInput.ButtonHandler::OnEnable()
extern void ButtonHandler_OnEnable_mF4257EC750A191164B42AA7ED19E95221E0C9084 ();
// 0x0000000A System.Void UnityStandardAssets.CrossPlatformInput.ButtonHandler::SetDownState()
extern void ButtonHandler_SetDownState_m22A563B85C0CFC7883586FE49D47EC8F4795740E ();
// 0x0000000B System.Void UnityStandardAssets.CrossPlatformInput.ButtonHandler::SetUpState()
extern void ButtonHandler_SetUpState_m20D0A07A6047D866EB95EB5D32D6D5C208CF779D ();
// 0x0000000C System.Void UnityStandardAssets.CrossPlatformInput.ButtonHandler::SetAxisPositiveState()
extern void ButtonHandler_SetAxisPositiveState_m2914614CA82F6CE2BCDEF41198D6505C08692F60 ();
// 0x0000000D System.Void UnityStandardAssets.CrossPlatformInput.ButtonHandler::SetAxisNeutralState()
extern void ButtonHandler_SetAxisNeutralState_m710F8A130253345840FC6A942453EBD386322691 ();
// 0x0000000E System.Void UnityStandardAssets.CrossPlatformInput.ButtonHandler::SetAxisNegativeState()
extern void ButtonHandler_SetAxisNegativeState_m57D4FA1CCB8E9F4CCB3D5AB589D57328EBDA782C ();
// 0x0000000F System.Void UnityStandardAssets.CrossPlatformInput.ButtonHandler::Update()
extern void ButtonHandler_Update_m84201A612F81A8C08E1E4F78635C47098A9C6BC0 ();
// 0x00000010 System.Void UnityStandardAssets.CrossPlatformInput.ButtonHandler::.ctor()
extern void ButtonHandler__ctor_m85B4D66D1CA83E5A73BFC70CAFB4F2D00F559795 ();
// 0x00000011 System.Void UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager::.cctor()
extern void CrossPlatformInputManager__cctor_m62BA59D81597A25895815DDB40DD8944A6B804F2 ();
// 0x00000012 System.Void UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager::SwitchActiveInputMethod(UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager_ActiveInputMethod)
extern void CrossPlatformInputManager_SwitchActiveInputMethod_m3BAB791534CAB7AA957901F370FE854C63AB1801 ();
// 0x00000013 System.Boolean UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager::AxisExists(System.String)
extern void CrossPlatformInputManager_AxisExists_m13A4ED5F88BAC335FDC42ADD4AAC9BB4CC5809F9 ();
// 0x00000014 System.Boolean UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager::ButtonExists(System.String)
extern void CrossPlatformInputManager_ButtonExists_m6C0E094AF61CF2F0F6592EFA67763D208C867440 ();
// 0x00000015 System.Void UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager::RegisterVirtualAxis(UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager_VirtualAxis)
extern void CrossPlatformInputManager_RegisterVirtualAxis_m84945297F5E2C4D218B59B76E9D90D3BD36198A4 ();
// 0x00000016 System.Void UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager::RegisterVirtualButton(UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager_VirtualButton)
extern void CrossPlatformInputManager_RegisterVirtualButton_mA5218520E9EE798325C72DFD0C988DC313D36BCF ();
// 0x00000017 System.Void UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager::UnRegisterVirtualAxis(System.String)
extern void CrossPlatformInputManager_UnRegisterVirtualAxis_m33DCEB8DAAF2703BFAB8F156A6633C0F4316C1A4 ();
// 0x00000018 System.Void UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager::UnRegisterVirtualButton(System.String)
extern void CrossPlatformInputManager_UnRegisterVirtualButton_m4B8F22F23F0891C1F5D4C07B729564D6A95CB82D ();
// 0x00000019 UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager_VirtualAxis UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager::VirtualAxisReference(System.String)
extern void CrossPlatformInputManager_VirtualAxisReference_m5864A44C3FE72270B22D4C97FADEEB2AAA77869D ();
// 0x0000001A System.Single UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager::GetAxis(System.String)
extern void CrossPlatformInputManager_GetAxis_m4D45F9BE30A159DA4E72F4BF8294872297566E2D ();
// 0x0000001B System.Single UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager::GetAxisRaw(System.String)
extern void CrossPlatformInputManager_GetAxisRaw_mE6D8754EAE5F6838CCF172FB03F4C251648EE987 ();
// 0x0000001C System.Single UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager::GetAxis(System.String,System.Boolean)
extern void CrossPlatformInputManager_GetAxis_mC9F177F6F0D83131B599CF80C3F3A8D7AD4568A0 ();
// 0x0000001D System.Boolean UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager::GetButton(System.String)
extern void CrossPlatformInputManager_GetButton_m728A64B9BC3F6471EB11B9CAF54BD4A10C710207 ();
// 0x0000001E System.Boolean UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager::GetButtonDown(System.String)
extern void CrossPlatformInputManager_GetButtonDown_mE1BCD85447E0EF510728E49314FBCCEEE1FC7E8D ();
// 0x0000001F System.Boolean UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager::GetButtonUp(System.String)
extern void CrossPlatformInputManager_GetButtonUp_mD115A6BD45062A08A42EBBC7F0C9EC0D4F764ADD ();
// 0x00000020 System.Void UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager::SetButtonDown(System.String)
extern void CrossPlatformInputManager_SetButtonDown_m4DBFE81592B86D460ACC34D5936C788CD5B50890 ();
// 0x00000021 System.Void UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager::SetButtonUp(System.String)
extern void CrossPlatformInputManager_SetButtonUp_m6228A0BD77568A903DF6429EEACD2267028FA32A ();
// 0x00000022 System.Void UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager::SetAxisPositive(System.String)
extern void CrossPlatformInputManager_SetAxisPositive_mC5C7F88EEF5D6CB7B6B91BF6279FA53A94B4D527 ();
// 0x00000023 System.Void UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager::SetAxisNegative(System.String)
extern void CrossPlatformInputManager_SetAxisNegative_m41A74CBE51E8CB4870C79A8343E66B99B2CA7FDB ();
// 0x00000024 System.Void UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager::SetAxisZero(System.String)
extern void CrossPlatformInputManager_SetAxisZero_mBBD24590C97037F84384A559AAE37D2F8CA51730 ();
// 0x00000025 System.Void UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager::SetAxis(System.String,System.Single)
extern void CrossPlatformInputManager_SetAxis_m6BCE358D3D1A2E5E393AF281602B3E4745C0C5DA ();
// 0x00000026 UnityEngine.Vector3 UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager::get_mousePosition()
extern void CrossPlatformInputManager_get_mousePosition_mC886FC2F654E91F06407FDB891DF3201ED576DCD ();
// 0x00000027 System.Void UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager::SetVirtualMousePositionX(System.Single)
extern void CrossPlatformInputManager_SetVirtualMousePositionX_m1800042FCD90010EA2E2D51969D971324DD11964 ();
// 0x00000028 System.Void UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager::SetVirtualMousePositionY(System.Single)
extern void CrossPlatformInputManager_SetVirtualMousePositionY_mDD4A2DF42E6CD673054A91FFE3C7FA61812889A8 ();
// 0x00000029 System.Void UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager::SetVirtualMousePositionZ(System.Single)
extern void CrossPlatformInputManager_SetVirtualMousePositionZ_m121058A0846AE6A974855607C8E3D46C221B376F ();
// 0x0000002A System.Void UnityStandardAssets.CrossPlatformInput.InputAxisScrollbar::Update()
extern void InputAxisScrollbar_Update_m4B6A6BBF4FAED786086BE4F9997E1D2D373BF2FE ();
// 0x0000002B System.Void UnityStandardAssets.CrossPlatformInput.InputAxisScrollbar::HandleInput(System.Single)
extern void InputAxisScrollbar_HandleInput_mF3A427E653ED917C3E91E0CBB1A3990F6110FB11 ();
// 0x0000002C System.Void UnityStandardAssets.CrossPlatformInput.InputAxisScrollbar::.ctor()
extern void InputAxisScrollbar__ctor_mB96FAA176CD2958CCDE6E5F9212DCF2082486243 ();
// 0x0000002D System.Void UnityStandardAssets.CrossPlatformInput.Joystick::OnEnable()
extern void Joystick_OnEnable_m8728113F5BEE6D91514CB1A07550E8E7A3856CEE ();
// 0x0000002E System.Void UnityStandardAssets.CrossPlatformInput.Joystick::Start()
extern void Joystick_Start_m6164BF9BB7A0A8DD4524223639EA549E0491CFFD ();
// 0x0000002F System.Void UnityStandardAssets.CrossPlatformInput.Joystick::UpdateVirtualAxes(UnityEngine.Vector3)
extern void Joystick_UpdateVirtualAxes_m5B79E0FBC765F85D9EE7FA9C7D74BDB35F326F3E ();
// 0x00000030 System.Void UnityStandardAssets.CrossPlatformInput.Joystick::CreateVirtualAxes()
extern void Joystick_CreateVirtualAxes_mCD13DFD2ADED0444F18C3856FD67A78539FD9C2C ();
// 0x00000031 System.Void UnityStandardAssets.CrossPlatformInput.Joystick::OnDrag(UnityEngine.EventSystems.PointerEventData)
extern void Joystick_OnDrag_m1DC1103944EB982931C5946BD8EBFB8E63073BB6 ();
// 0x00000032 System.Void UnityStandardAssets.CrossPlatformInput.Joystick::OnPointerUp(UnityEngine.EventSystems.PointerEventData)
extern void Joystick_OnPointerUp_m06850F5D6C95D16DEB57B3FC4E50CCBCCD0EF7FB ();
// 0x00000033 System.Void UnityStandardAssets.CrossPlatformInput.Joystick::OnPointerDown(UnityEngine.EventSystems.PointerEventData)
extern void Joystick_OnPointerDown_m1F10B670117FD67A734079ED71D4A3D36B783718 ();
// 0x00000034 System.Void UnityStandardAssets.CrossPlatformInput.Joystick::OnDisable()
extern void Joystick_OnDisable_m5097E08289FECC9A5499DB0747575F075353CAFB ();
// 0x00000035 System.Void UnityStandardAssets.CrossPlatformInput.Joystick::.ctor()
extern void Joystick__ctor_mA2C408B1EB0671CB8B340DBF932CB4153BAC3ABF ();
// 0x00000036 System.Void UnityStandardAssets.CrossPlatformInput.MobileControlRig::OnEnable()
extern void MobileControlRig_OnEnable_mAF3C7A8C67CE239A1FD5E6A8B224F7A91DE8B2E8 ();
// 0x00000037 System.Void UnityStandardAssets.CrossPlatformInput.MobileControlRig::Start()
extern void MobileControlRig_Start_m43792FB70FC02989DA9543801183A54005AD572B ();
// 0x00000038 System.Void UnityStandardAssets.CrossPlatformInput.MobileControlRig::CheckEnableControlRig()
extern void MobileControlRig_CheckEnableControlRig_m59A8FCD09B2A6EA7702AE9EBB24E3BB9605B5CCD ();
// 0x00000039 System.Void UnityStandardAssets.CrossPlatformInput.MobileControlRig::EnableControlRig(System.Boolean)
extern void MobileControlRig_EnableControlRig_m694051D1F28B05510357A3F96561EAF2732CAF8E ();
// 0x0000003A System.Void UnityStandardAssets.CrossPlatformInput.MobileControlRig::.ctor()
extern void MobileControlRig__ctor_mCCFD8CBDA57F8D9B0E2805D4740637F5FFC4B120 ();
// 0x0000003B System.Void UnityStandardAssets.CrossPlatformInput.TiltInput::OnEnable()
extern void TiltInput_OnEnable_mEACF194C56E3620055240D9D46880E6F9C201E9C ();
// 0x0000003C System.Void UnityStandardAssets.CrossPlatformInput.TiltInput::Update()
extern void TiltInput_Update_m14D22BD1D9D47DF03965F0F6BBC2FB0E322F2B2A ();
// 0x0000003D System.Void UnityStandardAssets.CrossPlatformInput.TiltInput::OnDisable()
extern void TiltInput_OnDisable_m169AFDCFFA0609747DA889DF88C86D0A5C9C42B0 ();
// 0x0000003E System.Void UnityStandardAssets.CrossPlatformInput.TiltInput::.ctor()
extern void TiltInput__ctor_m909CBEC7014B584CB5EBF5A0B650E5D8845E4FB7 ();
// 0x0000003F System.Void UnityStandardAssets.CrossPlatformInput.TouchPad::OnEnable()
extern void TouchPad_OnEnable_mFED012C0FDD349798B1296799C0AE7A05C2017EE ();
// 0x00000040 System.Void UnityStandardAssets.CrossPlatformInput.TouchPad::Start()
extern void TouchPad_Start_m986951F12FF80D3A0D4B0DCB49D9FBA13B8A025C ();
// 0x00000041 System.Void UnityStandardAssets.CrossPlatformInput.TouchPad::CreateVirtualAxes()
extern void TouchPad_CreateVirtualAxes_m214CE099E087A7A6FCDDF3B2740983436B62BA5E ();
// 0x00000042 System.Void UnityStandardAssets.CrossPlatformInput.TouchPad::UpdateVirtualAxes(UnityEngine.Vector3)
extern void TouchPad_UpdateVirtualAxes_m42D25C5EE9F890FECF580C97219455E73D09AF67 ();
// 0x00000043 System.Void UnityStandardAssets.CrossPlatformInput.TouchPad::OnPointerDown(UnityEngine.EventSystems.PointerEventData)
extern void TouchPad_OnPointerDown_m13FDEACD95785D853D85B68E4993AC520A2D771F ();
// 0x00000044 System.Void UnityStandardAssets.CrossPlatformInput.TouchPad::Update()
extern void TouchPad_Update_m0DD077DCE945CC47C3DD4FFDB9FEC5D4BB3A762A ();
// 0x00000045 System.Void UnityStandardAssets.CrossPlatformInput.TouchPad::OnPointerUp(UnityEngine.EventSystems.PointerEventData)
extern void TouchPad_OnPointerUp_mE35C9A5F6CD1909E8819F4D6D7282C7D20B37B88 ();
// 0x00000046 System.Void UnityStandardAssets.CrossPlatformInput.TouchPad::OnDisable()
extern void TouchPad_OnDisable_mD0E67236EB0D365E3397D26723250C01614168B5 ();
// 0x00000047 System.Void UnityStandardAssets.CrossPlatformInput.TouchPad::.ctor()
extern void TouchPad__ctor_m9FEC2CD43CD850304B41B1C0142CC47F44B01E25 ();
// 0x00000048 UnityEngine.Vector3 UnityStandardAssets.CrossPlatformInput.VirtualInput::get_virtualMousePosition()
extern void VirtualInput_get_virtualMousePosition_m897C50683722D1C3DF4FA9801524E7BF310B24BD ();
// 0x00000049 System.Void UnityStandardAssets.CrossPlatformInput.VirtualInput::set_virtualMousePosition(UnityEngine.Vector3)
extern void VirtualInput_set_virtualMousePosition_mDDF9F35B2C4AC37AB6CCF68772C57315612B1F75 ();
// 0x0000004A System.Boolean UnityStandardAssets.CrossPlatformInput.VirtualInput::AxisExists(System.String)
extern void VirtualInput_AxisExists_mDB6E7D0AF32ECE3E3CB1C4DA089D4B030D61F3F8 ();
// 0x0000004B System.Boolean UnityStandardAssets.CrossPlatformInput.VirtualInput::ButtonExists(System.String)
extern void VirtualInput_ButtonExists_mBD9401EC2186C54F8EA7577FEEA500624F2E6083 ();
// 0x0000004C System.Void UnityStandardAssets.CrossPlatformInput.VirtualInput::RegisterVirtualAxis(UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager_VirtualAxis)
extern void VirtualInput_RegisterVirtualAxis_m43BC4BC9355B708CC739E3F2D0761A49342BC60F ();
// 0x0000004D System.Void UnityStandardAssets.CrossPlatformInput.VirtualInput::RegisterVirtualButton(UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager_VirtualButton)
extern void VirtualInput_RegisterVirtualButton_mF6874262B94F78D0C2C166F7E20CFA47DD39BF41 ();
// 0x0000004E System.Void UnityStandardAssets.CrossPlatformInput.VirtualInput::UnRegisterVirtualAxis(System.String)
extern void VirtualInput_UnRegisterVirtualAxis_mD3511EE52A02EF720B086FF6EDCF9D4FA11A551F ();
// 0x0000004F System.Void UnityStandardAssets.CrossPlatformInput.VirtualInput::UnRegisterVirtualButton(System.String)
extern void VirtualInput_UnRegisterVirtualButton_mF05E241BD753B335E97CB8D1EDCFECE82A34F554 ();
// 0x00000050 UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager_VirtualAxis UnityStandardAssets.CrossPlatformInput.VirtualInput::VirtualAxisReference(System.String)
extern void VirtualInput_VirtualAxisReference_m5AE323533C7DF65D71B551B173A63680BB5850EA ();
// 0x00000051 System.Void UnityStandardAssets.CrossPlatformInput.VirtualInput::SetVirtualMousePositionX(System.Single)
extern void VirtualInput_SetVirtualMousePositionX_m49716B45CE295686844FDD803083136B9BAC2124 ();
// 0x00000052 System.Void UnityStandardAssets.CrossPlatformInput.VirtualInput::SetVirtualMousePositionY(System.Single)
extern void VirtualInput_SetVirtualMousePositionY_m80139449D4E09227D929E314419B1C72D57BD001 ();
// 0x00000053 System.Void UnityStandardAssets.CrossPlatformInput.VirtualInput::SetVirtualMousePositionZ(System.Single)
extern void VirtualInput_SetVirtualMousePositionZ_m9276A4D39BC31E00C1977B2621549B1C1F40E51D ();
// 0x00000054 System.Single UnityStandardAssets.CrossPlatformInput.VirtualInput::GetAxis(System.String,System.Boolean)
// 0x00000055 System.Boolean UnityStandardAssets.CrossPlatformInput.VirtualInput::GetButton(System.String)
// 0x00000056 System.Boolean UnityStandardAssets.CrossPlatformInput.VirtualInput::GetButtonDown(System.String)
// 0x00000057 System.Boolean UnityStandardAssets.CrossPlatformInput.VirtualInput::GetButtonUp(System.String)
// 0x00000058 System.Void UnityStandardAssets.CrossPlatformInput.VirtualInput::SetButtonDown(System.String)
// 0x00000059 System.Void UnityStandardAssets.CrossPlatformInput.VirtualInput::SetButtonUp(System.String)
// 0x0000005A System.Void UnityStandardAssets.CrossPlatformInput.VirtualInput::SetAxisPositive(System.String)
// 0x0000005B System.Void UnityStandardAssets.CrossPlatformInput.VirtualInput::SetAxisNegative(System.String)
// 0x0000005C System.Void UnityStandardAssets.CrossPlatformInput.VirtualInput::SetAxisZero(System.String)
// 0x0000005D System.Void UnityStandardAssets.CrossPlatformInput.VirtualInput::SetAxis(System.String,System.Single)
// 0x0000005E UnityEngine.Vector3 UnityStandardAssets.CrossPlatformInput.VirtualInput::MousePosition()
// 0x0000005F System.Void UnityStandardAssets.CrossPlatformInput.VirtualInput::.ctor()
extern void VirtualInput__ctor_mD6A4228D372182ABC7372ED25F4987CE1EAA27CB ();
// 0x00000060 System.Void UnityStandardAssets.CrossPlatformInput.PlatformSpecific.MobileInput::AddButton(System.String)
extern void MobileInput_AddButton_m55B4ECB00F31F0904145B5DC71AE2B7289960F34 ();
// 0x00000061 System.Void UnityStandardAssets.CrossPlatformInput.PlatformSpecific.MobileInput::AddAxes(System.String)
extern void MobileInput_AddAxes_mF5065897FC94197F4FD5BDD15A394E858218496E ();
// 0x00000062 System.Single UnityStandardAssets.CrossPlatformInput.PlatformSpecific.MobileInput::GetAxis(System.String,System.Boolean)
extern void MobileInput_GetAxis_m24CDEC7DA08736467196B8F90F19B3110782421A ();
// 0x00000063 System.Void UnityStandardAssets.CrossPlatformInput.PlatformSpecific.MobileInput::SetButtonDown(System.String)
extern void MobileInput_SetButtonDown_mF3C9EEAF5750B7CF53C0D6D04D035CA8F1D27547 ();
// 0x00000064 System.Void UnityStandardAssets.CrossPlatformInput.PlatformSpecific.MobileInput::SetButtonUp(System.String)
extern void MobileInput_SetButtonUp_m0CEDEA05459505931FB2686C20AC0900A4941448 ();
// 0x00000065 System.Void UnityStandardAssets.CrossPlatformInput.PlatformSpecific.MobileInput::SetAxisPositive(System.String)
extern void MobileInput_SetAxisPositive_mD4522AE0A5CFA591D720C9FA1E42D38485F66C9A ();
// 0x00000066 System.Void UnityStandardAssets.CrossPlatformInput.PlatformSpecific.MobileInput::SetAxisNegative(System.String)
extern void MobileInput_SetAxisNegative_mDB7F89D127295F2D4CC4764EB04571D9A46774C4 ();
// 0x00000067 System.Void UnityStandardAssets.CrossPlatformInput.PlatformSpecific.MobileInput::SetAxisZero(System.String)
extern void MobileInput_SetAxisZero_mCE681BFD720000CFA939C78B0EAEFCA3D5748BA8 ();
// 0x00000068 System.Void UnityStandardAssets.CrossPlatformInput.PlatformSpecific.MobileInput::SetAxis(System.String,System.Single)
extern void MobileInput_SetAxis_m40791B9F5D8B28086FEA1030918A6DDBD96D2704 ();
// 0x00000069 System.Boolean UnityStandardAssets.CrossPlatformInput.PlatformSpecific.MobileInput::GetButtonDown(System.String)
extern void MobileInput_GetButtonDown_m8B7EC91AD10FF37A6910CC3AD684572F8CC4A403 ();
// 0x0000006A System.Boolean UnityStandardAssets.CrossPlatformInput.PlatformSpecific.MobileInput::GetButtonUp(System.String)
extern void MobileInput_GetButtonUp_mFB0BF6CE172238F3AF6B28CB16A73B5A0D714ABB ();
// 0x0000006B System.Boolean UnityStandardAssets.CrossPlatformInput.PlatformSpecific.MobileInput::GetButton(System.String)
extern void MobileInput_GetButton_m1805C5AAFEA6C56E1F083C318C7D8A56414742DC ();
// 0x0000006C UnityEngine.Vector3 UnityStandardAssets.CrossPlatformInput.PlatformSpecific.MobileInput::MousePosition()
extern void MobileInput_MousePosition_m655B9F793060E92EEAFC358ED5A612124F71B234 ();
// 0x0000006D System.Void UnityStandardAssets.CrossPlatformInput.PlatformSpecific.MobileInput::.ctor()
extern void MobileInput__ctor_m58D4C2380917920DD39E646CB4717F6EFBAA16F0 ();
// 0x0000006E System.Single UnityStandardAssets.CrossPlatformInput.PlatformSpecific.StandaloneInput::GetAxis(System.String,System.Boolean)
extern void StandaloneInput_GetAxis_m208A36BD2256D5439E8BF99DFEE7C4FBE5C321DB ();
// 0x0000006F System.Boolean UnityStandardAssets.CrossPlatformInput.PlatformSpecific.StandaloneInput::GetButton(System.String)
extern void StandaloneInput_GetButton_m2156BA026DDB9F6FA9F45BBC8FEC871A3090629C ();
// 0x00000070 System.Boolean UnityStandardAssets.CrossPlatformInput.PlatformSpecific.StandaloneInput::GetButtonDown(System.String)
extern void StandaloneInput_GetButtonDown_m3F88DFF900E2AB8729E6F63694BE3C8E2C19BBB7 ();
// 0x00000071 System.Boolean UnityStandardAssets.CrossPlatformInput.PlatformSpecific.StandaloneInput::GetButtonUp(System.String)
extern void StandaloneInput_GetButtonUp_mDF55E35A4B50D58901CEEF8DAEECD050A636398C ();
// 0x00000072 System.Void UnityStandardAssets.CrossPlatformInput.PlatformSpecific.StandaloneInput::SetButtonDown(System.String)
extern void StandaloneInput_SetButtonDown_m5C1B0E5ED19F91DAEE8A23108865EBC57EB3F002 ();
// 0x00000073 System.Void UnityStandardAssets.CrossPlatformInput.PlatformSpecific.StandaloneInput::SetButtonUp(System.String)
extern void StandaloneInput_SetButtonUp_m23ECA36E7E2C9D79650FC93764E2FB47C52A6269 ();
// 0x00000074 System.Void UnityStandardAssets.CrossPlatformInput.PlatformSpecific.StandaloneInput::SetAxisPositive(System.String)
extern void StandaloneInput_SetAxisPositive_m45ABA3A91481B6B07E37A24322C345DE4341472D ();
// 0x00000075 System.Void UnityStandardAssets.CrossPlatformInput.PlatformSpecific.StandaloneInput::SetAxisNegative(System.String)
extern void StandaloneInput_SetAxisNegative_m8ABB3422B35FA3D5EFEC9A3BCCE7D813C91E1DDA ();
// 0x00000076 System.Void UnityStandardAssets.CrossPlatformInput.PlatformSpecific.StandaloneInput::SetAxisZero(System.String)
extern void StandaloneInput_SetAxisZero_mC0123C06F1DD19FF6DB9353DF0D711554B56B428 ();
// 0x00000077 System.Void UnityStandardAssets.CrossPlatformInput.PlatformSpecific.StandaloneInput::SetAxis(System.String,System.Single)
extern void StandaloneInput_SetAxis_m620AB31F30F82FDB44EB995E494F618D8C42F765 ();
// 0x00000078 UnityEngine.Vector3 UnityStandardAssets.CrossPlatformInput.PlatformSpecific.StandaloneInput::MousePosition()
extern void StandaloneInput_MousePosition_m7D158ACA958E8C1101AFF4B3282E12B1A6EF7C82 ();
// 0x00000079 System.Void UnityStandardAssets.CrossPlatformInput.PlatformSpecific.StandaloneInput::.ctor()
extern void StandaloneInput__ctor_m9D98FDF717857FB17019872D7A8446C224C493F3 ();
// 0x0000007A System.String UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager_VirtualAxis::get_name()
extern void VirtualAxis_get_name_mC3959CD36494EE1B06CAEA1675DD19E5FFCB9BD9 ();
// 0x0000007B System.Void UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager_VirtualAxis::set_name(System.String)
extern void VirtualAxis_set_name_m2A44E0BF21BB426C9A14AB057D5EF41616B76096 ();
// 0x0000007C System.Boolean UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager_VirtualAxis::get_matchWithInputManager()
extern void VirtualAxis_get_matchWithInputManager_m2F68784B6C454EB26934401303E28C159980F315 ();
// 0x0000007D System.Void UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager_VirtualAxis::set_matchWithInputManager(System.Boolean)
extern void VirtualAxis_set_matchWithInputManager_m326813FB9C39A5D63C98D4AE931384D6B67AE944 ();
// 0x0000007E System.Void UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager_VirtualAxis::.ctor(System.String)
extern void VirtualAxis__ctor_m9B094B00B2F0F1C6C474D3DA51419F4549540E53 ();
// 0x0000007F System.Void UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager_VirtualAxis::.ctor(System.String,System.Boolean)
extern void VirtualAxis__ctor_mAC45A3BC043EA253666CCDE2762DB39475FED915 ();
// 0x00000080 System.Void UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager_VirtualAxis::Remove()
extern void VirtualAxis_Remove_m0517C6C37E94CCC84337FD412982D1800E5CEFD6 ();
// 0x00000081 System.Void UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager_VirtualAxis::Update(System.Single)
extern void VirtualAxis_Update_m639BD6EC869B61C712D4519290523C61745FF6C3 ();
// 0x00000082 System.Single UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager_VirtualAxis::get_GetValue()
extern void VirtualAxis_get_GetValue_mB0D352473A7E1F6A9402335FBD18625ADFCE0A69 ();
// 0x00000083 System.Single UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager_VirtualAxis::get_GetValueRaw()
extern void VirtualAxis_get_GetValueRaw_mA75834F100AB39C130FEA7AE85677E4928E58397 ();
// 0x00000084 System.String UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager_VirtualButton::get_name()
extern void VirtualButton_get_name_m836058DAC831C5BB481A422120939EB4D14CE55B ();
// 0x00000085 System.Void UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager_VirtualButton::set_name(System.String)
extern void VirtualButton_set_name_mCC77CE771C89C23B47A2D9B027C7E754666A78A5 ();
// 0x00000086 System.Boolean UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager_VirtualButton::get_matchWithInputManager()
extern void VirtualButton_get_matchWithInputManager_mD6924A44FFCFF72519BDDEAD61E3072CC3C3FCF3 ();
// 0x00000087 System.Void UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager_VirtualButton::set_matchWithInputManager(System.Boolean)
extern void VirtualButton_set_matchWithInputManager_mD438AFD4E212727BED9ECD1F0CBFE6243112AE3D ();
// 0x00000088 System.Void UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager_VirtualButton::.ctor(System.String)
extern void VirtualButton__ctor_mECADC4A0B8ACF0954720A84061800EA0F00D9FDD ();
// 0x00000089 System.Void UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager_VirtualButton::.ctor(System.String,System.Boolean)
extern void VirtualButton__ctor_mBC57649412C90DFF3179B681B9D33BB88443FFD9 ();
// 0x0000008A System.Void UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager_VirtualButton::Pressed()
extern void VirtualButton_Pressed_m596B075C829D1E8C500AF6694155488CF2250402 ();
// 0x0000008B System.Void UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager_VirtualButton::Released()
extern void VirtualButton_Released_mC4B98C45864A5832601A90437E691119F28E25E6 ();
// 0x0000008C System.Void UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager_VirtualButton::Remove()
extern void VirtualButton_Remove_m0F66A404819C8B483DA3F02FDCEBDB005867D37D ();
// 0x0000008D System.Boolean UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager_VirtualButton::get_GetButton()
extern void VirtualButton_get_GetButton_m228F811AD3C4911C45AFEA7960E35F4A84B7A32D ();
// 0x0000008E System.Boolean UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager_VirtualButton::get_GetButtonDown()
extern void VirtualButton_get_GetButtonDown_mB6BBC9E21BB477279E5D74926CFA633E671AC430 ();
// 0x0000008F System.Boolean UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager_VirtualButton::get_GetButtonUp()
extern void VirtualButton_get_GetButtonUp_m79C31A03EE6AC926E932FA1A28989A73B0257E43 ();
// 0x00000090 System.Void UnityStandardAssets.CrossPlatformInput.TiltInput_AxisMapping::.ctor()
extern void AxisMapping__ctor_m2B8C914999C51C9568C81B4C1E6750BCAF66BE1F ();
static Il2CppMethodPointer s_methodPointers[144] = 
{
	TestAnimations_Update_m13E59AB2D132C422A2FB10C4DBBB0FE0EBFC2C58,
	TestAnimations__ctor_m209959676C951161D54BE378FDA95CC1130FF276,
	AxisTouchButton_OnEnable_mCB6F2E22CE0ED2867462D2B6477319CA34EC6923,
	AxisTouchButton_FindPairedButton_m40E5A08627D81FC2C9B18410E0A315A00AFB8E5E,
	AxisTouchButton_OnDisable_mA60CC8A5ACA0AF8EA245F67C774CC15489D26F0D,
	AxisTouchButton_OnPointerDown_mF8ED454A7629EC10D5D65B0806B1575B969CC151,
	AxisTouchButton_OnPointerUp_m47ACA384B0AB0496024E2BA07670DE7F416442A6,
	AxisTouchButton__ctor_m92FC868F9C30069B6E82AEFB601E72D7958146EB,
	ButtonHandler_OnEnable_mF4257EC750A191164B42AA7ED19E95221E0C9084,
	ButtonHandler_SetDownState_m22A563B85C0CFC7883586FE49D47EC8F4795740E,
	ButtonHandler_SetUpState_m20D0A07A6047D866EB95EB5D32D6D5C208CF779D,
	ButtonHandler_SetAxisPositiveState_m2914614CA82F6CE2BCDEF41198D6505C08692F60,
	ButtonHandler_SetAxisNeutralState_m710F8A130253345840FC6A942453EBD386322691,
	ButtonHandler_SetAxisNegativeState_m57D4FA1CCB8E9F4CCB3D5AB589D57328EBDA782C,
	ButtonHandler_Update_m84201A612F81A8C08E1E4F78635C47098A9C6BC0,
	ButtonHandler__ctor_m85B4D66D1CA83E5A73BFC70CAFB4F2D00F559795,
	CrossPlatformInputManager__cctor_m62BA59D81597A25895815DDB40DD8944A6B804F2,
	CrossPlatformInputManager_SwitchActiveInputMethod_m3BAB791534CAB7AA957901F370FE854C63AB1801,
	CrossPlatformInputManager_AxisExists_m13A4ED5F88BAC335FDC42ADD4AAC9BB4CC5809F9,
	CrossPlatformInputManager_ButtonExists_m6C0E094AF61CF2F0F6592EFA67763D208C867440,
	CrossPlatformInputManager_RegisterVirtualAxis_m84945297F5E2C4D218B59B76E9D90D3BD36198A4,
	CrossPlatformInputManager_RegisterVirtualButton_mA5218520E9EE798325C72DFD0C988DC313D36BCF,
	CrossPlatformInputManager_UnRegisterVirtualAxis_m33DCEB8DAAF2703BFAB8F156A6633C0F4316C1A4,
	CrossPlatformInputManager_UnRegisterVirtualButton_m4B8F22F23F0891C1F5D4C07B729564D6A95CB82D,
	CrossPlatformInputManager_VirtualAxisReference_m5864A44C3FE72270B22D4C97FADEEB2AAA77869D,
	CrossPlatformInputManager_GetAxis_m4D45F9BE30A159DA4E72F4BF8294872297566E2D,
	CrossPlatformInputManager_GetAxisRaw_mE6D8754EAE5F6838CCF172FB03F4C251648EE987,
	CrossPlatformInputManager_GetAxis_mC9F177F6F0D83131B599CF80C3F3A8D7AD4568A0,
	CrossPlatformInputManager_GetButton_m728A64B9BC3F6471EB11B9CAF54BD4A10C710207,
	CrossPlatformInputManager_GetButtonDown_mE1BCD85447E0EF510728E49314FBCCEEE1FC7E8D,
	CrossPlatformInputManager_GetButtonUp_mD115A6BD45062A08A42EBBC7F0C9EC0D4F764ADD,
	CrossPlatformInputManager_SetButtonDown_m4DBFE81592B86D460ACC34D5936C788CD5B50890,
	CrossPlatformInputManager_SetButtonUp_m6228A0BD77568A903DF6429EEACD2267028FA32A,
	CrossPlatformInputManager_SetAxisPositive_mC5C7F88EEF5D6CB7B6B91BF6279FA53A94B4D527,
	CrossPlatformInputManager_SetAxisNegative_m41A74CBE51E8CB4870C79A8343E66B99B2CA7FDB,
	CrossPlatformInputManager_SetAxisZero_mBBD24590C97037F84384A559AAE37D2F8CA51730,
	CrossPlatformInputManager_SetAxis_m6BCE358D3D1A2E5E393AF281602B3E4745C0C5DA,
	CrossPlatformInputManager_get_mousePosition_mC886FC2F654E91F06407FDB891DF3201ED576DCD,
	CrossPlatformInputManager_SetVirtualMousePositionX_m1800042FCD90010EA2E2D51969D971324DD11964,
	CrossPlatformInputManager_SetVirtualMousePositionY_mDD4A2DF42E6CD673054A91FFE3C7FA61812889A8,
	CrossPlatformInputManager_SetVirtualMousePositionZ_m121058A0846AE6A974855607C8E3D46C221B376F,
	InputAxisScrollbar_Update_m4B6A6BBF4FAED786086BE4F9997E1D2D373BF2FE,
	InputAxisScrollbar_HandleInput_mF3A427E653ED917C3E91E0CBB1A3990F6110FB11,
	InputAxisScrollbar__ctor_mB96FAA176CD2958CCDE6E5F9212DCF2082486243,
	Joystick_OnEnable_m8728113F5BEE6D91514CB1A07550E8E7A3856CEE,
	Joystick_Start_m6164BF9BB7A0A8DD4524223639EA549E0491CFFD,
	Joystick_UpdateVirtualAxes_m5B79E0FBC765F85D9EE7FA9C7D74BDB35F326F3E,
	Joystick_CreateVirtualAxes_mCD13DFD2ADED0444F18C3856FD67A78539FD9C2C,
	Joystick_OnDrag_m1DC1103944EB982931C5946BD8EBFB8E63073BB6,
	Joystick_OnPointerUp_m06850F5D6C95D16DEB57B3FC4E50CCBCCD0EF7FB,
	Joystick_OnPointerDown_m1F10B670117FD67A734079ED71D4A3D36B783718,
	Joystick_OnDisable_m5097E08289FECC9A5499DB0747575F075353CAFB,
	Joystick__ctor_mA2C408B1EB0671CB8B340DBF932CB4153BAC3ABF,
	MobileControlRig_OnEnable_mAF3C7A8C67CE239A1FD5E6A8B224F7A91DE8B2E8,
	MobileControlRig_Start_m43792FB70FC02989DA9543801183A54005AD572B,
	MobileControlRig_CheckEnableControlRig_m59A8FCD09B2A6EA7702AE9EBB24E3BB9605B5CCD,
	MobileControlRig_EnableControlRig_m694051D1F28B05510357A3F96561EAF2732CAF8E,
	MobileControlRig__ctor_mCCFD8CBDA57F8D9B0E2805D4740637F5FFC4B120,
	TiltInput_OnEnable_mEACF194C56E3620055240D9D46880E6F9C201E9C,
	TiltInput_Update_m14D22BD1D9D47DF03965F0F6BBC2FB0E322F2B2A,
	TiltInput_OnDisable_m169AFDCFFA0609747DA889DF88C86D0A5C9C42B0,
	TiltInput__ctor_m909CBEC7014B584CB5EBF5A0B650E5D8845E4FB7,
	TouchPad_OnEnable_mFED012C0FDD349798B1296799C0AE7A05C2017EE,
	TouchPad_Start_m986951F12FF80D3A0D4B0DCB49D9FBA13B8A025C,
	TouchPad_CreateVirtualAxes_m214CE099E087A7A6FCDDF3B2740983436B62BA5E,
	TouchPad_UpdateVirtualAxes_m42D25C5EE9F890FECF580C97219455E73D09AF67,
	TouchPad_OnPointerDown_m13FDEACD95785D853D85B68E4993AC520A2D771F,
	TouchPad_Update_m0DD077DCE945CC47C3DD4FFDB9FEC5D4BB3A762A,
	TouchPad_OnPointerUp_mE35C9A5F6CD1909E8819F4D6D7282C7D20B37B88,
	TouchPad_OnDisable_mD0E67236EB0D365E3397D26723250C01614168B5,
	TouchPad__ctor_m9FEC2CD43CD850304B41B1C0142CC47F44B01E25,
	VirtualInput_get_virtualMousePosition_m897C50683722D1C3DF4FA9801524E7BF310B24BD,
	VirtualInput_set_virtualMousePosition_mDDF9F35B2C4AC37AB6CCF68772C57315612B1F75,
	VirtualInput_AxisExists_mDB6E7D0AF32ECE3E3CB1C4DA089D4B030D61F3F8,
	VirtualInput_ButtonExists_mBD9401EC2186C54F8EA7577FEEA500624F2E6083,
	VirtualInput_RegisterVirtualAxis_m43BC4BC9355B708CC739E3F2D0761A49342BC60F,
	VirtualInput_RegisterVirtualButton_mF6874262B94F78D0C2C166F7E20CFA47DD39BF41,
	VirtualInput_UnRegisterVirtualAxis_mD3511EE52A02EF720B086FF6EDCF9D4FA11A551F,
	VirtualInput_UnRegisterVirtualButton_mF05E241BD753B335E97CB8D1EDCFECE82A34F554,
	VirtualInput_VirtualAxisReference_m5AE323533C7DF65D71B551B173A63680BB5850EA,
	VirtualInput_SetVirtualMousePositionX_m49716B45CE295686844FDD803083136B9BAC2124,
	VirtualInput_SetVirtualMousePositionY_m80139449D4E09227D929E314419B1C72D57BD001,
	VirtualInput_SetVirtualMousePositionZ_m9276A4D39BC31E00C1977B2621549B1C1F40E51D,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	VirtualInput__ctor_mD6A4228D372182ABC7372ED25F4987CE1EAA27CB,
	MobileInput_AddButton_m55B4ECB00F31F0904145B5DC71AE2B7289960F34,
	MobileInput_AddAxes_mF5065897FC94197F4FD5BDD15A394E858218496E,
	MobileInput_GetAxis_m24CDEC7DA08736467196B8F90F19B3110782421A,
	MobileInput_SetButtonDown_mF3C9EEAF5750B7CF53C0D6D04D035CA8F1D27547,
	MobileInput_SetButtonUp_m0CEDEA05459505931FB2686C20AC0900A4941448,
	MobileInput_SetAxisPositive_mD4522AE0A5CFA591D720C9FA1E42D38485F66C9A,
	MobileInput_SetAxisNegative_mDB7F89D127295F2D4CC4764EB04571D9A46774C4,
	MobileInput_SetAxisZero_mCE681BFD720000CFA939C78B0EAEFCA3D5748BA8,
	MobileInput_SetAxis_m40791B9F5D8B28086FEA1030918A6DDBD96D2704,
	MobileInput_GetButtonDown_m8B7EC91AD10FF37A6910CC3AD684572F8CC4A403,
	MobileInput_GetButtonUp_mFB0BF6CE172238F3AF6B28CB16A73B5A0D714ABB,
	MobileInput_GetButton_m1805C5AAFEA6C56E1F083C318C7D8A56414742DC,
	MobileInput_MousePosition_m655B9F793060E92EEAFC358ED5A612124F71B234,
	MobileInput__ctor_m58D4C2380917920DD39E646CB4717F6EFBAA16F0,
	StandaloneInput_GetAxis_m208A36BD2256D5439E8BF99DFEE7C4FBE5C321DB,
	StandaloneInput_GetButton_m2156BA026DDB9F6FA9F45BBC8FEC871A3090629C,
	StandaloneInput_GetButtonDown_m3F88DFF900E2AB8729E6F63694BE3C8E2C19BBB7,
	StandaloneInput_GetButtonUp_mDF55E35A4B50D58901CEEF8DAEECD050A636398C,
	StandaloneInput_SetButtonDown_m5C1B0E5ED19F91DAEE8A23108865EBC57EB3F002,
	StandaloneInput_SetButtonUp_m23ECA36E7E2C9D79650FC93764E2FB47C52A6269,
	StandaloneInput_SetAxisPositive_m45ABA3A91481B6B07E37A24322C345DE4341472D,
	StandaloneInput_SetAxisNegative_m8ABB3422B35FA3D5EFEC9A3BCCE7D813C91E1DDA,
	StandaloneInput_SetAxisZero_mC0123C06F1DD19FF6DB9353DF0D711554B56B428,
	StandaloneInput_SetAxis_m620AB31F30F82FDB44EB995E494F618D8C42F765,
	StandaloneInput_MousePosition_m7D158ACA958E8C1101AFF4B3282E12B1A6EF7C82,
	StandaloneInput__ctor_m9D98FDF717857FB17019872D7A8446C224C493F3,
	VirtualAxis_get_name_mC3959CD36494EE1B06CAEA1675DD19E5FFCB9BD9,
	VirtualAxis_set_name_m2A44E0BF21BB426C9A14AB057D5EF41616B76096,
	VirtualAxis_get_matchWithInputManager_m2F68784B6C454EB26934401303E28C159980F315,
	VirtualAxis_set_matchWithInputManager_m326813FB9C39A5D63C98D4AE931384D6B67AE944,
	VirtualAxis__ctor_m9B094B00B2F0F1C6C474D3DA51419F4549540E53,
	VirtualAxis__ctor_mAC45A3BC043EA253666CCDE2762DB39475FED915,
	VirtualAxis_Remove_m0517C6C37E94CCC84337FD412982D1800E5CEFD6,
	VirtualAxis_Update_m639BD6EC869B61C712D4519290523C61745FF6C3,
	VirtualAxis_get_GetValue_mB0D352473A7E1F6A9402335FBD18625ADFCE0A69,
	VirtualAxis_get_GetValueRaw_mA75834F100AB39C130FEA7AE85677E4928E58397,
	VirtualButton_get_name_m836058DAC831C5BB481A422120939EB4D14CE55B,
	VirtualButton_set_name_mCC77CE771C89C23B47A2D9B027C7E754666A78A5,
	VirtualButton_get_matchWithInputManager_mD6924A44FFCFF72519BDDEAD61E3072CC3C3FCF3,
	VirtualButton_set_matchWithInputManager_mD438AFD4E212727BED9ECD1F0CBFE6243112AE3D,
	VirtualButton__ctor_mECADC4A0B8ACF0954720A84061800EA0F00D9FDD,
	VirtualButton__ctor_mBC57649412C90DFF3179B681B9D33BB88443FFD9,
	VirtualButton_Pressed_m596B075C829D1E8C500AF6694155488CF2250402,
	VirtualButton_Released_mC4B98C45864A5832601A90437E691119F28E25E6,
	VirtualButton_Remove_m0F66A404819C8B483DA3F02FDCEBDB005867D37D,
	VirtualButton_get_GetButton_m228F811AD3C4911C45AFEA7960E35F4A84B7A32D,
	VirtualButton_get_GetButtonDown_mB6BBC9E21BB477279E5D74926CFA633E671AC430,
	VirtualButton_get_GetButtonUp_m79C31A03EE6AC926E932FA1A28989A73B0257E43,
	AxisMapping__ctor_m2B8C914999C51C9568C81B4C1E6750BCAF66BE1F,
};
static const int32_t s_InvokerIndices[144] = 
{
	23,
	23,
	23,
	23,
	23,
	26,
	26,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	3,
	121,
	109,
	109,
	111,
	111,
	111,
	111,
	0,
	1200,
	1200,
	1602,
	109,
	109,
	109,
	111,
	111,
	111,
	111,
	111,
	1131,
	1086,
	1133,
	1133,
	1133,
	23,
	276,
	23,
	23,
	23,
	1005,
	23,
	26,
	26,
	26,
	23,
	23,
	23,
	23,
	23,
	31,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	1005,
	26,
	23,
	26,
	23,
	23,
	1004,
	1005,
	9,
	9,
	26,
	26,
	26,
	26,
	28,
	276,
	276,
	276,
	1603,
	9,
	9,
	9,
	26,
	26,
	26,
	26,
	26,
	829,
	1004,
	23,
	26,
	26,
	1603,
	26,
	26,
	26,
	26,
	26,
	829,
	9,
	9,
	9,
	1004,
	23,
	1603,
	9,
	9,
	9,
	26,
	26,
	26,
	26,
	26,
	829,
	1004,
	23,
	14,
	26,
	102,
	31,
	26,
	384,
	23,
	276,
	655,
	655,
	14,
	26,
	102,
	31,
	26,
	384,
	23,
	23,
	23,
	102,
	102,
	102,
	23,
};
extern const Il2CppCodeGenModule g_AssemblyU2DCSharpU2DfirstpassCodeGenModule;
const Il2CppCodeGenModule g_AssemblyU2DCSharpU2DfirstpassCodeGenModule = 
{
	"Assembly-CSharp-firstpass.dll",
	144,
	s_methodPointers,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
};
